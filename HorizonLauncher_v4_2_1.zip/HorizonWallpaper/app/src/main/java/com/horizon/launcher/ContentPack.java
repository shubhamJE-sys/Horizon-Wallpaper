package com.horizon.launcher;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Importable content pack: festivals, quote pools and extra wallpaper scenes that can be added
 * without building a new APK. A pack is either a plain JSON/text file, or a .zip containing
 * pack.json plus the scene images it refers to. Imports are merged into what is already stored.
 */
final class ContentPack {

    private static final String DIR = "pack";
    private static final int MAX_BYTES = 40 * 1024 * 1024;

    private final File dir;
    private JSONObject json = new JSONObject();

    private ContentPack(File dir) {
        this.dir = dir;
    }

    static ContentPack load(Context ctx) {
        ContentPack p = new ContentPack(new File(ctx.getFilesDir(), DIR));
        File f = new File(p.dir, "pack.json");
        if (f.isFile()) {
            try {
                p.json = new JSONObject(new String(readAll(new FileInputStream(f), MAX_BYTES), "UTF-8"));
            } catch (Exception ignored) {
                p.json = new JSONObject();
            }
        }
        return p;
    }

    // ---------- reading ----------

    boolean isEmpty() {
        return json.length() == 0;
    }

    String name() {
        return json.optString("name", "");
    }

    JSONArray festivals() {
        return json.optJSONArray("festivals");
    }

    List<String> quotes(String key) {
        List<String> out = new ArrayList<String>();
        JSONObject q = json.optJSONObject("quotes");
        if (q == null) return out;
        JSONArray a = q.optJSONArray(key);
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            String s = a.optString(i, "").trim();
            if (s.length() > 0) out.add(s);
        }
        return out;
    }

    /** Extra scenes as {id, name}. */
    List<String[]> scenes() {
        List<String[]> out = new ArrayList<String[]>();
        JSONArray a = json.optJSONArray("scenes");
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String id = o.optString("id", "");
            String file = o.optString("file", "");
            if (id.length() == 0 || file.length() == 0) continue;
            if (!new File(dir, file).isFile()) continue;
            out.add(new String[]{id, o.optString("name", id).toUpperCase(java.util.Locale.ENGLISH), file});
        }
        return out;
    }

    File sceneFile(String id) {
        for (String[] s : scenes()) {
            if (s[0].equals(id)) return new File(dir, s[2]);
        }
        return null;
    }

    String summary() {
        JSONArray f = festivals();
        int nf = f == null ? 0 : f.length();
        int nq = 0;
        JSONObject q = json.optJSONObject("quotes");
        if (q != null) {
            Iterator<String> it = q.keys();
            while (it.hasNext()) {
                JSONArray a = q.optJSONArray(it.next());
                if (a != null) nq += a.length();
            }
        }
        return nf + " FESTIVALS, " + nq + " MESSAGES, " + scenes().size() + " WALLPAPERS";
    }

    // ---------- importing ----------

    static void reset(Context ctx) {
        deleteTree(new File(ctx.getFilesDir(), DIR));
    }

    /** Imports a pack from a picked file. Returns a short message for the user; never throws. */
    static String importFrom(Context ctx, Uri uri) {
        File tmp = new File(ctx.getFilesDir(), "pack_tmp");
        try {
            InputStream in = ctx.getContentResolver().openInputStream(uri);
            if (in == null) return "COULD NOT OPEN THAT FILE";
            byte[] data = readAll(in, MAX_BYTES);
            deleteTree(tmp);
            if (!tmp.mkdirs()) return "COULD NOT PREPARE STORAGE";

            JSONObject incoming;
            File root = tmp;
            if (data.length > 4 && data[0] == 'P' && data[1] == 'K') {
                unzip(data, tmp);
                File pj = findFile(tmp, "pack.json", 0);
                if (pj == null) return "NOT A PACK: pack.json IS MISSING";
                root = pj.getParentFile();
                incoming = new JSONObject(new String(readAll(new FileInputStream(pj), MAX_BYTES), "UTF-8"));
            } else {
                incoming = new JSONObject(new String(data, "UTF-8").trim());
            }
            if (!incoming.has("festivals") && !incoming.has("quotes") && !incoming.has("scenes")) {
                return "NOT A PACK: NOTHING TO ADD";
            }

            File dir = new File(ctx.getFilesDir(), DIR);
            JSONObject cur = new JSONObject();
            if (!incoming.optBoolean("reset", false)) {
                File old = new File(dir, "pack.json");
                if (old.isFile()) {
                    try {
                        cur = new JSONObject(new String(readAll(new FileInputStream(old), MAX_BYTES), "UTF-8"));
                    } catch (Exception ignored) {
                        cur = new JSONObject();
                    }
                }
            } else {
                deleteTree(dir);
            }
            if (!dir.isDirectory() && !dir.mkdirs()) return "COULD NOT PREPARE STORAGE";

            cur.put("version", 1);
            if (incoming.has("name")) cur.put("name", incoming.optString("name"));

            // festivals: add, replacing the same date + name
            JSONArray cf = cur.optJSONArray("festivals");
            if (cf == null) cf = new JSONArray();
            JSONArray inf = incoming.optJSONArray("festivals");
            int addedF = 0;
            if (inf != null) {
                for (int i = 0; i < inf.length(); i++) {
                    JSONObject o = inf.optJSONObject(i);
                    if (o == null || o.optString("date", "").length() == 0) continue;
                    JSONArray next = new JSONArray();
                    for (int k = 0; k < cf.length(); k++) {
                        JSONObject e = cf.optJSONObject(k);
                        if (e != null && !(e.optString("date").equals(o.optString("date"))
                                && e.optString("name").equals(o.optString("name")))) {
                            next.put(e);
                        }
                    }
                    next.put(o);
                    cf = next;
                    addedF++;
                }
            }
            cur.put("festivals", cf);

            // quotes: append, skipping duplicates
            JSONObject cq = cur.optJSONObject("quotes");
            if (cq == null) cq = new JSONObject();
            JSONObject inq = incoming.optJSONObject("quotes");
            int addedQ = 0;
            if (inq != null) {
                Iterator<String> it = inq.keys();
                while (it.hasNext()) {
                    String key = it.next();
                    JSONArray src = inq.optJSONArray(key);
                    if (src == null) continue;
                    JSONArray dst = cq.optJSONArray(key);
                    if (dst == null) dst = new JSONArray();
                    for (int i = 0; i < src.length(); i++) {
                        String s = src.optString(i, "").trim();
                        if (s.length() == 0) continue;
                        boolean dup = false;
                        for (int k = 0; k < dst.length(); k++) {
                            if (s.equals(dst.optString(k))) {
                                dup = true;
                                break;
                            }
                        }
                        if (!dup) {
                            dst.put(s);
                            addedQ++;
                        }
                    }
                    cq.put(key, dst);
                }
            }
            cur.put("quotes", cq);

            // scenes: copy images, replace the same id
            JSONArray cs = cur.optJSONArray("scenes");
            if (cs == null) cs = new JSONArray();
            JSONArray ins = incoming.optJSONArray("scenes");
            int addedS = 0;
            if (ins != null) {
                File sceneDir = new File(dir, "scenes");
                sceneDir.mkdirs();
                for (int i = 0; i < ins.length(); i++) {
                    JSONObject o = ins.optJSONObject(i);
                    if (o == null) continue;
                    String id = o.optString("id", "").replaceAll("[^A-Za-z0-9_-]", "");
                    String file = o.optString("file", "");
                    if (id.length() == 0 || file.length() == 0) continue;
                    File srcF = new File(root, file);
                    if (!srcF.isFile()) continue;
                    BitmapFactory.Options opt = new BitmapFactory.Options();
                    opt.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(srcF.getAbsolutePath(), opt);
                    if (opt.outWidth <= 0) continue;
                    String ext = file.toLowerCase().endsWith(".webp") ? ".webp" : ".png";
                    String rel = "scenes/" + id + ext;
                    copyFile(srcF, new File(dir, rel));
                    JSONObject entry = new JSONObject();
                    entry.put("id", id);
                    entry.put("name", o.optString("name", id));
                    entry.put("file", rel);
                    JSONArray next = new JSONArray();
                    for (int k = 0; k < cs.length(); k++) {
                        JSONObject e = cs.optJSONObject(k);
                        if (e != null && !id.equals(e.optString("id"))) next.put(e);
                    }
                    next.put(entry);
                    cs = next;
                    addedS++;
                }
            }
            cur.put("scenes", cs);

            writeFile(new File(dir, "pack.json"), cur.toString().getBytes("UTF-8"));
            return "PACK ADDED: " + addedF + " FESTIVALS, " + addedQ + " MESSAGES, " + addedS + " WALLPAPERS";
        } catch (Exception e) {
            return "COULD NOT READ THIS PACK";
        } finally {
            deleteTree(tmp);
        }
    }

    // ---------- file helpers ----------

    private static byte[] readAll(InputStream in, int max) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        long total = 0;
        try {
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > max) throw new Exception("too big");
                bo.write(buf, 0, n);
            }
        } finally {
            try {
                in.close();
            } catch (Exception ignored) { }
        }
        return bo.toByteArray();
    }

    private static void unzip(byte[] data, File into) throws Exception {
        String base = into.getCanonicalPath() + File.separator;
        ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(data));
        try {
            ZipEntry e;
            int count = 0;
            while ((e = z.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                if (++count > 300) break;
                File out = new File(into, e.getName());
                String canon = out.getCanonicalPath();
                if (!canon.startsWith(base)) continue; // zip-slip guard
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                OutputStream os = new FileOutputStream(out);
                try {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = z.read(buf)) > 0) os.write(buf, 0, n);
                } finally {
                    os.close();
                }
            }
        } finally {
            z.close();
        }
    }

    private static File findFile(File dir, String name, int depth) {
        File[] list = dir.listFiles();
        if (list == null || depth > 3) return null;
        for (File f : list) {
            if (f.isFile() && f.getName().equals(name)) return f;
        }
        for (File f : list) {
            if (f.isDirectory()) {
                File r = findFile(f, name, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static void copyFile(File from, File to) throws Exception {
        File parent = to.getParentFile();
        if (parent != null) parent.mkdirs();
        writeFile(to, readAll(new FileInputStream(from), MAX_BYTES));
    }

    private static void writeFile(File f, byte[] data) throws Exception {
        OutputStream os = new FileOutputStream(f);
        try {
            os.write(data);
        } finally {
            os.close();
        }
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) deleteTree(k);
        }
        f.delete();
    }
}
