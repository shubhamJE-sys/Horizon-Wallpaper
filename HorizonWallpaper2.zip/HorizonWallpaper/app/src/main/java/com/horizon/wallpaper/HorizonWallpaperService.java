package com.horizon.wallpaper;

import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.service.wallpaper.WallpaperService;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import java.io.InputStream;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Retro poster live wallpaper. The background image (design size 360x804 units,
 * stored at 4x) has empty frames; this service draws the live clock, date, day,
 * greeting, day-of-year, battery/charging, music player and text buttons into them.
 */
public class HorizonWallpaperService extends WallpaperService {

    private static final float DW = 360f, DH = 804f;
    private static final int INK = Color.parseColor("#1B1B1A");
    private static final int RED = Color.parseColor("#C8382C");
    private static final int CREAM = Color.parseColor("#ECE3D0");

    // media panel (expanded) bounds in design units
    private static final float PANEL_L = 8f, PANEL_R = 352f, PANEL_T = 395f, PANEL_B = 553f;
    private static final float BTN_Y = 524f, PREV_X = 160f, PLAY_X = 234f, NEXT_X = 308f;

    private static final String[] BUTTON_WORDS = {
            "PHONE", "MESSAGES", "BROWSER", "GALLERY", "CAMERA", "PLAY STORE"};

    @Override
    public Engine onCreateEngine() {
        return new PosterEngine();
    }

    private class PosterEngine extends Engine {
        private Bitmap bg;
        private Typeface bebas, roboto;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Paint artPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Handler handler = new Handler(Looper.getMainLooper());

        private int width, height;
        private float scale = 1f, offX = 0f, offY = 0f;
        private boolean visible = false;
        private boolean receiving = false;
        private long lastTap = 0;

        // battery
        private int batteryPct = 100;
        private int pluggedType = 0;
        private float tempC = -1f;

        // media
        private MediaSessionManager msm;
        private ComponentName listenerComp;
        private MediaController controller;
        private Bitmap art;
        private boolean mediaRegistered = false;

        private final BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                    readBattery(intent);
                }
                draw();
            }
        };

        private final Runnable ticker = new Runnable() {
            @Override
            public void run() {
                draw();
                scheduleTick();
            }
        };

        private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
                new MediaSessionManager.OnActiveSessionsChangedListener() {
                    @Override
                    public void onActiveSessionsChanged(List<MediaController> controllers) {
                        pickController(controllers);
                        draw();
                    }
                };

        private final MediaController.Callback controllerCallback = new MediaController.Callback() {
            @Override
            public void onPlaybackStateChanged(PlaybackState state) {
                draw();
                scheduleTick();
            }

            @Override
            public void onMetadataChanged(MediaMetadata metadata) {
                updateArt();
                draw();
            }

            @Override
            public void onSessionDestroyed() {
                setController(null);
                draw();
            }
        };

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);
            try {
                InputStream in = getAssets().open("live_bg.jpg");
                bg = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Exception ignored) { }
            try {
                bebas = Typeface.createFromAsset(getAssets(), "BebasNeue.ttf");
                roboto = Typeface.createFromAsset(getAssets(), "Roboto-Regular.ttf");
            } catch (Exception e) {
                bebas = Typeface.DEFAULT_BOLD;
                roboto = Typeface.DEFAULT;
            }
            ColorMatrix gray = new ColorMatrix();
            gray.setSaturation(0f);
            artPaint.setColorFilter(new ColorMatrixColorFilter(gray));
            Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (sticky != null) readBattery(sticky);
        }

        // ---------- battery ----------

        private void readBattery(Intent i) {
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scaleVal = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (level >= 0 && scaleVal > 0) batteryPct = Math.round(level * 100f / scaleVal);
            pluggedType = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            tempC = t >= 0 ? t / 10f : -1f;
        }

        private void startReceiving() {
            if (receiving) return;
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_TIME_TICK);
            f.addAction(Intent.ACTION_TIME_CHANGED);
            f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            f.addAction(Intent.ACTION_BATTERY_CHANGED);
            f.addAction(Intent.ACTION_POWER_CONNECTED);
            f.addAction(Intent.ACTION_POWER_DISCONNECTED);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(receiver, f);
            }
            receiving = true;
            Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (sticky != null) readBattery(sticky);
        }

        private void stopReceiving() {
            if (!receiving) return;
            try { unregisterReceiver(receiver); } catch (Exception ignored) { }
            receiving = false;
        }

        // ---------- media ----------

        private boolean hasListenerAccess() {
            try {
                String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
                return flat != null && flat.contains(getPackageName());
            } catch (Exception e) {
                return false;
            }
        }

        private void startMedia() {
            if (mediaRegistered || !hasListenerAccess()) return;
            try {
                msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
                listenerComp = new ComponentName(HorizonWallpaperService.this, MediaListenerService.class);
                msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComp, handler);
                mediaRegistered = true;
                pickController(msm.getActiveSessions(listenerComp));
            } catch (RuntimeException e) {
                mediaRegistered = false;
            }
        }

        private void stopMedia() {
            if (msm != null && mediaRegistered) {
                try { msm.removeOnActiveSessionsChangedListener(sessionsListener); } catch (Exception ignored) { }
            }
            mediaRegistered = false;
            setController(null);
        }

        private void pickController(List<MediaController> list) {
            MediaController best = null;
            if (list != null) {
                for (MediaController mc : list) {
                    PlaybackState st = mc.getPlaybackState();
                    if (st == null) continue;
                    if (st.getState() == PlaybackState.STATE_PLAYING) {
                        best = mc;
                        break;
                    }
                    if (best == null && mc.getMetadata() != null
                            && (st.getState() == PlaybackState.STATE_PAUSED
                            || st.getState() == PlaybackState.STATE_BUFFERING)) {
                        best = mc;
                    }
                }
            }
            setController(best);
        }

        private void setController(MediaController mc) {
            if (controller != null) {
                try { controller.unregisterCallback(controllerCallback); } catch (Exception ignored) { }
            }
            controller = mc;
            if (mc != null) {
                try { mc.registerCallback(controllerCallback, handler); } catch (Exception ignored) { }
            }
            updateArt();
            scheduleTick();
        }

        private void updateArt() {
            art = null;
            if (controller == null) return;
            MediaMetadata m = controller.getMetadata();
            if (m == null) return;
            Bitmap b = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
            if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
            art = b;
        }

        private boolean isPlaying() {
            if (controller == null) return false;
            PlaybackState st = controller.getPlaybackState();
            return st != null && st.getState() == PlaybackState.STATE_PLAYING;
        }

        private boolean mediaActive() {
            if (controller == null) return false;
            PlaybackState st = controller.getPlaybackState();
            MediaMetadata m = controller.getMetadata();
            if (st == null || m == null) return false;
            int s = st.getState();
            if (s != PlaybackState.STATE_PLAYING && s != PlaybackState.STATE_PAUSED
                    && s != PlaybackState.STATE_BUFFERING) return false;
            CharSequence title = m.getText(MediaMetadata.METADATA_KEY_TITLE);
            return !TextUtils.isEmpty(title);
        }

        private void scheduleTick() {
            handler.removeCallbacks(ticker);
            if (visible && isPlaying()) handler.postDelayed(ticker, 1000);
        }

        private long position() {
            PlaybackState s = controller.getPlaybackState();
            if (s == null) return 0;
            long p = s.getPosition();
            if (s.getState() == PlaybackState.STATE_PLAYING) {
                long dt = SystemClock.elapsedRealtime() - s.getLastPositionUpdateTime();
                p += (long) (dt * s.getPlaybackSpeed());
            }
            return Math.max(0, p);
        }

        // ---------- lifecycle ----------

        @Override
        public void onVisibilityChanged(boolean vis) {
            visible = vis;
            if (vis) {
                startReceiving();
                startMedia();
                draw();
                scheduleTick();
            } else {
                handler.removeCallbacks(ticker);
                stopReceiving();
                stopMedia();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            width = w;
            height = h;
            draw();
        }

        @Override
        public void onDestroy() {
            handler.removeCallbacks(ticker);
            stopReceiving();
            stopMedia();
            super.onDestroy();
        }

        // ---------- touch ----------

        @Override
        public void onTouchEvent(MotionEvent event) {
            super.onTouchEvent(event);
            if (event.getAction() == MotionEvent.ACTION_UP) handleTap(event.getX(), event.getY());
        }

        @Override
        public android.os.Bundle onCommand(String action, int x, int y, int z,
                                           android.os.Bundle extras, boolean resultRequested) {
            if (WallpaperManager.COMMAND_TAP.equals(action)) handleTap(x, y);
            return super.onCommand(action, x, y, z, extras, resultRequested);
        }

        private void handleTap(float px, float py) {
            long now = SystemClock.uptimeMillis();
            if (now - lastTap < 350) return;
            if (width <= 0) return;
            float x = (px - offX) / scale;
            float y = (py - offY) / scale;

            if (mediaActive() && x >= PANEL_L && x <= PANEL_R && y >= PANEL_T && y <= PANEL_B) {
                lastTap = now;
                mediaTap(x, y);
                return;
            }
            if (!hasListenerAccess() && x >= 8 && x <= 230 && y >= 477 && y <= 553) {
                lastTap = now;
                openNotificationAccess();
                return;
            }
            if (x >= 8 && x <= 352 && y >= 641 && y <= 771) {
                lastTap = now;
                int col = (int) ((x - 8) / (344f / 3f));
                col = Math.max(0, Math.min(2, col));
                int row = y < 713 ? 0 : 1;
                launchButton(row * 3 + col);
            }
        }

        private boolean near(float x, float y, float cx, float cy, float r) {
            float dx = x - cx, dy = y - cy;
            return dx * dx + dy * dy <= r * r;
        }

        private void mediaTap(float x, float y) {
            if (controller == null) return;
            try {
                if (near(x, y, PREV_X, BTN_Y, 24)) {
                    controller.getTransportControls().skipToPrevious();
                } else if (near(x, y, NEXT_X, BTN_Y, 24)) {
                    controller.getTransportControls().skipToNext();
                } else if (near(x, y, PLAY_X, BTN_Y, 26)) {
                    if (isPlaying()) controller.getTransportControls().pause();
                    else controller.getTransportControls().play();
                } else if (controller.getSessionActivity() != null) {
                    controller.getSessionActivity().send();
                }
            } catch (Exception ignored) { }
        }

        private void openNotificationAccess() {
            try {
                Intent i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                HorizonWallpaperService.this.startActivity(i);
            } catch (Exception ignored) { }
        }

        private void launchButton(int idx) {
            Intent i = null;
            switch (idx) {
                case 0:
                    i = new Intent(Intent.ACTION_DIAL);
                    break;
                case 1:
                    i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING);
                    break;
                case 2:
                    i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
                    break;
                case 3:
                    i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY);
                    break;
                case 4:
                    i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                    break;
                case 5:
                    i = getPackageManager().getLaunchIntentForPackage("com.android.vending");
                    break;
                default:
                    break;
            }
            if (i == null) return;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                HorizonWallpaperService.this.startActivity(i);
            } catch (Exception ignored) { }
        }

        // ---------- drawing ----------

        private void draw() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null && width > 0) render(c);
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Exception ignored) { }
                }
            }
        }

        private void render(Canvas c) {
            c.drawColor(CREAM);
            scale = Math.max(width / DW, height / DH);
            offX = (width - DW * scale) / 2f;
            offY = (height - DH * scale) / 2f;

            if (bg != null) {
                Matrix m = new Matrix();
                float bs = scale * DW / bg.getWidth();
                m.postScale(bs, bs);
                m.postTranslate(offX, offY);
                c.drawBitmap(bg, m, bitmapPaint);
            }

            c.save();
            c.translate(offX, offY);
            c.scale(scale, scale);
            drawLive(c);
            c.restore();
        }

        private void text(Canvas c, String t, float x, float y, float size, int color,
                          Typeface tf, Paint.Align align, float spacingEm) {
            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(tf);
            paint.setTextSize(size);
            paint.setColor(color);
            paint.setTextAlign(align);
            paint.setLetterSpacing(spacingEm);
            c.drawText(t, x, y, paint);
        }

        private void drawLive(Canvas c) {
            Calendar cal = Calendar.getInstance();
            boolean h24 = DateFormat.is24HourFormat(HorizonWallpaperService.this);
            int hour = cal.get(Calendar.HOUR_OF_DAY);
            int hh = h24 ? hour : ((hour % 12 == 0) ? 12 : hour % 12);
            int mm = cal.get(Calendar.MINUTE);

            // Clock (top-left frame)
            text(c, String.format(Locale.US, "%02d", hh), 14, 108, 96, INK, bebas, Paint.Align.LEFT, 0f);
            text(c, String.format(Locale.US, "%02d", mm), 14, 182, 96, RED, bebas, Paint.Align.LEFT, 0f);

            // Date next to clock
            String mon = cal.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
            text(c, mon, 112, 62, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            text(c, String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), 112, 88, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            text(c, String.valueOf(cal.get(Calendar.YEAR)), 112, 114, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(INK);
            paint.setStrokeWidth(1.5f);
            c.drawLine(112, 126, 160, 126, paint);
            if (!h24) {
                text(c, hour < 12 ? "AM" : "PM", 112, 144, 10, RED, roboto, Paint.Align.LEFT, 0.25f);
            }

            // Day name, vertical (right column of top frame)
            String day = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
            float size = 62f;
            paint.setTypeface(bebas);
            paint.setTextSize(size);
            paint.setLetterSpacing(0.02f);
            float wdt = paint.measureText(day);
            if (wdt > 182f) size = size * 182f / wdt;
            float cap = size * 0.70f;
            c.save();
            c.translate(266f + cap / 2f, 228f);
            c.rotate(-90f);
            text(c, day, 0, 0, size, INK, bebas, Paint.Align.LEFT, 0.02f);
            c.restore();

            // Greeting (media frame) - replaced by the music panel while music is active
            String greet = hour < 12 ? "GOOD MORNING" : (hour < 17 ? "GOOD AFTERNOON" : (hour < 21 ? "GOOD EVENING" : "GOOD NIGHT"));
            float gs = 40f;
            paint.setTypeface(bebas);
            paint.setTextSize(gs);
            paint.setLetterSpacing(0.03f);
            float gw = paint.measureText(greet);
            if (gw > 205f) gs = gs * 205f / gw;
            text(c, greet, 18, 524, gs, INK, bebas, Paint.Align.LEFT, 0.03f);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(RED);
            c.drawRect(18, 534, 54, 536.5f, paint);
            if (!hasListenerAccess()) {
                text(c, "TAP HERE TO ENABLE MUSIC CONTROLS", 18, 548, 5.6f, RED, roboto, Paint.Align.LEFT, 0.16f);
            }

            // Day of year (left small frame)
            text(c, String.valueOf(cal.get(Calendar.DAY_OF_YEAR)), 16, 590, 42, INK, bebas, Paint.Align.LEFT, 0f);
            text(c, "DAY OF THE YEAR", 16, 603, 5.6f, INK, roboto, Paint.Align.LEFT, 0.25f);

            // Battery (right frame)
            drawBattery(c);

            // Text buttons in the bottom grid
            drawButtons(c);

            // Expanded music panel on top of everything else
            if (mediaActive()) drawMusic(c);
        }

        private void drawButtons(Canvas c) {
            float cw = 344f / 3f;
            for (int row = 0; row < 2; row++) {
                for (int col = 0; col < 3; col++) {
                    float cx = 8f + cw * (col + 0.5f);
                    float baseline = row == 0 ? 678f : 744f;
                    text(c, BUTTON_WORDS[row * 3 + col], cx, baseline, 22, INK, bebas,
                            Paint.Align.CENTER, 0.06f);
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(RED);
                    c.drawRect(cx - 9, baseline + 6, cx + 9, baseline + 8, paint);
                }
            }
        }

        private void drawBattery(Canvas c) {
            float x = 146, y = 562, w = 52, h = 22;
            boolean charging = pluggedType != 0;

            paint.setColor(INK);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.8f);
            c.drawRoundRect(x, y, x + w, y + h, 3, 3, paint);
            paint.setStyle(Paint.Style.FILL);
            c.drawRect(x + w, y + 6, x + w + 4, y + h - 6, paint);

            int segs = Math.max(batteryPct > 0 ? 1 : 0, Math.round(batteryPct / 20f));
            paint.setColor(RED);
            float sw = (w - 8) / 5f;
            for (int i = 0; i < segs && i < 5; i++) {
                float sx = x + 3 + i * sw;
                c.drawRect(sx, y + 3, sx + sw - 2, y + h - 3, paint);
            }

            if (charging) {
                float cx = x + w / 2f, top = y + 2f;
                Path bolt = new Path();
                bolt.moveTo(cx + 3f, top);
                bolt.lineTo(cx - 6f, top + 11f);
                bolt.lineTo(cx - 0.5f, top + 11f);
                bolt.lineTo(cx - 3f, top + 18f);
                bolt.lineTo(cx + 6f, top + 7f);
                bolt.lineTo(cx + 0.5f, top + 7f);
                bolt.close();
                paint.setColor(CREAM);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                paint.setStrokeWidth(1.6f);
                c.drawPath(bolt, paint);
                paint.setColor(INK);
                paint.setStyle(Paint.Style.FILL);
                c.drawPath(bolt, paint);
            }

            text(c, batteryPct + "%", 342, 592, 44, INK, bebas, Paint.Align.RIGHT, 0f);

            String status;
            if (charging) {
                String src = pluggedType == BatteryManager.BATTERY_PLUGGED_WIRELESS ? "WIRELESS"
                        : (pluggedType == BatteryManager.BATTERY_PLUGGED_USB ? "USB" : "CABLE");
                status = "CHARGING • " + src;
            } else {
                status = "ON BATTERY";
            }
            if (tempC >= 0) status += " • " + Math.round(tempC) + "°C";
            text(c, status, 146, 593, 6.2f, charging ? RED : INK, roboto, Paint.Align.LEFT, 0.16f);
        }

        private String fmt(long ms) {
            long s = Math.max(0, ms / 1000);
            return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
        }

        private void drawMusic(Canvas c) {
            MediaMetadata m = controller.getMetadata();
            if (m == null) return;
            String title = String.valueOf(m.getText(MediaMetadata.METADATA_KEY_TITLE));
            CharSequence artistCs = m.getText(MediaMetadata.METADATA_KEY_ARTIST);
            if (TextUtils.isEmpty(artistCs)) artistCs = m.getText(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
            String artist = artistCs == null ? "" : artistCs.toString().toUpperCase(Locale.getDefault());
            long dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION);
            long pos = position();
            if (dur > 0 && pos > dur) pos = dur;
            boolean playing = isPlaying();

            // panel background + frame
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(CREAM);
            c.drawRect(PANEL_L, PANEL_T, PANEL_R, PANEL_B - 1f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(INK);
            paint.setStrokeWidth(1.5f);
            c.drawRect(PANEL_L, PANEL_T, PANEL_R, PANEL_B - 1f, paint);

            text(c, playing ? "NOW PLAYING" : "PAUSED", 126, 410, 6f, RED, roboto, Paint.Align.LEFT, 0.3f);

            // cover art
            RectF dst = new RectF(18, 405, 114, 501);
            if (art != null && art.getWidth() > 0 && art.getHeight() > 0) {
                int sw = art.getWidth(), sh = art.getHeight(), side = Math.min(sw, sh);
                Rect src = new Rect((sw - side) / 2, (sh - side) / 2, (sw + side) / 2, (sh + side) / 2);
                c.drawBitmap(art, src, dst, artPaint);
            } else {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(Color.parseColor("#D9D1BF"));
                c.drawRect(dst, paint);
                text(c, "♫", 66, 462, 40, INK, roboto, Paint.Align.CENTER, 0f);
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(INK);
            paint.setStrokeWidth(1.5f);
            c.drawRect(dst, paint);

            // title (ellipsized) + artist
            TextPaint tp = new TextPaint(paint);
            tp.setStyle(Paint.Style.FILL);
            tp.setTypeface(bebas);
            tp.setTextSize(30f);
            tp.setLetterSpacing(0.02f);
            CharSequence t = TextUtils.ellipsize(title.toUpperCase(Locale.getDefault()), tp, 214f, TextUtils.TruncateAt.END);
            text(c, t.toString(), 126, 440, 30f, INK, bebas, Paint.Align.LEFT, 0.02f);
            TextPaint ap = new TextPaint(paint);
            ap.setStyle(Paint.Style.FILL);
            ap.setTypeface(roboto);
            ap.setTextSize(8.5f);
            ap.setLetterSpacing(0.16f);
            CharSequence a = TextUtils.ellipsize(artist, ap, 214f, TextUtils.TruncateAt.END);
            text(c, a.toString(), 126, 456, 8.5f, INK, roboto, Paint.Align.LEFT, 0.16f);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(RED);
            c.drawRect(126, 464, 150, 466.5f, paint);

            // progress bar
            float px0 = 126, px1 = 342, py = 486;
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(INK);
            paint.setStrokeWidth(1.2f);
            c.drawLine(px0, py, px1, py, paint);
            float frac = dur > 0 ? Math.min(1f, (float) pos / dur) : 0f;
            paint.setColor(RED);
            paint.setStrokeWidth(2.4f);
            c.drawLine(px0, py, px0 + (px1 - px0) * frac, py, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(INK);
            c.drawCircle(px0 + (px1 - px0) * frac, py, 3f, paint);
            text(c, fmt(pos), px0, 499, 6.5f, INK, roboto, Paint.Align.LEFT, 0.1f);
            if (dur > 0) text(c, fmt(dur), px1, 499, 6.5f, INK, roboto, Paint.Align.RIGHT, 0.1f);

            // transport buttons
            float cy = BTN_Y;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(INK);
            c.drawRect(PREV_X - 9, cy - 7, PREV_X - 7, cy + 7, paint);
            Path prev = new Path();
            prev.moveTo(PREV_X + 8, cy - 7);
            prev.lineTo(PREV_X - 5, cy);
            prev.lineTo(PREV_X + 8, cy + 7);
            prev.close();
            c.drawPath(prev, paint);

            c.drawRect(NEXT_X + 7, cy - 7, NEXT_X + 9, cy + 7, paint);
            Path next = new Path();
            next.moveTo(NEXT_X - 8, cy - 7);
            next.lineTo(NEXT_X + 5, cy);
            next.lineTo(NEXT_X - 8, cy + 7);
            next.close();
            c.drawPath(next, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(RED);
            paint.setStrokeWidth(2.2f);
            c.drawCircle(PLAY_X, cy, 17, paint);
            paint.setStyle(Paint.Style.FILL);
            if (playing) {
                c.drawRect(PLAY_X - 5, cy - 7, PLAY_X - 2, cy + 7, paint);
                c.drawRect(PLAY_X + 2, cy - 7, PLAY_X + 5, cy + 7, paint);
            } else {
                Path play = new Path();
                play.moveTo(PLAY_X - 4, cy - 8);
                play.lineTo(PLAY_X - 4, cy + 8);
                play.lineTo(PLAY_X + 8, cy);
                play.close();
                c.drawPath(play, paint);
            }
        }
    }
}
