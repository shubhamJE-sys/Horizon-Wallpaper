# Horizon Launcher - code, structure and rules of the app (v6.15)

Package `com.horizon.launcher`, Android 8+ (minSdk 26, targetSdk 36), phones only, no AndroidX, no extra permissions.
Signed with the fixed key `app/horizon.keystore` (never change or lose it; md5 9d0706916a7a18e7fd293b1e6be730f6).

## How the zips fit together
- `HorizonLauncher_v6_15.zip` (this one): the whole project WITHOUT the beach pictures.
- `HorizonScene_beach.zip`: only the beach pictures, laid out as `HorizonWallpaper/app/src/main/assets/...`.
- Repo root = both zips + `.github/workflows/build.yml` (the new one in `repo_workflow/`). The workflow unpacks the newest code zip
  (every .zip whose name does not start with `HorizonScene_`), then every `HorizonScene_*.zip` on top of it, then builds.
- Without the scene zip the app still builds and runs: ANDAMAN BEACH then shows the old scene (see `StackScene.beachReady`).
- Each zip is under GitHub's 25 MB web-upload limit (code about 21.5 MB, scene about 8.6 MB).

## Project structure (app/src/main/java/com/horizon/launcher)
- `HomeActivity` home + lock wallpaper host; `PosterView` page 1 (poster home, taps, sky, scene box); `RoomView` page 2 (retro room, window, item shelves); `LockArt` lock-screen picture.
- Scenes: `Look` (daily pick: colour scheme, festival, scene ids/names, texts), `SceneRender` (loads a scene's layers), `StackScene` (layered scenes in a 1364x944 scene space:
  city, highway, dunes/oasis, lake, beach), `Boats`, `Decor` (festival diyas), `StringLights`, `Festivals`, `ContentPack`, `ThemePack` (IMPORT THEME zip: sky, sun, stars, water, moon parts).
- Sky: `Sky`, `SkyArt` (painted/real skies, stars, photo sun), `SkyEngine`, `Moon`, `Astro`, `Body` (sun/moon positions for the chosen city), `Loc`, `Palette`, `Texts`, `InfoCards`, `IconStyler`, `SignalWatcher`, `WaterExt`.
- Assets: `app/src/main/assets` (scene layers `sc_*`, props, room, skies, etc.).

## Rules of the app (decided by the user)
- Never build or send a new version until told ("go" / "make next version"); keep a list of queued edits. Mock-ups are rendered from the real app code.
- Page 1: four equal 58-unit rows, grid lines 1.5, version mark right under the grid, swipe down splits (left half notifications, right half quick settings), swipe up = All Apps, greeting = news, Phone tap = dialer home (hold = Contacts).
- Text: one colour per text (white or black by contrast, thin opposite soft outline under 3:1). Never 5-point stars; sun is drawn in code.
- Layered scenes: solid down to the imaginary line (top of the greeting row), fading to nothing by the middle of GOOD MORNING; no streaks or mirrored images under a scene; no scene top may be cut.
  The painted sky behind a layered scene is stretched on below its horizon and fades out over the same 23 units as the scene (`Sky.artFade`, `SkyArt.draw`), so the panel colour comes in under the fade and no edge or faint line shows behind it (home screen and lock screen).
- Page 2 (room) is rebuilt from item layers, never patched; window shows the lower 70% scene / 30% sky, original colours, weather applies.
- New themes and scenes come in through IMPORT THEME first; scenes are wired in only when the user says the set is complete. ANDAMAN BEACH = the new beach scene (v6.14).
- Highway festival strings (tea stall every festival, shrine on Diwali) are drawn INSIDE the scene (`StackScene.roadside` overlay, after the roadside props and before the traffic), so buses and lorries pass in front of them. Their night glow is kept small and faint (`StringLights.highway`, `farGlowAlpha` 0.3, `farGlowRad` 0.6) because the view is far and the bulbs must stay clearly visible; page 1's other strings keep the full glow.
- Headlights (`StackScene.headlight`) throw light forward only, onto the road ahead; nothing behind the lamp, and the lamp shows as a small bright spot. Tail lights stay a small red glow.
- Real Sky sun (imported zip with `engine`): the sun is a set of photographs, all 512 px square with the disc 184 px in radius so the size never changes: `sun` (clear day, required),
  `sun_gold`, `sun_low`, `sun_red` (the low sun walks gold > amber > deep red as it nears the horizon: warm 0.2-0.9, neighbours cross-fade) and `sun_haze` (cloud > 0.55), `sun_hot` (35 C and over),
  `sun_cold` (18 C and under). Missing parts fall back to `sun`. Only the plain `sun` is tinted orange by code; the photographs carry their own colour. See `SkyArt.drawSun`, `SkyArt.weatherSun`.
- Phone use strains eyes: calm, informative at a glance; avoid extra permissions; works on every phone (curved corners and camera cut-out respected).

## Beach scene taps (page 1, beach shown)
- 2 taps cancel both cycles; locking the phone cancels them too. Nothing is on the beach at rest (empty lounger, towel set, no mermaid).
- 3 taps start the bench girl cycle: it then runs by itself, no more taps needed (a further 3 taps only skip to the next picture). Lounger woman 1-3 (each rests 24 s, walks to the sea, jumps 5 times in a loop, dives away and comes back; 50 s per picture), then the woman lying on the towel 1-4 (16 s each), round and round, with cross-fades.
- 4 taps start the mermaid cycle: she fades in and then goes through her looks by herself (long hair, short hair, shell top, round again); no more taps needed (a further 4 taps only skip to the next look). Short hair and shell top: each picture shows 24 s. Long hair: her first picture 24 s, then 5 s of playing with the water by her legs (her two legs-in-water pictures swap every 280 ms), then she swims ashore. In every look she then lies ashore for 7 towel pictures (12 s each) before she swims back. Both cycles can run together.
- The beach pictures end on the line at the foot of the scene; the sea and sand carry on below it as a short copy of their own last rows (carryOn in StackScene: plain water and sand texture, no objects; the city and oasis use the same method) so the standard fade (100% at the line, 0% at the middle of the greeting text) has art to fade. Real extra rows drawn for the beach would replace it.
- Taps are counted within 550 ms; the action is decided after the last tap (3 taps are not mistaken for the start of 4).
- Details and timings: see `SCENE_beach_NOTES.md` inside `HorizonScene_beach.zip`.
