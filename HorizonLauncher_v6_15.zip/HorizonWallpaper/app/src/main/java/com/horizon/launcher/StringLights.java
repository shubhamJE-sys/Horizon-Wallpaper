package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * The engraved string lights for page 1 (assets p1_h0..9 off / on, bulb positions in p1_pts.txt):
 * 0 filament bulbs, 1 and 2 stars, 3 hearts, 4 moons, 5 lanterns, 6 flowers, 7 jars, 8 globe bulbs, 9 teardrop bulbs.
 */
final class StringLights {
    static final int FILAMENT = 0, STAR_A = 1, STAR_B = 2, HEART = 3, MOON = 4, LANTERN = 5, FLOWER = 6, JAR = 7, GLOBE = 8, DROP = 9;
    private static final Bitmap[][] B = new Bitmap[10][2];
    private static float[][][] pts;
    private static final Paint BP = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private static final Paint GP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final RectF R = new RectF();
    private static final int[] TRI = {0xFFFF9933, 0xFFFFFFFF, 0xFF3CDC5A};
    /** Glow controls (canvas units): the smallest glow radius, how strong the glows are and how wide (1 = the page-1 look). Far views turn the glow down so the bulbs stay visible. */
    private static float glowMin = 5f, glowAlpha = 1f, glowRad = 1f;

    private StringLights() { }

    private static Bitmap bmp(Context ctx, int k, int on) {
        if (B[k][on] == null) {
            try (InputStream in = ctx.getAssets().open("p1_h" + k + (on == 1 ? "_on" : "_off") + ".webp")) {
                B[k][on] = BitmapFactory.decodeStream(in);
            } catch (Throwable ignored) { }
        }
        return B[k][on];
    }

    private static void loadPts(Context ctx) {
        if (pts != null) return;
        float[][][] p = new float[10][][];
        try (BufferedReader br = new BufferedReader(new InputStreamReader(ctx.getAssets().open("p1_pts.txt")))) {
            String ln;
            while ((ln = br.readLine()) != null) {
                String[] t = ln.trim().split(" ");
                if (t.length < 3) continue;
                int k = t[0].charAt(1) - '0';
                float[][] q = new float[t.length - 3][2];
                for (int i = 3; i < t.length; i++) {
                    String[] xy = t[i].split(",");
                    q[i - 3][0] = Float.parseFloat(xy[0]);
                    q[i - 3][1] = Float.parseFloat(xy[1]);
                }
                p[k] = q;
            }
        } catch (Throwable ignored) { }
        pts = p;
    }

    private static void glow(Canvas c, float x, float y, float r, int rgb, float a) {
        int col = Color.argb((int) (255 * Math.max(0f, Math.min(1f, a))), Color.red(rgb), Color.green(rgb), Color.blue(rgb));
        GP.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
        GP.setShader(new RadialGradient(x, y, r, new int[]{col, Color.argb((int) (Color.alpha(col) * 0.35f), Color.red(rgb), Color.green(rgb), Color.blue(rgb)), 0},
                new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, GP);
        GP.setShader(null);
        GP.setXfermode(null);
    }

    /**
     * Hangs string k between (ax,ay) and (bx,by). lit 0..1 fades the lit picture and the glows in; tri = 1 gives
     * saffron / white / green lights; dim 0..1 darkens the unlit picture (the scene is darker at night).
     */
    static void draw(Canvas c, Context ctx, int k, float ax, float ay, float bx, float by, float lit, int tri, float dim, long now) {
        drawCut(c, ctx, k, ax, ay, bx, by, 1f, lit, tri, dim, now);
    }

    /**
     * Cut rule: a string cut to `frac` (0.75 = three quarters) keeps the bulb size of the FULL string; only the first `frac`
     * of it is shown, from (ax,ay) to (bx,by). So a piece cut from a string of length L shows bulbs exactly as big as an
     * uncut string of length L, and cut pieces can be mixed with uncut ones without the bulb sizes jumping.
     */
    static void drawCut(Canvas c, Context ctx, int k, float ax, float ay, float bx, float by, float frac, float lit, int tri, float dim, long now) {
        if (frac < 1f) {
            drawFull(c, ctx, k, ax, ay, ax + (bx - ax) / frac, ay + (by - ay) / frac, frac, lit, tri, dim, now);
        } else {
            drawFull(c, ctx, k, ax, ay, bx, by, 1f, lit, tri, dim, now);
        }
    }

    private static void drawFull(Canvas c, Context ctx, int k, float ax, float ay, float bx, float by, float frac, float lit, int tri, float dim, long now) {
        Bitmap off = bmp(ctx, k, 0);
        loadPts(ctx);
        if (off == null || pts[k] == null) return;
        float len = (float) Math.hypot(bx - ax, by - ay);
        float ang = (float) Math.toDegrees(Math.atan2(by - ay, bx - ax));
        float h = len * off.getHeight() / off.getWidth();
        c.save();
        c.translate(ax, ay);
        c.rotate(ang);
        if (frac < 1f) c.clipRect(-1000f, -1000f, len * frac, 1000f);
        R.set(0f, 0f, len, h);
        BP.setAlpha(255);
        BP.setColorFilter(dim > 0.01f ? new android.graphics.LightingColorFilter(
                Color.rgb((int) (255 - 110 * dim), (int) (255 - 110 * dim), (int) (255 - 80 * dim)), 0) : null);
        c.drawBitmap(off, null, R, BP);
        BP.setColorFilter(null);
        if (lit > 0.01f) {
            Bitmap on = bmp(ctx, k, 1);
            if (on != null) {
                BP.setAlpha((int) (255 * Math.min(1f, lit * (tri == 1 ? 0.5f : 1f))));
                c.drawBitmap(on, null, R, BP);
                BP.setAlpha(255);
            }
            float[][] q = pts[k];
            float gr = Math.max(glowMin, h * 0.55f) * glowRad;
            for (int i = 0; i < q.length; i++) {
                float x = q[i][0] * len, y = q[i][1] * h;
                float tw = 0.72f + 0.28f * (float) Math.sin(now / 330.0 + i * 1.9);
                if (tri == 1) {
                    glow(c, x, y, gr, TRI[(i + (int) (now / 900L)) % 3], 0.85f * lit * tw * glowAlpha);
                } else {
                    glow(c, x, y, gr, 0xFFFFD890, 0.5f * lit * tw * glowAlpha);
                }
                glow(c, x, y, gr * 0.3f, 0xFFFFFFFF, 0.5f * lit * tw * glowAlpha);
            }
        }
        c.restore();
    }

    /**
     * Highway: the tea stall gets a string of lights under its roof on every festival; the shrine gets lights on three sides (along the top and
     * down both sides, like the notice board) on Diwali only. Drawn in the scene's own picture pixels (st / sh = the props' boxes from
     * StackScene.propBox, s = design units per picture pixel) from inside StackScene, so the traffic passes in front of them. The view is far, so
     * at night the glow is kept small and faint: the bulbs themselves must stay clearly visible.
     */
    static void highway(Canvas c, Context ctx, float[] st, float[] sh, float s, String pal, String decor, float nightK, long now) {
        String pl = pal == null ? "" : pal, dc = decor == null ? "" : decor;
        int a, b, tri = 0;
        if ("TRICOLOUR".equals(dc) || "TRICOLOUR".equals(pl)) { a = GLOBE; b = FILAMENT; tri = 1; }
        else if ("DIWALI".equals(pl)) { a = LANTERN; b = DROP; }
        else if ("CHRISTMAS".equals(pl)) { a = STAR_B; b = DROP; }
        else if ("EID".equals(pl)) { a = MOON; b = STAR_A; }
        else { a = FILAMENT; b = STAR_A; }
        float lit = Math.max(Math.min(1f, Math.max(0f, (nightK - 0.1f) / 0.5f)), 0.35f);
        float dim = 0.5f * nightK;
        glowMin = 5f / s;        // the 5-unit minimum is in design units, the canvas here is in picture pixels
        glowAlpha = farGlowAlpha;
        glowRad = farGlowRad;
        try {
            if (st != null) {
                // tea stall, every festival: three strands side by side along the roof edge
                float[] xs = {6f, 46f, 86f, 125f};
                float y = st[1] + 14.5f;
                for (int i = 0; i < 3; i++) draw(c, ctx, a, st[0] + xs[i], y, st[0] + xs[i + 1], y, lit, tri, dim, now);
            }
            if (sh != null && "DIWALI".equals(pl)) {
                // temple, Diwali only, on the body: two sides full length, the top is two pieces cut (fraction worked out) from a string of the side
                // string's length so that the bulbs on all three sides are the same size
                float xl = sh[0] + 17f, xr = sh[0] + 49.5f, yt = sh[1] + 35f, yb = sh[1] + 60f;
                float side = yb - yt - 1f;   // (one picture pixel less, as on page 1)
                float t0 = sh[0] + 12f, t1 = sh[0] + 54f, mid = (t0 + t1) / 2f;
                float piece = (t1 - t0) / 2f, frac = Math.min(1f, piece / side);
                drawCut(c, ctx, a, mid - piece, yt, mid, yt, frac, lit, 0, dim, now);
                drawCut(c, ctx, a, mid, yt, mid + piece, yt, frac, lit, 0, dim, now);
                draw(c, ctx, b, xl, yt + 1f, xl, yb, lit, 0, dim, now);   // left side
                draw(c, ctx, b, xr, yb, xr, yt + 1f, lit, 0, dim, now);   // right side
            }
        } finally {
            glowMin = 5f;
            glowAlpha = 1f;
            glowRad = 1f;
        }
    }

    /** Night glow of the highway strings (far view): this much of the page-1 strength and width. */
    static float farGlowAlpha = 0.3f, farGlowRad = 0.6f;
}
