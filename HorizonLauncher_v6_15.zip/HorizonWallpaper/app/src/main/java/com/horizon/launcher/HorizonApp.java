package com.horizon.launcher;

import android.app.Application;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Remembers the reason of a crash so that the next start can show it instead of silently stopping. */
public class HorizonApp extends Application {

    static File crashFile(android.content.Context c) {
        return new File(c.getFilesDir(), "crash.txt");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // the beach pictures come in a separate scene zip: with them ANDAMAN BEACH is the layered beach, without them the old Andaman scene stays
        try {
            String[] need = {"sc_bc_0.webp", "sc_bc_1.webp", "sc_bc_g.webp", "sc_bc_2.webp"};
            boolean all = true;
            for (String n : need) {
                try { getAssets().open(n).close(); } catch (Throwable t) { all = false; break; }
            }
            StackScene.beachReady = all;
        } catch (Throwable ignored) { }
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        final File f = crashFile(this);
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    String s = "v5.0 crash in thread " + t.getName() + "\n" + sw;
                    if (s.length() > 6000) s = s.substring(0, 6000);
                    FileOutputStream out = new FileOutputStream(f);
                    out.write(s.getBytes("UTF-8"));
                    out.close();
                } catch (Throwable ignored) { }
                if (old != null) old.uncaughtException(t, e);
            }
        });
    }
}
