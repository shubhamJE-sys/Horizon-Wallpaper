package com.horizon.launcher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends Activity implements PosterView.Host {

    private static final int INK = Color.parseColor("#1B1B1A");
    private static final int RED = Color.parseColor("#C8382C");
    private static final int CREAM = Color.parseColor("#ECE3D0");

    private static class AppEntry {
        String label;
        ComponentName component;
    }

    private PosterView poster;
    private FrameLayout root;
    private LinearLayout drawer;
    private ListView list;
    private TextView countView;
    private Typeface bebas, roboto;
    private final List<AppEntry> apps = new ArrayList<AppEntry>();
    private BaseAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(CREAM));
        try {
            bebas = Typeface.createFromAsset(getAssets(), "BebasNeue.ttf");
            roboto = Typeface.createFromAsset(getAssets(), "Roboto-Regular.ttf");
        } catch (Exception e) {
            bebas = Typeface.DEFAULT_BOLD;
            roboto = Typeface.DEFAULT;
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(CREAM);
        poster = new PosterView(this, this);
        root.addView(poster, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildDrawer();
        root.addView(drawer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawer.setVisibility(View.GONE);
        setContentView(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int bottom = insets.getSystemWindowInsetBottom();
                poster.setBottomInset(bottom);
                drawer.setPadding(dp(22), dp(52), dp(22), bottom + dp(8));
                return insets;
            }
        });
        root.requestApplyInsets();

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, new OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            // A launcher never exits: back closes the app list or the music panel.
                            if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
                            else poster.closePanel();
                        }
                    });
        }
        hideBars();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    protected void onResume() {
        super.onResume();
        poster.start();
        hideBars();
    }

    @Override
    protected void onPause() {
        poster.stop();
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Pressing Home again returns to the poster.
        if (drawer.getVisibility() == View.VISIBLE) closeDrawer();
        poster.closePanel();
    }

    // ---------- app list ----------

    private void buildDrawer() {
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setBackgroundColor(CREAM);
        drawer.setClickable(true);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.BOTTOM);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("ALL APPS");
        title.setTypeface(bebas);
        title.setTextSize(52f);
        title.setTextColor(INK);
        title.setLetterSpacing(0.03f);
        title.setIncludeFontPadding(false);
        titleBox.addView(title);
        countView = new TextView(this);
        countView.setTypeface(roboto);
        countView.setTextSize(10f);
        countView.setTextColor(RED);
        countView.setLetterSpacing(0.3f);
        titleBox.addView(countView);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView close = new TextView(this);
        close.setText("CLOSE");
        close.setTypeface(bebas);
        close.setTextSize(24f);
        close.setTextColor(RED);
        close.setLetterSpacing(0.1f);
        close.setPadding(dp(16), dp(12), 0, dp(6));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });
        header.addView(close, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        drawer.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View rule = new View(this);
        rule.setBackgroundColor(INK);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(2));
        rp.topMargin = dp(10);
        drawer.addView(rule, rp);

        list = new ListView(this);
        list.setDivider(new ColorDrawable(Color.parseColor("#33000000")));
        list.setDividerHeight(1);
        list.setVerticalScrollBarEnabled(false);
        list.setFastScrollEnabled(false);
        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return apps.size();
            }

            @Override
            public Object getItem(int position) {
                return apps.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView tv;
                if (convertView instanceof TextView) {
                    tv = (TextView) convertView;
                } else {
                    tv = new TextView(HomeActivity.this);
                    tv.setTypeface(bebas);
                    tv.setTextSize(30f);
                    tv.setTextColor(INK);
                    tv.setLetterSpacing(0.06f);
                    tv.setPadding(0, dp(11), 0, dp(11));
                    tv.setSingleLine(true);
                }
                tv.setText(apps.get(position).label.toUpperCase(Locale.getDefault()));
                return tv;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                launch(apps.get(position));
            }
        });
        drawer.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        for (ResolveInfo r : found) {
            if (r.activityInfo == null) continue;
            if (getPackageName().equals(r.activityInfo.packageName)) continue;
            AppEntry a = new AppEntry();
            a.label = String.valueOf(r.loadLabel(pm));
            a.component = new ComponentName(r.activityInfo.packageName, r.activityInfo.name);
            apps.add(a);
        }
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry x, AppEntry y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });
        countView.setText(apps.size() + " APPS");
        adapter.notifyDataSetChanged();
    }

    private void launch(AppEntry a) {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setComponent(a.component);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(i);
        } catch (Exception ignored) { }
        closeDrawer();
    }

    @Override
    public void openDrawer() {
        loadApps();
        list.setSelection(0);
        drawer.setVisibility(View.VISIBLE);
    }

    private void closeDrawer() {
        drawer.setVisibility(View.GONE);
    }
}
