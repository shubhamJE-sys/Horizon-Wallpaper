package com.horizon.wallpaper;

import android.service.notification.NotificationListenerService;

/**
 * Intentionally empty. Enabling this listener in system settings is what lets the
 * wallpaper read the "now playing" media session (title, artist, cover, controls).
 */
public class MediaListenerService extends NotificationListenerService {
}
