package com.horizon.wallpaper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.service.wallpaper.WallpaperService;
import android.text.format.DateFormat;
import android.view.SurfaceHolder;

import java.io.InputStream;
import java.util.Calendar;
import java.util.Locale;

/**
 * Retro poster live wallpaper. The background image (design size 360x804 units,
 * stored at 4x) has empty frames; this service draws the live clock, date, day,
 * greeting, day-of-year and battery into them.
 */
public class HorizonWallpaperService extends WallpaperService {

    private static final float DW = 360f, DH = 804f;
    private static final int INK = Color.parseColor("#1B1B1A");
    private static final int RED = Color.parseColor("#C8382C");

    @Override
    public Engine onCreateEngine() {
        return new PosterEngine();
    }

    private class PosterEngine extends Engine {
        private Bitmap bg;
        private Typeface bebas, roboto;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private int width, height;
        private int batteryPct = 100;
        private boolean charging = false;
        private boolean receiving = false;

        private final BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                    readBattery(intent);
                }
                draw();
            }
        };

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            try {
                InputStream in = getAssets().open("live_bg.jpg");
                bg = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Exception ignored) { }
            try {
                bebas = Typeface.createFromAsset(getAssets(), "BebasNeue.ttf");
                roboto = Typeface.createFromAsset(getAssets(), "Roboto-Regular.ttf");
            } catch (Exception e) {
                bebas = Typeface.DEFAULT_BOLD;
                roboto = Typeface.DEFAULT;
            }
            Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (sticky != null) readBattery(sticky);
        }

        private void readBattery(Intent i) {
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (level >= 0 && scale > 0) batteryPct = Math.round(level * 100f / scale);
            int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL;
        }

        private void startReceiving() {
            if (receiving) return;
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_TIME_TICK);
            f.addAction(Intent.ACTION_TIME_CHANGED);
            f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            f.addAction(Intent.ACTION_BATTERY_CHANGED);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(receiver, f);
            }
            receiving = true;
        }

        private void stopReceiving() {
            if (!receiving) return;
            try { unregisterReceiver(receiver); } catch (Exception ignored) { }
            receiving = false;
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            if (visible) {
                startReceiving();
                draw();
            } else {
                stopReceiving();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            width = w;
            height = h;
            draw();
        }

        @Override
        public void onDestroy() {
            stopReceiving();
            super.onDestroy();
        }

        // ---------- drawing ----------

        private void draw() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null && width > 0) render(c);
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Exception ignored) { }
                }
            }
        }

        private void render(Canvas c) {
            c.drawColor(Color.parseColor("#ECE3D0"));
            float s = Math.max(width / DW, height / DH);
            float dx = (width - DW * s) / 2f;
            float dy = (height - DH * s) / 2f;

            if (bg != null) {
                Matrix m = new Matrix();
                float bs = s * DW / bg.getWidth();
                m.postScale(bs, bs);
                m.postTranslate(dx, dy);
                c.drawBitmap(bg, m, bitmapPaint);
            }

            c.save();
            c.translate(dx, dy);
            c.scale(s, s);
            drawLive(c);
            c.restore();
        }

        private void text(Canvas c, String t, float x, float y, float size, int color,
                          Typeface tf, Paint.Align align, float spacingEm) {
            paint.setTypeface(tf);
            paint.setTextSize(size);
            paint.setColor(color);
            paint.setTextAlign(align);
            paint.setLetterSpacing(spacingEm);
            c.drawText(t, x, y, paint);
        }

        private void drawLive(Canvas c) {
            Calendar cal = Calendar.getInstance();
            boolean h24 = DateFormat.is24HourFormat(HorizonWallpaperService.this);
            int hour = cal.get(Calendar.HOUR_OF_DAY);
            int hh = h24 ? hour : ((hour % 12 == 0) ? 12 : hour % 12);
            int mm = cal.get(Calendar.MINUTE);

            // Clock (top-left frame)
            text(c, String.format(Locale.US, "%02d", hh), 14, 108, 96, INK, bebas, Paint.Align.LEFT, 0f);
            text(c, String.format(Locale.US, "%02d", mm), 14, 182, 96, RED, bebas, Paint.Align.LEFT, 0f);

            // Date next to clock
            String mon = cal.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
            text(c, mon, 112, 62, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            text(c, String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), 112, 88, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            text(c, String.valueOf(cal.get(Calendar.YEAR)), 112, 114, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            paint.setColor(INK);
            paint.setStrokeWidth(1.5f);
            c.drawLine(112, 126, 160, 126, paint);
            if (!h24) {
                text(c, hour < 12 ? "AM" : "PM", 112, 144, 10, RED, roboto, Paint.Align.LEFT, 0.25f);
            }

            // Day name, vertical (right column of top frame)
            String day = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
            float size = 62f;
            paint.setTypeface(bebas);
            paint.setTextSize(size);
            paint.setLetterSpacing(0.02f);
            float wdt = paint.measureText(day);
            if (wdt > 182f) size = size * 182f / wdt;
            float cap = size * 0.70f;
            c.save();
            c.translate(266f + cap / 2f, 228f);
            c.rotate(-90f);
            text(c, day, 0, 0, size, INK, bebas, Paint.Align.LEFT, 0.02f);
            c.restore();

            // Greeting (media frame)
            String greet = hour < 12 ? "GOOD MORNING" : (hour < 17 ? "GOOD AFTERNOON" : (hour < 21 ? "GOOD EVENING" : "GOOD NIGHT"));
            float gs = 40f;
            paint.setTypeface(bebas);
            paint.setTextSize(gs);
            paint.setLetterSpacing(0.03f);
            float gw = paint.measureText(greet);
            if (gw > 205f) gs = gs * 205f / gw;
            text(c, greet, 18, 524, gs, INK, bebas, Paint.Align.LEFT, 0.03f);
            paint.setColor(RED);
            c.drawRect(18, 534, 54, 536.5f, paint);

            // Day of year (left small frame)
            text(c, String.valueOf(cal.get(Calendar.DAY_OF_YEAR)), 16, 590, 42, INK, bebas, Paint.Align.LEFT, 0f);
            text(c, "DAY OF THE YEAR", 16, 603, 5.6f, INK, roboto, Paint.Align.LEFT, 0.25f);

            // Battery (right frame)
            drawBattery(c);
        }

        private void drawBattery(Canvas c) {
            float x = 146, y = 562, w = 52, h = 22;
            paint.setColor(INK);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.8f);
            c.drawRoundRect(x, y, x + w, y + h, 3, 3, paint);
            paint.setStyle(Paint.Style.FILL);
            c.drawRect(x + w, y + 6, x + w + 4, y + h - 6, paint);
            int segs = Math.max(batteryPct > 0 ? 1 : 0, Math.round(batteryPct / 20f));
            paint.setColor(RED);
            float sw = (w - 8) / 5f;
            for (int i = 0; i < segs && i < 5; i++) {
                float sx = x + 3 + i * sw;
                c.drawRect(sx, y + 3, sx + sw - 2, y + h - 3, paint);
            }
            text(c, batteryPct + "%", 342, 592, 44, INK, bebas, Paint.Align.RIGHT, 0f);
            text(c, charging ? "CHARGING" : "ON BATTERY", 146, 593, 5.6f, INK, roboto, Paint.Align.LEFT, 0.2f);
        }
    }
}
