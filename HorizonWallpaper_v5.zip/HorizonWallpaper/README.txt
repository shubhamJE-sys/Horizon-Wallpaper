HOW TO GET THE APK (free, no coding)
1. Make a free account at github.com and tap New repository (any name, Public or Private).
2. Choose "uploading an existing file" and upload EVERYTHING from this folder
   (the .github folder, app folder, build.gradle, settings.gradle, gradle.properties).
   Tip: on a PC you can drag the whole folder contents in. Hidden ".github" folder must be included.
3. Commit. Open the Actions tab -> "Build APK" runs by itself (about 3-5 minutes).
4. Open the finished run -> Artifacts -> HorizonWallpaper-apk -> download, unzip, install app-debug.apk
   (allow "Install unknown apps" for your browser/file manager when asked).
5. Open "Horizon Wallpaper" from your app list -> tap Set wallpaper.
