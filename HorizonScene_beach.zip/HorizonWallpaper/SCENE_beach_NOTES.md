# Beach scene (replaces ANDAMAN BEACH from v6.14)

Files (all under HorizonWallpaper/app/src/main/assets, drawn by `StackScene` branch `beach`):
- `sc_bc_0` far islands, `sc_bc_1` sea (mirrored upward so the horizon sits at about 43 % of the scene), `sc_bc_g` sand + foam, `sc_bc_2` foreground palm/grass/rocks, `bc_isle` palm island with huts (attached to the left edge)
- `bc_p0..7` props: 0 blue umbrella, 1 green umbrella, 2 palm (unused), 3 lounger, 4 surfboard, 5 hut (unused), 6 towel + bag + hat, 7 rowboat near the huts
- `bc_w0..2` girl on the lounger, `bc_t0..3` girl lying on the towel, `bc_j0..1` jump sheets (6 x 4 cells of 24 frames, 10 fps: slim girl, fuller girl)
- Mermaid on her rock: `bc_m0..2` (first look, shell top), `bc_ml0..2` long hair, `bc_ms0..3` short hair; `bc_s0..6` the mermaid ashore on a towel and sand patch
- Optional `bc_mr.webp` (640 x 464, same frame as the `bc_m*` pictures: the rock and water with nobody on it). Not made yet; without it the rock fades with her when she goes ashore.
- Cut frame of the mermaid pictures: source px (158, 68)-(1186, 814), 640 px wide; sprite drawn 380 scene px wide, bottom at y 690, x 720.

Behaviour:
- Idle: lounger empty, towel set as is, no mermaid on the beach.
- Water: sun/moon shimmer and reflection on the visible sea; sun and moon use the app's normal sky arcs (horizon about LAKE_Y).
- 3 taps = girl cycle, started once and then running by itself (more taps are not needed, a further triple tap only skips to the next picture): lounger woman 1, 2, 3, then the woman lying on the towel 1-4, then round again, 1.8 s cross-fades. Each lounger picture lasts 50 s: she rests 24 s, gets up, walks to the sea, jumps 5 times in a loop (GIF frames, 2.4 s each), stands, dives away (19.5 s), returns and lies down again at 24 s of her trip. Each towel picture lasts 16 s.
- 4 taps = mermaid cycle, started once and then running by itself (a further four taps only skip to the next look): she fades in with long hair, then short hair, then the shell look, then round again. Short hair and shell top: each picture 24 s on the rock. Long hair: the first picture 24 s, then 5 s of playing with the water by her legs (bc_ml1 and bc_ml2 swap every 280 ms). Then she swims ashore, the 7 towel pictures show 12 s each, and she swims back; looks cross-fade into each other.
- Double tap or locking the phone cancels both cycles; both can run together.
- The pictures that only the cycles use (about 30 MB decoded) are decoded when the first cycle starts.

Pending: empty rock picture, foreground palm hides most of the island's tall palms (option: smaller or moved palm), night tint/glitter check, towel pictures could be larger.
