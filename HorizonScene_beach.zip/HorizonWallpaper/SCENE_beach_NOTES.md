# Beach scene (replaces ANDAMAN BEACH from v6.14)

Files (all under HorizonWallpaper/app/src/main/assets, drawn by `StackScene` branch `beach`):
- `sc_bc_0` far islands, `sc_bc_1` sea (mirrored upward so the horizon sits at about 43 % of the scene), `sc_bc_g` sand + foam, `sc_bc_2` foreground palm/grass/rocks, `bc_isle` palm island with huts (attached to the left edge)
- `bc_p0..7` props: 0 blue umbrella, 1 green umbrella, 2 palm (unused), 3 lounger, 4 surfboard, 5 hut (unused), 6 towel + bag + hat, 7 rowboat near the huts
- `bc_w0..2` girl on the lounger, `bc_t0..3` girl lying on the towel, `bc_j0..1` jump sheets (6 x 4 cells of 24 frames, 10 fps: slim girl, fuller girl)
- Mermaid on her rock: `bc_m0..2` (first look, shell top), `bc_ml0..2` long hair, `bc_ms0..3` short hair; `bc_s0..6` the mermaid ashore on a towel and sand patch
- Optional `bc_mr.webp` (640 x 464, same frame as the `bc_m*` pictures: the rock and water with nobody on it). Not made yet; without it the rock fades with her when she goes ashore.
- Cut frame of the mermaid pictures: source px (158, 68)-(1186, 814), 640 px wide; sprite drawn 380 scene px wide, bottom at y 690, x 720.

Behaviour:
- Idle: lounger empty, towel set as is, the mermaid sits on her rock; her three pictures change every 24 s (1.8 s cross-fade).
- Water: sun/moon shimmer and reflection on the visible sea; sun and moon use the app's normal sky arcs (horizon about LAKE_Y).
- 3 taps = girl cycle: each triple tap steps to the next girl (3 on the lounger, then 4 on the towel, then empty). A girl on the lounger rests 34 s, gets up, walks to the sea, jumps (GIF frames), stands in the water, dives away (14.5 s), returns and lies down again; 60 s loop.
- 4 taps = mermaid cycle: shell look, then long hair, then short hair, then shell look. In the long and short looks she changes pictures every 24 s on the rock, then swims ashore and the 7 towel pictures show 12 s each, then she swims back.
- Double tap or locking the phone cancels both cycles; both can run together.
- The pictures that only the cycles use (about 30 MB decoded) are decoded when the first cycle starts.

Pending: empty rock picture, foreground palm hides most of the island's tall palms (option: smaller or moved palm), night tint/glitter check, towel pictures could be larger.
