# Horizon Launcher - code, structure and rules of the app (v6.14)

Package `com.horizon.launcher`, Android 8+ (minSdk 26, targetSdk 36), phones only, no AndroidX, no extra permissions.
Signed with the fixed key `app/horizon.keystore` (never change or lose it; md5 9d0706916a7a18e7fd293b1e6be730f6).

## How the zips fit together
- `HorizonLauncher_v6_14.zip` (this one): the whole project WITHOUT the beach pictures.
- `HorizonScene_beach.zip`: only the beach pictures, laid out as `HorizonWallpaper/app/src/main/assets/...`.
- Repo root = both zips + `.github/workflows/build.yml` (the new one in `repo_workflow/`). The workflow unpacks the newest code zip
  (every .zip whose name does not start with `HorizonScene_`), then every `HorizonScene_*.zip` on top of it, then builds.
- Without the scene zip the app still builds and runs: ANDAMAN BEACH then shows the old scene (see `StackScene.beachReady`).
- Each zip is under GitHub's 25 MB web-upload limit (code about 21.5 MB, scene about 8.6 MB).

## Project structure (app/src/main/java/com/horizon/launcher)
- `HomeActivity` home + lock wallpaper host; `PosterView` page 1 (poster home, taps, sky, scene box); `RoomView` page 2 (retro room, window, item shelves); `LockArt` lock-screen picture.
- Scenes: `Look` (daily pick: colour scheme, festival, scene ids/names, texts), `SceneRender` (loads a scene's layers), `StackScene` (layered scenes in a 1364x944 scene space:
  city, highway, dunes/oasis, lake, beach), `Boats`, `Decor` (festival diyas), `StringLights`, `Festivals`, `ContentPack`, `ThemePack` (IMPORT THEME zip: sky, sun, stars, water, moon parts).
- Sky: `Sky`, `SkyArt` (painted/real skies, stars, photo sun), `SkyEngine`, `Moon`, `Astro`, `Body` (sun/moon positions for the chosen city), `Loc`, `Palette`, `Texts`, `InfoCards`, `IconStyler`, `SignalWatcher`, `WaterExt`.
- Assets: `app/src/main/assets` (scene layers `sc_*`, props, room, skies, etc.).

## Rules of the app (decided by the user)
- Never build or send a new version until told ("go" / "make next version"); keep a list of queued edits. Mock-ups are rendered from the real app code.
- Page 1: four equal 58-unit rows, grid lines 1.5, version mark right under the grid, swipe down splits (left half notifications, right half quick settings), swipe up = All Apps, greeting = news, Phone tap = dialer home (hold = Contacts).
- Text: one colour per text (white or black by contrast, thin opposite soft outline under 3:1). Never 5-point stars; sun is drawn in code.
- Layered scenes: solid down to the imaginary line (top of the greeting row), fading to nothing by the middle of GOOD MORNING; no streaks or mirrored images under a scene; no scene top may be cut.
- Page 2 (room) is rebuilt from item layers, never patched; window shows the lower 70% scene / 30% sky, original colours, weather applies.
- New themes and scenes come in through IMPORT THEME first; scenes are wired in only when the user says the set is complete. ANDAMAN BEACH = the new beach scene (v6.14).
- Phone use strains eyes: calm, informative at a glance; avoid extra permissions; works on every phone (curved corners and camera cut-out respected).

## Beach scene taps (page 1, beach shown)
- 2 taps cancel both cycles; locking the phone cancels them too. 3 taps = girl cycle, 4 taps = mermaid cycle; both can run together.
- Taps are counted within 550 ms; the action is decided after the last tap (3 taps are not mistaken for the start of 4).
- Details and timings: see `SCENE_beach_NOTES.md` inside `HorizonScene_beach.zip`.
