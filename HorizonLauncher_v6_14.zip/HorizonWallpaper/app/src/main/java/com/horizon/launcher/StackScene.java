package com.horizon.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.io.InputStream;

/**
 * The layered Classic scenes ("city" and "highway"): every layer is a transparent picture already placed in the
 * 1364x944 picture space, drawn back to front, with traffic and people that move between the layers.
 *
 * City:    far skyline + towers, lit windows (night), shop-houses, road with street furniture; vehicles drive on the
 *          road, people walk on the pavement.
 * Highway: mountains + valley, road on the slope, foreground trees; vehicles drive between the road and the trees
 *          (the trees at the sides of the road cover them as they enter and leave).
 * A rare Meteor motorbike overtakes everything (every 40 to 60 minutes, or on a double tap on the scene).
 */
final class StackScene {

    static final int W = 1364, H = 944;
    private static final long PERIOD = 50L * 60000L;
    private static final long METEOR_MS = 3000L;
    private static volatile long manualStart = -1000000L;

    /** Set by the caller for the length of one draw: a lamp festival (decor DIYA) puts small diyas along the highway's road edge. */
    static volatile boolean diyaRoad = false;
    /** Sun or moon over the water: {x, y in design units, strength 0..1, 1 if moon, radius in design units, warm 0..1}; null = nothing to reflect. Set by the screen before drawing. */
    static volatile float[] refl = null;
    private float cl, cs, cty;
    private Bitmap wMask;
    private float wTop, wBot, wLx, wRx;
    private boolean wTried;
    private static final int WSTEP = 6;
    private Bitmap[] dyB, flB;
    private float[][] dyTip;
    final boolean city;
    private boolean lake;    // the mountain lake: far peaks, forest, still water with a rowing boat, reeds in front
    private boolean beach;   // the tropical beach: far islands, a still sea, a foam shoreline, props on the sand, a palm in front
    private boolean oasis;   // the desert oasis: dunes, palms and a pool, with a caravan camp and a fire in front
    private Bitmap b0, bWin, b1, b1r, b2;   // b1r: the highway's guardrail and wall, drawn in front of the traffic
    private Bitmap[][] mermaid = new Bitmap[0][];   // beach: the mermaid on her rock in the sea: [0] shell top, [1] long hair, [2] short hair; each set changes picture by itself
    /** True when the beach pictures (sc_bc_*, bc_*: the separate scene zip) are in the app; then ANDAMAN BEACH is this layered scene, otherwise the old one. */
    static volatile boolean beachReady = false;
    private android.content.Context lazyCtx;
    private boolean animLoaded;
    private Bitmap[] shore = new Bitmap[0];   // beach: the mermaid ashore, as a woman on her towel on a sand patch (7 pictures)
    private Bitmap[] jump = new Bitmap[0];   // beach: the girl from the lounger jumping into the sea (two 6x4 sheets of 24 frames, 100 ms each)
    private Bitmap rockEmpty;   // beach: her rock and water without her (optional art); without it the whole picture fades while she is ashore
    private final float[] ms = new float[8];   // beach: what the mermaid shows right now (see merState)
    private Bitmap[] lying = new Bitmap[0];   // beach: the woman lying on the towel (states 4..6)
    private Bitmap[] woman = new Bitmap[0];   // beach: the woman on the lounger, three pictures that a triple tap cycles through
    private Bitmap isle;   // beach: the palm island, standing on its own in the sea
    private Bitmap[] veh = new Bitmap[0];
    private Bitmap[] ppl = new Bitmap[0];
    private Bitmap[] walk = new Bitmap[0];   // animated 12-frame walkers (city): 0 man with briefcase, 1 woman with bag, 2 golden retriever
    private Bitmap[] props = new Bitmap[0];
    private Bitmap meteor;
    private float lampX = 0.97f, lampY = 0.46f;   // where the Meteor's headlight sits in its picture

    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint plain = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint fade = new Paint();
    private Paint tint;

    private StackScene(boolean city) { this.city = city; }

    private static Bitmap dec(Context ctx, String name) {
        try {
            InputStream in = ctx.getAssets().open(name);
            try { return BitmapFactory.decodeStream(in); } finally { in.close(); }
        } catch (Throwable t) {
            return null;
        }
    }

    private static Bitmap[] decAll(Context ctx, String prefix, int n) {
        Bitmap[] out = new Bitmap[n];
        for (int i = 0; i < n; i++) out[i] = dec(ctx, prefix + i + ".webp");
        return out;
    }

    /** Decodes the pictures that only the tap cycles use, once, when the first cycle starts. */
    private void animLoad() {
        if (animLoaded || lazyCtx == null) return;
        animLoaded = true;
        woman = decAll(lazyCtx, "bc_w", 3);
        lying = decAll(lazyCtx, "bc_t", 4);
        mermaid[1] = decAll(lazyCtx, "bc_ml", 3);
        mermaid[2] = decAll(lazyCtx, "bc_ms", 4);
        shore = decAll(lazyCtx, "bc_s", 7);
        jump = decAll(lazyCtx, "bc_j", 2);
    }

    static StackScene load(Context ctx, String id) {
        boolean city = "city".equals(id);
        StackScene s = new StackScene(city);
        if ("lake".equals(id)) {
            s.lake = true;
            s.b0 = dec(ctx, "sc_lk_0.webp");    // far: snow peaks
            s.b1 = dec(ctx, "sc_lk_1.webp");    // mid: the forest on the far shore
            s.b1r = dec(ctx, "sc_lk_2.webp");   // near: the water with the painted mirror of the forest and peaks
            s.b2 = dec(ctx, "sc_lk_3.webp");    // foreground: pines, reeds and rocks at the two sides
            // 0 empty boat (moored at the shore), 1 boat with the couple, 2 wake (one V), 3 bow wave, 4 circular ripples (one ring picture), 5 waterline lap
            s.props = new Bitmap[6];
            s.props[0] = dec(ctx, "lk_b0.webp");
            s.props[1] = dec(ctx, "lk_b1.webp");
            s.props[2] = dec(ctx, "lk_wake1.webp");
            s.props[3] = dec(ctx, "lk_bow1.webp");
            s.props[4] = dec(ctx, "lk_circ.webp");
            s.props[5] = dec(ctx, "lk_lap1.webp");
            if (s.b0 == null || s.b1 == null || s.b1r == null) return null;
            return s;
        }
        if ("beach".equals(id)) {
            s.beach = true;
            s.b0 = dec(ctx, "sc_bc_0.webp");    // far islands
            s.b1 = dec(ctx, "sc_bc_1.webp");    // the sea with the palm island
            s.b1r = dec(ctx, "sc_bc_g.webp");   // sand and the foam of the shoreline
            s.b2 = dec(ctx, "sc_bc_2.webp");    // palm, grass and rocks in front
            s.props = decAll(ctx, "bc_p", 8);
            // only what is always on show is decoded now; the pictures that a tap cycle needs (about 30 MB) are decoded when the first cycle starts
            s.woman = new Bitmap[3];
            s.lying = new Bitmap[4];
            s.mermaid = new Bitmap[][] { decAll(ctx, "bc_m", 3), new Bitmap[3], new Bitmap[4] };
            s.shore = new Bitmap[7];
            s.jump = new Bitmap[2];
            s.lazyCtx = ctx.getApplicationContext();
            s.rockEmpty = dec(ctx, "bc_mr.webp");
            s.isle = dec(ctx, "bc_isle.webp");   // the palm island with its huts and sand, cut out of the sea picture
            if (s.b0 == null || s.b1 == null || s.b1r == null) return null;
            return s;
        }
        if ("oasis".equals(id)) {
            s.oasis = true;
            s.b0 = dec(ctx, "sc_oa_0.webp");
            s.b1 = dec(ctx, "sc_oa_1.webp");
            s.b1r = dec(ctx, "sc_oa_g.webp");   // the sand ridge in front of the pool, the camp stands on it
            s.b2 = dec(ctx, "sc_oa_2.webp");    // palms and rocks at the two sides, in front of the camp
            // 0 fire pit, 1 the burning bonfire, 4-7 people, 8-11 camels
            s.props = new Bitmap[14];
            s.props[0] = dec(ctx, "oa_pit.webp");
            s.props[1] = dec(ctx, "oa_fire.webp");   // the same pit with its bonfire burning
            s.props[12] = dec(ctx, "oa_wind.webp");    // a gust of sand blowing low over the ground
            s.props[13] = dec(ctx, "oa_devil.webp");   // a sand whirlwind far out on the dunes
            for (int i = 0; i < 4; i++) { s.props[4 + i] = dec(ctx, "oa_p" + i + ".webp"); s.props[8 + i] = dec(ctx, "oa_c" + i + ".webp"); }
            if (s.b0 == null || s.b1 == null) return null;
            return s;
        }
        if (city) {
            s.b0 = dec(ctx, "sc_city_0.webp");
            s.bWin = dec(ctx, "sc_city_win.webp");
            s.b1 = dec(ctx, "sc_city_1.webp");
            s.b2 = dec(ctx, "sc_city_2.webp");
            s.veh = decAll(ctx, "spr_cv", 18);
            s.ppl = decAll(ctx, "spr_cp", 12);
            s.walk = new Bitmap[]{dec(ctx, "cw_man.webp"), dec(ctx, "cw_wom.webp"), dec(ctx, "cw_dog.webp")};   // 12-frame walk cycles: man, woman, dog
        } else {
            s.b0 = dec(ctx, "sc_hw_0.webp");
            s.b1 = dec(ctx, "sc_hw_1.webp");
            s.b1r = dec(ctx, "sc_hw_1r.webp");
            s.b2 = dec(ctx, "sc_hw_2.webp");
            s.veh = decAll(ctx, "spr_hv", 8);
            s.props = decAll(ctx, "spr_hp", 5);
            s.dyB = decAll(ctx, "diya_", 6);
            s.flB = decAll(ctx, "flame_", 6);
            s.dyTip = new float[6][2];
            for (int i = 0; i < 6; i++) {
                s.dyTip[i][0] = 0.5f; s.dyTip[i][1] = 0.1f;
                Bitmap d = s.dyB[i];
                if (d == null) continue;
                outer:
                for (int y = 0; y < d.getHeight(); y++) {
                    long sx = 0; int n = 0;
                    for (int x = 0; x < d.getWidth(); x++) if ((d.getPixel(x, y) >>> 24) > 140) { sx += x; n++; }
                    if (n > 0) { s.dyTip[i][0] = sx / (float) n / d.getWidth(); s.dyTip[i][1] = (y + 2) / (float) d.getHeight(); break outer; }
                }
            }
        }
        // the highway has its own hero bike (the Meteor with the leather-jacket rider); the old one stays in the city scenes
        s.meteor = city ? dec(ctx, "spr_meteor0.webp") : dec(ctx, "spr_meteor1.webp");
        if (s.meteor == null) s.meteor = dec(ctx, "spr_meteor0.webp");
        s.lampX = city ? 0.97f : 0.83f;
        s.lampY = city ? 0.46f : 0.43f;
        if (s.b0 == null || s.b1 == null) return null;
        return s;
    }

    /** 0 = lounger and towel as they are; 1..3 = the woman on the lounger; 4..7 = the woman lying on the towel (the bag and hat give way). */
    private static volatile int benchPhoto = 0;
    private static volatile boolean beachShown = false;

    /** The mermaid: 0 = shell top, as she sits when nothing was tapped; 1 = long hair, 2 = short hair (these two also come ashore now and then). */
    private static volatile int mermaidLook = 0;
    private static volatile long mermaidSince = 0L, benchSince = 0L;

    /** Triple tap on the beach scene: the lounger shows the next picture (empty, lounger 1-3, towel 1-4, empty ...); while a woman lies on the lounger she now and then walks into the sea and jumps in. False when the scene is not the beach. */
    static boolean cycleBench(long now) {
        if (!beachShown) return false;
        benchPhoto = (benchPhoto + 1) % 8;
        benchSince = now;
        return true;
    }

    /** Four taps on the beach scene: the mermaid changes to the next look (shell top, long hair, short hair); the last two go ashore now and then. */
    static boolean cycleMermaid(long now) {
        if (!beachShown) return false;
        mermaidLook = (mermaidLook + 1) % 3;
        mermaidSince = now;
        return true;
    }

    /** Double tap or locking the phone: both beach cycles stop, the lounger is empty again and the mermaid is back to the first look. True when something was running. */
    static boolean cancelAll() {
        boolean any = benchPhoto != 0 || mermaidLook != 0;
        benchPhoto = 0;
        mermaidLook = 0;
        return any;
    }

    static boolean onBeach() {
        return beachShown;
    }

    /** Double tap on the scene: the Meteor rides past now (ignored while one is already riding). */
    static boolean trigger(long now) {
        if (now - manualStart < METEOR_MS + 4000L) return false;
        manualStart = now;
        return true;
    }

    // ---------- drawing ----------

    /**
     * Width-fit and anchored at the bottom line: the picture is never cropped or enlarged. Whatever height the box has
     * above the picture is sky. Below the line the ground carries on (the last rows of every layer stretched) and fades out.
     */
    void draw(Canvas c, Paint tinted, float l, float r, float top, float bottom, float nightK, long now) {
        float s = (r - l) / W;
        float ty = bottom - H * s;
        float ext = 23f;   // fade length below the line: from the line (0%) to the middle of the greeting text (100%)
        tint = tinted;
        cl = l; cs = s; cty = ty;
        Paint bp = new Paint(tinted);
        bp.setFilterBitmap(true);
        c.save();
        // nothing may show below the end of the fade (the highway layers carry extra ground rows beyond it)
        c.clipRect(l - 100000f, top - 100000f, r + 100000f, bottom + ext);
        c.translate(l, ty);
        c.scale(s, s);
        beachShown = beach;
        if (lake) drawLake(c, bp, nightK, now); else if (beach) drawBeach(c, bp, nightK, now); else if (oasis) drawOasis(c, bp, nightK, now); else if (city) drawCity(c, bp, nightK, now); else drawHighway(c, bp, nightK, now);
        // the ground below the line carries on as a mirrored copy of the scene's own bottom (real texture, no streaks);
        // it dissolves into the panel colour below
        if (city || oasis) {
            // each layer carries on below its own last row (the oasis pictures are 1004 rows tall, the city's 944)
            for (Bitmap b : new Bitmap[]{b0, b1, b1r, b2}) {
                if (b == null) continue;
                float bh = b.getHeight();
                c.save();
                c.clipRect(0f, bh - 0.5f, W, bh + ext / s);
                c.scale(1f, -1f, 0f, bh);
                c.drawBitmap(b, 0f, 0f, bp);
                c.restore();
            }
        }
        // (the highway's layers carry 100 rows of real ground below the line, so it needs no mirrored copy)
        c.restore();
        // one rule for every scene: linear 0% at the imaginary line to 100% at the middle of the greeting text;
        // below that only the sky / panel colour shows
        fade.setShader(new LinearGradient(0f, bottom, 0f, bottom + ext, 0x00000000, 0xFF000000, Shader.TileMode.CLAMP));
        fade.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        c.drawRect(l, bottom, r, bottom + ext + 1f, fade);
        fade.setShader(null);
    }

    /** How far the far layer is raised (picture units) in the oasis and the lake. */
    static final float FAR_UP_OASIS = 45f, FAR_UP_LAKE = 38f;

    /** The far layer moved up by `up`, its last rows stretched down so no gap opens behind the layers in front. */
    private void farLayer(Canvas c, Paint p, Bitmap b, float up) {
        if (b == null) return;
        if (lake) { c.save(); c.translate(0f, -FAR_UP_LAKE); }
        c.drawBitmap(b, 0f, 0f, p);
        int bh = b.getHeight();
        float u = lake ? FAR_UP_LAKE : up;
        if (u > 0f) c.drawBitmap(b, new android.graphics.Rect(0, bh - 2, b.getWidth(), bh),
                new android.graphics.RectF(0f, bh - 1f, b.getWidth(), bh + u + 2f), p);
        if (lake) c.restore();
    }

    private void layer(Canvas c, Paint p, Bitmap b) {
        if (b != null) c.drawBitmap(b, 0f, 0f, p);
    }

    // ---------- the mountain lake ----------

    /** Frame f of a 4x3 sheet, centred on (x, y), drawn w wide and h tall. */
    private void cell(Canvas c, Paint bp, Bitmap sh, int f, float x, float y, float w, float h, float a) {
        if (sh == null || a <= 0.01f) return;
        int cw = sh.getWidth() / 4, ch = sh.getHeight() / 3;
        int sx = (f % 4) * cw, sy = ((f / 4) % 3) * ch;
        bp.setAlpha((int) (255 * Math.min(1f, a)));
        c.drawBitmap(sh, new android.graphics.Rect(sx, sy, sx + cw, sy + ch),
                new android.graphics.RectF(x - w / 2f, y - h / 2f, x + w / 2f, y + h / 2f), bp);
        bp.setAlpha(255);
    }

    /** The wake: its narrow tip (right end of the art) sits on (x, y) at the stern, it trails left len px and fades out along its length. */
    private void wakeV(Canvas c, Paint bp, float x, float y, float len, float a) {
        Bitmap w = props[2];
        if (w == null || a <= 0.01f) return;
        float ky = 0.45f, th = w.getHeight() * ky, tipY = th * 0.52f;
        float l = x - len, top = y - tipY;
        float lt = y - tipY * 1.5f - 2f, lb = y + (th - tipY) * 1.5f + 2f;
        int save = c.saveLayer(l - 2f, lt, x + 2f, lb, null);
        bp.setAlpha((int) (255 * Math.min(1f, a)));
        // like a real wake it spreads out as it trails away: slices that get taller towards the far end
        int n = 12, bw = w.getWidth();
        for (int j = 0; j < n; j++) {
            float fr = (n - 1 - j) / (float) n, hs = 0.6f + 0.9f * fr;
            float dx0 = l + (x - l) * j / n, dx1 = l + (x - l) * (j + 1) / n + 0.8f;
            float t0 = y - tipY * hs;
            c.drawBitmap(w, new android.graphics.Rect(bw * j / n, 0, bw * (j + 1) / n, w.getHeight()),
                    new android.graphics.RectF(dx0, t0, dx1, t0 + th * hs), bp);
        }
        bp.setAlpha(255);
        plain.setShader(new LinearGradient(l, 0f, x, 0f, 0x00000000, 0xFF000000, Shader.TileMode.CLAMP));
        plain.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        c.drawRect(l - 2f, lt, x + 2f, lb, plain);
        plain.setXfermode(null);
        plain.setShader(null);
        c.restoreToCount(save);
    }

    /** Rings spreading out from the tied-up boat: three at a time, each growing and fading; front = only the half below the waterline. */
    private void ripples(Canvas c, Paint bp, float x, float wl, long now, float a, boolean front) {
        Bitmap r = props[4];
        if (r == null || a <= 0.01f) return;
        if (front) { c.save(); c.clipRect(x - 400f, wl + 1f, x + 400f, wl + 120f); }
        for (int i = 0; i < 3; i++) {
            float q = now > 0L ? ((now % 7500L) / 7500f + i / 3f) % 1f : (0.2f + i * 0.3f);
            float w = 250f + 260f * q, h = w * r.getHeight() / r.getWidth();
            float al = Math.min(1f, q * 5f) * (1f - q);
            bp.setAlpha((int) (255 * Math.min(1f, 0.9f * al * a)));
            c.drawBitmap(r, null, new android.graphics.RectF(x - w / 2f, wl + 2f - h / 2f, x + w / 2f, wl + 2f + h / 2f), bp);
        }
        bp.setAlpha(255);
        if (front) c.restore();
    }

    static final float LK_MOOR_X = 430f;

    /** The thin wave strip over the lowest part of the hull, swaying a little. */
    private void lapStrip(Canvas c, Paint bp, float x, float wl, long now, float a) {
        Bitmap l = props[5];
        if (l == null || a <= 0.01f) return;
        float sw = now > 0L ? 3f * (float) Math.sin(now / 900.0) : 0f;
        float w = LK_BW * 1.15f;
        bp.setAlpha((int) (255 * Math.min(1f, a)));
        c.drawBitmap(l, null, new android.graphics.RectF(x - w / 2f + sw, wl - 4f, x + w / 2f + sw, wl + 8f), bp);
        bp.setAlpha(255);
    }

    /** A boat sunk 5 px into the water with its upside-down reflection (45%, fading and rippling) starting at the hull's bottom. */
    private void boatAt(Canvas c, Paint bp, Bitmap b, float hull, float x, float wl, float roll, float a, long now, boolean moving) {
        if (b == null || a < 0.01f) return;
        float sc = LK_BW / b.getWidth(), h = b.getHeight() * sc;
        float yh = h * hull / sc, sl = 5f, q = sl / sc;
        for (int j = 0; j < 10; j++) {
            float sy0 = yh - (j + 1) * q;
            if (sy0 < 0f) break;
            float dx = now > 0L ? (1.6f + (moving ? 2.2f : 0f)) * (float) Math.sin(now / 420.0 + j * 1.2) : 0f;
            bp.setAlpha((int) (255 * a * 0.45f * (1f - 0.07f * j)));
            c.save();
            c.scale(1f, -1f, 0f, wl);
            c.drawBitmap(b, new android.graphics.Rect(0, (int) sy0, b.getWidth(), (int) (sy0 + q) + 1),
                    new android.graphics.RectF(x - LK_BW / 2f + dx, wl - (j + 1) * sl, x + LK_BW / 2f + dx, wl - j * sl + 0.6f), bp);
            c.restore();
        }
        bp.setAlpha((int) (255 * a));
        c.save();
        c.rotate(roll, x, wl);
        c.drawBitmap(b, null, new android.graphics.RectF(x - LK_BW / 2f, wl - h * hull + 5f, x + LK_BW / 2f, wl + h * (1f - hull) + 5f), bp);
        c.restore();
        bp.setAlpha(255);
    }

    private static float smooth(float v) { v = Math.max(0f, Math.min(1f, v)); return v * v * (3f - 2f * v); }

    static final float LK_UP = 95f, LK_DOWN = 114f, LK_X0 = 20f, LK_X1 = 1250f, LK_TREES_OUT = 70f;
    static final float LK_WL = 790f, LK_BW = 270f;   // where the boat's hull meets the water, and how wide the boat is

    /**
     * Far peaks, forest, the still water, then the boat, then the reeds. The boat (the couple by day, empty at night) drifts
     * slowly right across the open water in 100 s: the wake trails behind its stern, bow ripples run ahead and idle rings
     * lie round the hull; it rests, fades out, and comes back in at the start. Pictures (now = 0): resting, rings only.
     */

    /** Mask of the water in a layer (alpha, 1/WSTEP size): every opaque pixel for the lake, teal-looking pixels for the oasis pool. */
    private void buildWaterMask(Bitmap b, boolean allOpaque) {
        wTried = true;
        if (b == null) return;
        int w = b.getWidth() / WSTEP, h = b.getHeight() / WSTEP;
        if (w < 4 || h < 4) return;
        boolean[] on = new boolean[w * h];
        wTop = h * WSTEP; wBot = 0f; wLx = w * WSTEP; wRx = 0f;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int r = 0, g = 0, bl = 0, a = 0;
            for (int j = 0; j < 3; j++) for (int i = 0; i < 3; i++) {
                int px = b.getPixel(x * WSTEP + 1 + i * 2, y * WSTEP + 1 + j * 2);
                a += px >>> 24; r += (px >> 16) & 255; g += (px >> 8) & 255; bl += px & 255;
            }
            a /= 9; r /= 9; g /= 9; bl /= 9;
            boolean water = allOpaque ? a > 200 : (a > 200 && bl > r + 8 && g >= r && bl >= g * 0.74f);
            on[y * w + x] = water;
        }
        if (!allOpaque) {   // close the hatching: a cell is water if most of its neighbours are
            boolean[] cp = on.clone();
            for (int y = 1; y < h - 1; y++) for (int x = 1; x < w - 1; x++) {
                int n = 0;
                for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) if (cp[(y + j) * w + x + i]) n++;
                on[y * w + x] = n >= 5;
            }
        }
        byte[] m = new byte[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (on[y * w + x]) {
            m[y * w + x] = (byte) 255;
            wTop = Math.min(wTop, y * WSTEP); wBot = Math.max(wBot, (y + 1) * WSTEP);
            wLx = Math.min(wLx, x * WSTEP); wRx = Math.max(wRx, (x + 1) * WSTEP);
        }
        Bitmap mk = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8);
        mk.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(m));
        wMask = mk;
    }

    /** What the screens hand to the scene: the lit body's place and how strongly it shows on the water (weather, phase, height). */
    static float[] bodyReflection(boolean sun, float x, float y, float r, float bright, float cloud, double phase, float warm) {
        float k;
        if (sun) k = (0.6f + 0.4f * bright) * (1f - 0.75f * cloud);
        else {
            float f = (float) ((1.0 - Math.cos(2.0 * Math.PI * (phase - Math.floor(phase)))) / 2.0);
            k = (0.12f + 0.88f * f) * (1f - 0.8f * cloud) * 0.9f;
        }
        return new float[]{x, y, Math.max(0f, Math.min(1f, k)), sun ? 0f : 1f, r, sun ? warm : 0f};
    }

    private static float h01(int i, int j) {
        double v = Math.sin(i * 12.9898 + j * 78.233) * 43758.5453;
        return (float) (v - Math.floor(v));
    }

    /**
     * The sun or moon over the water: a soft glow, a broken glitter path that sparkles, and the disc itself reflected in shimmering slices.
     * Only where the picture is water, and drawn before anything that stands in the water.
     */
    private void waterShine(Canvas c, long now, Bitmap src, float dy, boolean allOpaque) {
        float[] rf = refl;
        if (rf == null || rf[2] < 0.02f || src == null) return;
        if (!wTried) buildWaterMask(src, allOpaque);
        if (wMask == null || wBot <= wTop) return;
        float k = rf[2];
        float bx = (rf[0] - cl) / cs;
        float rad = rf[4] / cs;
        // the shine always lands on the water you can see: a sun or moon over the reeds or the bank still glitters on the nearest open water
        float inset = (allOpaque ? 0.22f : 0.12f) * (wRx - wLx);
        if (wRx > wLx + 8f * inset / Math.max(1f, inset)) bx = Math.max(wLx + inset, Math.min(wRx - inset, bx));
        float y0 = wTop + dy, y1 = wBot + dy, hh = y1 - y0;
        boolean moon = rf[3] > 0.5f;
        int rgb = moon ? 0xDDE6F5 : blendRgb(0xFFF4CF, 0xFFA85A, rf[5]);
        int sv = c.saveLayer(0f, y0 - 4f, W, y1 + 4f, null);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        // soft glow, widest near the top of the water, fading toward the viewer
        c.save();
        c.translate(bx, y0);
        c.scale(rad * 1.9f, hh * 0.9f);
        p.setShader(new android.graphics.RadialGradient(0f, 0f, 1f, new int[]{((int) (95 * k) << 24) | rgb, ((int) (38 * k) << 24) | rgb, rgb},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        p.setAlpha(255);
        c.drawCircle(0f, 0f, 1f, p);
        p.setShader(null);
        c.restore();
        // the reflected disc, cut into thin slices that slide sideways with the ripples
        float dc = y0 + Math.min(hh * 0.42f, Math.max(rad * 0.45f, 18f));
        int slices = 14;
        float dh = rad * 0.9f;
        for (int i = 0; i < slices; i++) {
            float v = (i + 0.5f) / slices * 2f - 1f;                      // -1 .. 1 down the disc
            float half = rad * (float) Math.sqrt(Math.max(0f, 1f - v * v));
            if (half < 2f) continue;
            float sh = (float) Math.sin(now / 520.0 + i * 1.7) * (3f + 6f * Math.abs(v)) + (float) Math.sin(now / 1300.0 + i) * 3f;
            float al = (0.55f + 0.35f * (float) Math.sin(now / 410.0 + i * 2.3)) * (1f - 0.55f * Math.abs(v)) * k;
            p.setColor(rgb);
            p.setAlpha(Math.max(0, Math.min(255, (int) (255 * al * (moon ? 0.85f : 1f)))));
            float yy = dc + v * dh * 0.5f;
            c.drawRect(bx + sh - half, yy, bx + sh + half, yy + dh / slices * 0.8f, p);
        }
        // glitter: broken dashes in rows, wider and more scattered toward the viewer, each twinkling on its own beat
        int rows = (int) (hh / 5f);
        for (int r = 0; r < rows; r++) {
            float t = r / (float) rows;
            float yy = y0 + 6f + t * (hh - 8f);
            float spread = rad * (0.55f + 1.5f * t);
            int n = 2 + (int) (h01(r, 3) * 3f);
            for (int j = 0; j < n; j++) {
                float hx = h01(r, 10 + j), ht = h01(r, 30 + j);
                float x = bx + (hx - 0.5f) * 2f * spread + (float) Math.sin(now / 900.0 + r * 0.7 + j) * 5f * (0.4f + t);
                float w = (6f + h01(r, 50 + j) * 40f) * (0.45f + t) * 0.9f;
                float tw = 0.5f + 0.5f * (float) Math.sin(now / (230.0 + 90.0 * ht) + ht * 40.0 + r);
                float al = tw * (1f - 0.55f * t) * (1f - 0.9f * Math.abs(hx - 0.5f)) * k;
                p.setColor(rgb);
                p.setAlpha(Math.max(0, Math.min(255, (int) (255 * al))));
                c.drawRect(x - w / 2f, yy, x + w / 2f, yy + 1.8f + 2.6f * t, p);
            }
        }
        p.setAlpha(255);
        // keep only the water
        Paint m = new Paint();
        m.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        m.setFilterBitmap(true);
        c.drawBitmap(wMask, null, new android.graphics.RectF(0f, dy, wMask.getWidth() * (float) WSTEP, dy + wMask.getHeight() * (float) WSTEP), m);
        c.restoreToCount(sv);
    }

    private static int blendRgb(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private void drawLake(Canvas c, Paint bp, float night, long now) {
        // the forest (with its meadow along the shore) and the peaks stand LK_UP higher and the water LK_DOWN lower than drawn in the
        // art, so the strip of ground under the trees shows and the water starts right under it (3 px overlap)
        c.save();
        c.translate(0f, -LK_UP);
        farLayer(c, bp, b0, 0f);   // peaks (and FAR_UP_LAKE higher still)
        layer(c, bp, b1);          // forest with its ground
        c.restore();
        c.save();
        c.translate(0f, LK_DOWN);
        layer(c, bp, b1r);         // water
        c.restore();
        waterShine(c, now, b1r, LK_DOWN, true);   // sun / moon glitter and reflection on the lake (the boat and the foreground stay in front)
        // the boat rows right across the lake in 85 s, coming out from behind the left reeds and going in behind the right ones
        // (the foreground hides both ends, so it never fades or jumps in view), then waits 15 s out of sight
        float bx = 690f, alpha = 1f, move = 0f, p = 0.5f, spd = 0f;
        if (now > 0L) {
            float t = (now % 100000L) / 1000f;
            float u = Math.min(1f, t / 85f);
            // the boat speeds up and slows down twice on the crossing (vr = its speed relative to the mean)
            p = u + 0.7f * (float) Math.sin(4.0 * Math.PI * u) / (float) (4.0 * Math.PI);
            float vr = 1f + 0.7f * (float) Math.cos(4.0 * Math.PI * u);
            bx = LK_X0 + (LK_X1 - LK_X0) * p;
            move = t < 85f ? Math.min(1f, Math.min(t, 85f - t) / 5f) : 0f;
            spd = move * vr / 1.7f;
            if (t >= 85f) alpha = 0f;
        }
        float wakeA = smooth((spd - 0.3f) / 0.3f);        // wake and bow wave only while it moves briskly
        float ringA = 1f - wakeA;                         // idle rings when it slows
        if (now == 0L) { wakeA = 0f; ringA = 1f; }
        int f = now > 0L ? (int) ((now / 111L) % 12L) : 0;
        float bob = now > 0L ? (float) Math.sin(now / 1100.0) * 1.2f : 0f;
        float roll = now > 0L ? (float) Math.sin(now / 1700.0 + 1.0) * 0.6f : 0f;
        float wl = LK_WL + bob + (now > 0L ? 9f * (float) Math.sin(p * 2.0 * Math.PI) : 0f);   // a gentle S in its course
        if (alpha > 0.01f) {
            float dayA = 1f - smooth((night - 0.4f) / 0.2f);
            float ca = dayA * alpha;      // the couple's boat sails by day
            if (ca > 0.01f) {
                boatAt(c, bp, props[1], 0.94f, bx, wl, roll, ca, now, true);
                lapStrip(c, bp, bx, wl, now, ca);
                // wake, in front of the hull: its tip on the stern at the waterline, trailing behind (left), stretching with speed, sliding 10 px per loop
                if (wakeA > 0.01f && now > 0L) {
                    float len = 120f + 200f * Math.max(0f, Math.min(1f, spd));
                    float ph = (now % 1333L) / 1333f;
                    for (int i = 0; i < 2; i++) {
                        float q = (ph + 0.5f * i) % 1f;
                        float wgt = (float) Math.pow(Math.sin(Math.PI * q), 2.0);
                        wakeV(c, bp, bx - LK_BW * 0.44f - 10f * q, wl, len + 10f * q, 0.85f * wakeA * wgt * ca);
                    }
                }
                if (wakeA > 0.01f && props[3] != null) {
                    // the bow wave: flipped, so its crest rears up against the stem (the boat's front) and its tail runs back along the hull;
                    // smaller copies hug the hull behind it, dying away towards the stern
                    float bowBob = now > 0L ? 3.5f * (float) Math.sin(now / 330.0) : 0f;
                    float[] off = {92f, 54f, 20f}, wd = {140f, 84f, 56f}, al = {0.95f, 0.8f, 0.6f};
                    for (int k = 0; k < 3; k++) {
                        float bw = wd[k], bh = bw * props[3].getHeight() / props[3].getWidth() * 1.5f;
                        float cx = bx + off[k], by = wl + 2f + (k == 0 ? bowBob : bowBob * 0.5f);
                        c.save();
                        c.scale(-1f, 1f, cx, 0f);
                        bp.setAlpha((int) (255 * al[k] * wakeA * ca));
                        c.drawBitmap(props[3], null, new android.graphics.RectF(cx - bw / 2f, by - bh, cx + bw / 2f, by), bp);
                        bp.setAlpha(255);
                        c.restore();
                    }
                }
            }
            // the empty boat stays tied up at the shore by night, with slow circular ripples round it
            float na = (1f - dayA) * alpha;
            if (na > 0.01f) {
                float mx = LK_MOOR_X, mwl = LK_WL + 16f + (now > 0L ? (float) Math.sin(now / 1500.0 + 2.0) * 1.0f : 0f);
                float mroll = now > 0L ? (float) Math.sin(now / 2300.0) * 0.9f : 0f;
                ripples(c, bp, mx, mwl, now, na, false);
                boatAt(c, bp, props[0], 0.985f, mx, mwl, mroll, na, now, false);
                ripples(c, bp, mx, mwl, now, na, true);   // (no wave strip on a still boat: only the circular ripples)
            }
        }
        // foreground: the left cluster (the two front trees with the reeds and the rock) sits LK_TREES_OUT further out of the frame
        c.save();
        c.clipRect(0f, 0f, W * 0.5f, H + 120f);
        c.translate(-LK_TREES_OUT, 0f);
        layer(c, bp, b2);
        c.restore();
        c.save();
        c.clipRect(W * 0.5f, 0f, W, H + 120f);
        layer(c, bp, b2);
        c.restore();
    }

    // ---------- the desert oasis ----------

    /** One camp sprite: standing on (x, base), `h` tall (the width follows), turned to face the other way when `flip`. */
    private void campSprite(Canvas c, Paint bp, Bitmap b, float x, float base, float h, boolean flip) {
        if (b == null) return;
        float w = h * b.getWidth() / b.getHeight();
        c.save();
        if (flip) c.scale(-1f, 1f, x, base);
        c.drawBitmap(b, null, new android.graphics.RectF(x - w / 2f, base - h, x + w / 2f, base), bp);
        c.restore();
    }

    private final Paint shadowP = new Paint();

    /** The bonfire (at ground level) throws a person's shadow along the sand, away from the fire: long, flat and dark, wavering with the flame. */
    private void personShadow(Canvas c, Bitmap b, float x, float base, float h, float fl, long now) {
        if (b == null || fl < 0.03f) return;
        float dir = x > OA_FIRE_X ? 1f : -1f;
        float w = h * b.getWidth() / b.getHeight();
        float dist = Math.abs(x - OA_FIRE_X);
        float len = (0.42f + 0.5f * Math.max(0f, 1f - dist / 330f)) * (0.93f + 0.14f * (float) Math.sin(now / 170.0 + x));
        shadowP.setColorFilter(new android.graphics.ColorMatrixColorFilter(new android.graphics.ColorMatrix(new float[]{
                0, 0, 0, 0, 14,
                0, 0, 0, 0, 8,
                0, 0, 0, 0, 4,
                0, 0, 0, 0.72f * Math.min(1f, fl), 0})));
        shadowP.setFilterBitmap(true);
        c.save();
        c.translate(x, base - 1f);
        c.skew(-dir * len / 0.2f, 0f);
        c.scale(1f, 0.2f);
        c.drawBitmap(b, null, new android.graphics.RectF(-w / 2f, -h, w / 2f, 0f), shadowP);
        c.restore();
        shadowP.setColorFilter(null);
    }

    /** The side of a person that faces the fire catches its light: a warm glow over the sprite's own pixels, strongest at the fire-facing edge. */
    private void litPerson(Canvas c, Paint bp, Bitmap b, float x, float base, float h, boolean flip, float fl) {
        if (b == null) return;
        if (fl < 0.03f) { campSprite(c, bp, b, x, base, h, flip); return; }
        float w = h * b.getWidth() / b.getHeight();
        int save = c.saveLayer(x - w, base - h - 4f, x + w, base + 6f, null);
        campSprite(c, bp, b, x, base, h, flip);
        float dir = OA_FIRE_X > x ? 1f : -1f;   // towards the fire
        float edge = x + dir * w / 2f, far = x - dir * w / 2f;
        int a = (int) (255 * Math.min(0.85f, 0.8f * fl));
        plain.setShader(new LinearGradient(edge, 0f, far, 0f, (a << 24) | 0xFFA848, 0x00FF9030, Shader.TileMode.CLAMP));
        plain.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        c.drawRect(x - w, base - h - 4f, x + w, base + 6f, plain);
        plain.setXfermode(null);
        plain.setShader(null);
        c.restoreToCount(save);
    }

    /** Beach props: {picture, feet x, feet y (art px of the 1536x1024 sheets), scale}. Nearer (lower) objects are larger. */
    private static final float[][] BC_PROPS = {
            {7, 345f, 478f, 0.40f},    // rowboat, far back near the huts: drawn after the hut layer (the island), so the huts stand behind it
            {0, 395f, 700f, 0.64f},    // blue umbrella, standing behind the lounger
            {3, 345f, 712f, 0.74f},    // lounger (enlarged, with the woman on it) in front of it, facing the ocean
            {1, 520f, 905f, 0.66f},    // green umbrella, behind the towel
            {4, 385f, 910f, 0.60f},    // surfboard, behind the towel
            {6, 430f, 935f, 0.80f},    // towel, bag and hat on the open sand
    };

    private static final long BC_MER_EVERY = 24000L, BC_MER_FADE = 1800L;
    // the mermaid ashore: each of her 7 towel pictures stays 12 s; she swims in / out over 2.5 s
    private static final long BC_SH_EACH = 12000L, BC_MER_LEAVE = 2500L;
    private static final float BC_SH_SC = 0.58f, BC_SH_DX = 88f, BC_SH_DY = -22f;   // scene px per picture px (the towel is 560 px wide in the pictures = about 325 px in the scene); her spot is right of the towel set, on the open sand
    // the girl from the lounger: on the lounger 34 s, then 26 s away (walks to the sea, jumps, stands in the water, dives away, comes back)
    private static final long BC_STAY = 34000L, BC_AWAY = 26000L;
    private static final long J_WALK = 4500L, J_JUMP = 2400L, J_STAND_END = 12500L, J_DIVE_END = 14500L, J_BACK = 24000L, J_BACK_FADE = 2000L, J_OUT = 1000L;
    private static final float J_SX = 346f, J_SY = 716f, J_PX = 610f, J_PY = 705f, J_D = 213f;   // start (lounger), where she jumps in, drawn width of a picture cell
    private static final float[] J_WLS = {205f / 247f, 209f / 248f};   // waterline height inside a cell of the slim / fuller girl's sheet (6 x 4 cells, the sea strip of the gifs is cut away)
    private static final float BC_FAR_UP = 94f, BC_SAND_DOWN = 45f, BC_GEN = 64f, BC_HZ = 501f, BC_ISLE_X = 470f, BC_MER_X = 720f, BC_MER_Y = 690f, BC_MER_W = 380f, BC_ISLE_FY = 470f, BC_ISLE_SC = 0.95f;

    /** Draws rows [ax, ax+gh) of the sea picture flipped upward about the line ax, over x0..x1 (source columns start at srcX0); the left patch fades out at its right end. */
    private void bcMirror(Canvas c, Paint bp, float x0, float x1, float ax, float gh, int srcX0, boolean fadeRight) {
        int sv = c.saveLayer(x0, ax - gh, x1, ax, null);
        c.save();
        c.translate(0f, ax);
        c.scale(1f, -1f);
        c.drawBitmap(b1, new android.graphics.Rect(srcX0, (int) ax, srcX0 + (int) (x1 - x0), (int) (ax + gh)), new android.graphics.RectF(x0, 0f, x1, gh), bp);
        c.restore();
        if (fadeRight) {
            fade.setShader(new LinearGradient(x1 - 60f, 0f, x1, 0f, 0xFF000000, 0x00000000, Shader.TileMode.CLAMP));
            fade.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            c.drawRect(x0, ax - gh, x1, ax, fade);
            fade.setShader(null); fade.setXfermode(null);
        }
        c.restoreToCount(sv);
    }

    /** The mermaid sits on her rock in the sea near the shore; her picture changes by itself every 24 s with a short cross-fade. */
    private static boolean full(Bitmap[] set) {
        if (set == null || set.length == 0) return false;
        for (Bitmap b : set) if (b == null) return false;
        return true;
    }

    /**
     * What the mermaid shows at time now. ms[0],ms[1]: picture of her rock set and its opacity; ms[2],ms[3]: the next one fading in;
     * ms[4],ms[5]: shore picture and opacity; ms[6],ms[7]: the next shore picture fading in. -1 = none.
     * Look 0 (nothing tapped): her three pictures change by themselves. Looks 1 and 2 (four taps): the same with her hair set, and
     * after the last picture she comes ashore, lies on her towel through the 7 shore pictures and swims back to her rock.
     */
    private void merState(long now) {
        ms[0] = -1f; ms[1] = 0f; ms[2] = -1f; ms[3] = 0f; ms[4] = -1f; ms[5] = 0f; ms[6] = -1f; ms[7] = 0f;
        int look = mermaid.length == 0 ? 0 : Math.min(mermaidLook, mermaid.length - 1);
        if (mermaid.length == 0) return;
        if (!full(mermaid[look])) look = 0;
        Bitmap[] set = mermaid[look];
        if (!full(set)) return;
        int n = set.length;
        long t = now <= 0L ? 0L : look == 0 ? now : Math.max(0L, now - mermaidSince);
        boolean visits = look != 0 && full(shore);
        long R = n * BC_MER_EVERY, S = visits ? shore.length * BC_SH_EACH : 0L;
        long u = visits ? t % (R + S) : t;
        if (!visits || u < R) {
            int slot = (int) ((u / BC_MER_EVERY) % n);
            long into = u % BC_MER_EVERY;
            ms[0] = slot; ms[1] = 1f;
            boolean last = visits && slot == n - 1;
            if (last && into > BC_MER_EVERY - BC_MER_LEAVE) {
                float k = (into - (BC_MER_EVERY - BC_MER_LEAVE)) / (float) BC_MER_LEAVE;   // she swims to the shore
                ms[1] = 1f - k; ms[4] = 0f; ms[5] = k;
            } else if (!last && into > BC_MER_EVERY - BC_MER_FADE) {
                ms[2] = (slot + 1) % n; ms[3] = (into - (BC_MER_EVERY - BC_MER_FADE)) / (float) BC_MER_FADE;
            }
        } else {
            long s = u - R;
            int idx = (int) (s / BC_SH_EACH);
            long into = s % BC_SH_EACH;
            ms[4] = idx; ms[5] = 1f;
            if (idx < shore.length - 1) {
                if (into > BC_SH_EACH - BC_MER_FADE) { ms[6] = idx + 1; ms[7] = (into - (BC_SH_EACH - BC_MER_FADE)) / (float) BC_MER_FADE; }
            } else if (into > BC_SH_EACH - BC_MER_LEAVE) {
                float k = (into - (BC_SH_EACH - BC_MER_LEAVE)) / (float) BC_MER_LEAVE;   // and back to her rock
                ms[5] = 1f - k; ms[0] = 0f; ms[1] = k;
            }
        }
    }

    /** The mermaid sits on her rock in the sea near the shore (see merState for what she shows). */
    private void drawMermaid(Canvas c, Paint bp, long now) {
        if (mermaid.length == 0) return;
        int look = Math.min(mermaidLook, mermaid.length - 1);
        Bitmap[] set = full(mermaid[look]) ? mermaid[look] : mermaid[0];
        if (!full(set)) return;
        Bitmap a0 = set[Math.max(0, (int) ms[0])];
        float h = BC_MER_W * a0.getHeight() / (float) a0.getWidth();
        android.graphics.RectF dst = new android.graphics.RectF(BC_MER_X - BC_MER_W / 2f, BC_MER_Y - h, BC_MER_X + BC_MER_W / 2f, BC_MER_Y);
        Paint mp = new Paint(bp);
        if (rockEmpty != null && ms[1] < 1f) {   // her empty rock stays while she is ashore
            mp.setAlpha(Math.round(255 * (1f - ms[1])));
            c.drawBitmap(rockEmpty, null, dst, mp);
        }
        if (ms[0] >= 0f && ms[1] > 0.01f) {
            mp.setAlpha(Math.round(255 * ms[1]));
            c.drawBitmap(set[(int) ms[0]], null, dst, mp);
        }
        if (ms[2] >= 0f && ms[3] > 0.01f) {
            mp.setAlpha(Math.round(255 * ms[3]));
            c.drawBitmap(set[(int) ms[2]], null, dst, mp);
        }
    }

    /** The mermaid ashore: a woman on her towel and sand patch; the picture's bottom centre sits on (fx, fy). */
    private void drawShore(Canvas c, Paint bp, float fx, float fy) {
        Paint sp = new Paint(bp);
        for (int i = 0; i < 2; i++) {
            int idx = (int) ms[4 + 2 * i];
            float al = ms[5 + 2 * i];
            if (idx < 0 || idx >= shore.length || shore[idx] == null || al <= 0.01f) continue;
            Bitmap b = shore[idx];
            float w = b.getWidth() * BC_SH_SC, h = b.getHeight() * BC_SH_SC;
            sp.setAlpha(Math.round(255 * al));
            c.drawBitmap(b, null, new android.graphics.RectF(fx - w / 2f, fy - h, fx + w / 2f, fy), sp);
        }
    }

    /** How much of the woman on the lounger is there: she gets up (1 s), is away, and lies down again (2 s) while the girl is on her walk. */
    private static float benchWomanAlpha(long e) {
        if (e < 0L) return 1f;
        if (e < J_OUT) return 1f - e / (float) J_OUT;
        if (e < J_BACK) return 0f;
        return Math.min(1f, (e - J_BACK) / (float) J_BACK_FADE);
    }

    /** The girl from the lounger, e ms into her walk: to the sea, the jump (the 24 frames of the picture sheet), standing in the water, diving away. */
    private void drawJumper(Canvas c, Paint bp, int sheet, long e) {
        if (e < 0L || e >= J_DIVE_END || sheet < 0 || sheet >= jump.length || jump[sheet] == null) return;
        Bitmap sh = jump[sheet];
        int fw = sh.getWidth() / 6, fh = sh.getHeight() / 4;
        float dh = J_D * fh / fw;
        float x = J_PX, y = J_PY, a = 1f, bob = 0f, tilt = 0f;
        int frame = 0;
        if (e < J_WALK) {
            float u = e / (float) J_WALK;
            x = J_SX + (J_PX - J_SX) * u;
            y = J_SY + (J_PY - J_SY) * u;
            a = Math.min(1f, e / 800f);
            bob = Math.abs((float) Math.sin(e * Math.PI * 2.0 / 650.0)) * 5f;   // her steps
            tilt = (float) Math.sin(e * Math.PI * 2.0 / 1300.0) * 2f;
        } else if (e < J_WALK + J_JUMP) {
            frame = (int) Math.min(23L, (e - J_WALK) / 100L);
        } else if (e < J_STAND_END) {
            frame = 23;
            bob = (float) Math.sin(e / 520.0) * 1.5f;
        } else {
            float u = (e - J_STAND_END) / (float) (J_DIVE_END - J_STAND_END);
            frame = 23;
            a = 1f - u;
            y += 22f * u;   // she sinks and swims away
        }
        float top = y - J_WLS[sheet] * dh - bob;
        Paint jp = new Paint(bp);
        jp.setAlpha(Math.round(255 * a));
        c.save();
        c.rotate(tilt, x, y);
        c.drawBitmap(sh, new android.graphics.Rect((frame % 6) * fw, (frame / 6) * fh, (frame % 6 + 1) * fw, (frame / 6 + 1) * fh),
                new android.graphics.RectF(x - J_D / 2f, top, x + J_D / 2f, top + dh), jp);
        c.restore();
    }

    private void drawBeach(Canvas c, Paint bp, float night, long now) {
        if (benchPhoto != 0 || mermaidLook != 0) animLoad();   // a tap cycle is running: decode its pictures (once)
        c.save();
        c.translate(0f, -BC_FAR_UP);              // the far islands and their horizon stand higher
        layer(c, bp, b0);
        c.restore();
        // the sea is made taller: its top rows are mirrored upward about a line just under the old horizon (so the old horizon line is
        // covered), up to the far layer's horizon. The island stands on the left, so there the sea beside it is mirrored instead,
        // blended in over 60 px.
        float ax = BC_HZ + 6f, gh = BC_GEN + 6f;
        bcMirror(c, bp, 0f, W, ax, gh, 0, false);
        layer(c, bp, b1);                         // the sea
        // the mid layer's own horizon line is covered by the mirrored sea (right of the island)
        c.save();
        c.clipRect(0f, BC_HZ - 3f, W, ax);
        bcMirror(c, bp, 0f, W, ax, gh, 0, false);
        c.restore();
        waterShine(c, now, b1, 0f, false);        // sun / moon glitter and reflection on the sea
        if (isle != null) {                       // the palm island is attached to the left edge of the scene (its sand runs off the edge)
            float k0 = 1364f / 1536f, iw = isle.getWidth() * BC_ISLE_SC * k0, ih = isle.getHeight() * BC_ISLE_SC * k0;
            c.drawBitmap(isle, null, new android.graphics.RectF(0f, BC_ISLE_FY - ih, iw, BC_ISLE_FY), bp);
        }
        merState(now);
        drawMermaid(c, bp, now);
        long be = -1L;   // ms into the girl's walk to the sea (-1: she lies on the lounger, or nobody does)
        int jsheet = benchPhoto == 1 ? 0 : 1;   // the first lounger picture is the slimmer girl, the other two the fuller one: each has her own jump
        if (benchPhoto >= 1 && benchPhoto <= 3 && now > 0L) {
            long tt = Math.max(0L, now - benchSince) % (BC_STAY + BC_AWAY);
            if (tt >= BC_STAY) be = tt - BC_STAY;
        }
        float wa = benchWomanAlpha(be);
        float ashore = Math.max(ms[5], ms[7]);   // the mermaid lies on the towel's place
        c.save();
        c.translate(0f, BC_SAND_DOWN);            // the sand layer sits lower: more sea, the land and its palms show
        layer(c, bp, b1r);                        // sand and foam: its foam band overlaps the sea, so the join reads as the water's edge
        float k = 1364f / 1536f, oy = 944f - 1024f * k;
        for (float[] q : BC_PROPS) {
            Bitmap b = props[(int) q[0]];
            if (b == null) continue;
            float w = b.getWidth() * q[3] * k, h = b.getHeight() * q[3] * k;
            float fx = q[1] * k, fy = q[2] * k + oy;
            if ((int) q[0] == 6) {
                float under = 1f - ashore;   // the towel set (or the woman lying on it) gives way to the mermaid ashore
                if (under > 0.01f) {
                    bp.setAlpha(Math.round(255 * under));
                    if (benchPhoto >= 4 && lying.length >= benchPhoto - 3 && lying[benchPhoto - 4] != null) {
                        Bitmap tm = lying[benchPhoto - 4];   // the woman lying on her towel replaces the towel with its bag and hat
                        boolean side = benchPhoto == 7;   // the long side-lying picture is shifted right and drawn wider so the grass in front does not hide her head
                        float tw = side ? w * 1.15f : w, th = tw * tm.getHeight() / (float) tm.getWidth(), tx = fx + (side ? w * 0.28f : 0f);
                        c.drawBitmap(tm, null, new android.graphics.RectF(tx - tw / 2f, fy - th, tx + tw / 2f, fy), bp);
                    } else {
                        c.drawBitmap(b, null, new android.graphics.RectF(fx - w / 2f, fy - h, fx + w / 2f, fy), bp);
                    }
                    bp.setAlpha(255);
                }
                if (ashore > 0.01f) drawShore(c, bp, fx + BC_SH_DX, fy + BC_SH_DY);
                continue;
            }
            if ((int) q[0] == 3 && benchPhoto > 0 && benchPhoto <= 3 && woman.length >= benchPhoto && woman[benchPhoto - 1] != null) {
                if (wa < 1f) {   // the empty lounger shows while she is away
                    c.save(); c.scale(-1f, 1f, fx, 0f);
                    c.drawBitmap(b, null, new android.graphics.RectF(fx - w / 2f, fy - h, fx + w / 2f, fy), bp);
                    c.restore();
                }
                if (wa > 0.01f) {
                    Bitmap wm = woman[benchPhoto - 1];   // the woman on the lounger (already facing the ocean), same footprint as the empty one
                    float wh = w * wm.getHeight() / (float) wm.getWidth();
                    bp.setAlpha(Math.round(255 * wa));
                    c.drawBitmap(wm, null, new android.graphics.RectF(fx - w / 2f, fy - wh, fx + w / 2f, fy), bp);
                    bp.setAlpha(255);
                }
                continue;
            }
            boolean flip = (int) q[0] == 3;   // the lounger is turned to face the ocean (its backrest on the land side)
            if (flip) { c.save(); c.scale(-1f, 1f, fx, 0f); }
            c.drawBitmap(b, null, new android.graphics.RectF(fx - w / 2f, fy - h, fx + w / 2f, fy), bp);
            if (flip) c.restore();
        }
        c.restore();
        drawJumper(c, bp, jsheet, be);            // the girl walks from the lounger into the sea and jumps in
        layer(c, bp, b2);                         // palm, grass and rocks in front
    }

    static final float OA_FIRE_X = 682f, OA_BASE = 929f;

    private void drawOasis(Canvas c, Paint bp, float night, long now) {
        c.save();
        c.translate(0f, -FAR_UP_OASIS);   // the far dunes (and the sand storm that climbs them) stand higher
        sandDevil(c, bp, night, now);   // behind the far dunes: the dune hides its foot
        farLayer(c, bp, b0, FAR_UP_OASIS);   // far dunes
        c.restore();
        layer(c, bp, b1);   // palms, pool and the sand in front
        waterShine(c, now, b1, 0f, false);   // sun / moon glitter and reflection on the pool (only where the picture is water)
        layer(c, bp, b1r);  // sand ridge the camp stands on
        Bitmap pit = props[0];
        if (pit == null) return;
        // sizes follow the art brief: a sitting adult about half of a sitting camel, a child 70% of an adult, the fire pit about
        // as wide as a camel is long (ring 110 px)
        float ph = 110f * 427f / 880f, pw = 110f;
        // the travellers sit round the fire facing it, on the sand ridge, a little apart and at different depths
        // fire: lit from dusk, out in full daylight
        float lit = Math.max(0f, Math.min(1f, (night - 0.1f) / 0.4f));
        float fk = fireLevel(now);   // 1 burning ... 0 blown out (only embers)
        float flick = 0.88f + 0.12f * (float) Math.sin(now / 90.0) * (float) Math.sin(now / 230.0 + 1.0);
        float fl = lit * fk * flick;   // how much light the flame throws on the people
        float[][] ppl = {{5, 500f, 918f, 74f}, {4, 575f, 928f, 80f}, {6, 800f, 929f, 78f}, {7, 868f, 921f, 54f}};
        for (float[] q : ppl) personShadow(c, props[(int) q[0]], q[1], q[2], q[3], fl, now);   // the fire throws their shadows on the sand, away from it
        for (float[] q : ppl) litPerson(c, bp, props[(int) q[0]], q[1], q[2], q[3], q[1] > OA_FIRE_X, fl);   // and lights the side that faces it
        // the fire pit
        campSprite(c, bp, pit, OA_FIRE_X, OA_BASE, ph, false);
        if (lit > 0f) {
            float fy = OA_BASE - ph * 0.45f;
            // warm light on the sand, the people and the camels (goes with the flame)
            if (fk > 0.01f) glowAt(c, OA_FIRE_X, fy - 10f, 190f * (0.95f + 0.05f * flick), lit * fk * flick, 255, 150, 50, 1.6f, 0.9f);
            Bitmap fire = props[1];
            if (fire != null && fk > 0.01f) {
                // the burning bonfire is the unlit pit's own picture with the fire in it: it fades in over the pit from dusk
                // (same stone ring, so the ring width 880 of the pit = 941 of the fire picture), and breathes a little
                float u = ph / 427f * 880f / 941f;
                float fh = fire.getHeight() * u * (0.985f + 0.03f * flick);
                plain.setAlpha((int) (255 * lit * fk));
                campSprite(c, plain, fire, OA_FIRE_X, OA_BASE, fh, false);
                plain.setAlpha(255);
            }
            // embers: when the wind has put the flame out only a dull red glow and a few live coals are left
            float em = lit * (1f - fk);
            if (em > 0.01f) {
                float pulse = 0.75f + 0.25f * (float) Math.sin(now / 700.0) * (float) Math.sin(now / 1300.0 + 2.0);
                glowAt(c, OA_FIRE_X, fy + 12f, 52f, em * 0.8f * pulse, 255, 70, 20, 1.5f, 0.55f);
                for (int i = 0; i < 9; i++) {
                    float ex = OA_FIRE_X - 32f + hash01(i, 21) * 64f, ey = OA_BASE - 36f + hash01(i, 22) * 16f;
                    float tw = 0.4f + 0.6f * (float) Math.abs(Math.sin(now / (500.0 + 90.0 * i) + i));
                    plain.setColor(0xFFFF6A2A);
                    plain.setAlpha((int) (255 * em * tw));
                    c.drawRect(ex, ey, ex + 2.2f, ey + 1.6f, plain);
                }
                plain.setAlpha(255);
            }
        }
        sandGust(c, bp, night, now);   // a gust passes low over the sand, in front of the camp
        layer(c, bp, b2);   // foreground palms, bushes and rock at the two sides
        // the camels lie in front of those palms, at the two ends of the camp
        campSprite(c, bp, props[8], 300f, 932f, 126f, false);
        campSprite(c, bp, props[10], 1028f, 930f, 118f, true);
        // with the fire out, the whole camp goes dark (only over pixels already drawn: the sky is not touched)
        float dark = lit * (1f - fk) * 0.4f;
        if (dark > 0.01f) {
            plain.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
            plain.setColor(0xFF04070F);
            plain.setAlpha((int) (255 * dark));
            c.drawRect(0f, 0f, W, H + 80f, plain);
            plain.setAlpha(255);
            plain.setXfermode(null);
        }
    }

    /**
     * How strongly the bonfire burns (1 = burning, 0 = blown out). Every 70 s the gust passes over the camp (13.5 s into it):
     * the flame is blown out in 1.5 s, only embers glow for 12 s, then it catches again over 4 s. Still pictures (now = 0): burning.
     */
    private static float fireLevel(long now) {
        if (now <= 0L) return 1f;
        float t = now % 70000L;
        if (t < 13500f) return 1f;
        if (t < 15000f) return 1f - (t - 13500f) / 1500f;
        if (t < 27000f) return 0f;
        if (t < 31000f) {
            float u = (t - 27000f) / 4000f;
            return u * u * (3f - 2f * u);
        }
        return 1f;
    }

    // --- sand in the wind (static pictures draw nothing: now == 0 on the lock screen) ---
    private static float hash01(int i, int j) {
        double v = Math.sin(i * 12.9898 + j * 78.233) * 43758.5453;
        return (float) (v - Math.floor(v));
    }

    /** One sand grain, about one screen pixel (1.6 picture px), warm sand colour, dimmer at night. */
    private void grain(Canvas c, float x, float y, float a, float night) { grain(c, x, y, a, night, 0xFFE6C27A); }

    private void grain(Canvas c, float x, float y, float a, float night, int col) {
        float k = 1f - 0.55f * night;
        plain.setColor(col);
        plain.setAlpha((int) (255 * Math.max(0f, Math.min(1f, a)) * k));
        c.drawRect(x, y, x + 1.6f, y + 1.6f, plain);
    }

    /** A gust: a drift of sand streaks crosses the ground left to right (30 s of every 70 s) with loose grains riding in it. */
    private void sandGust(Canvas c, Paint bp, float night, long now) {
        if (now <= 0L || props.length < 13 || props[12] == null) return;
        float g = (now % 70000L) / 30000f;
        if (g >= 1f) return;
        float env = (float) Math.sin(Math.PI * g);
        env = env * env;
        Bitmap w = props[12];
        float h = 150f, wd = h * w.getWidth() / w.getHeight();
        float x = -wd + g * (W + wd + 120f);
        float base = 940f;   // a little below the foot of the bonfire (OA_BASE 929)
        plain.setAlpha((int) (255 * 0.8f * env * (1f - 0.35f * night)));
        c.drawBitmap(w, null, new android.graphics.RectF(x, base - h, x + wd, base), plain);
        plain.setAlpha(255);
        long cycle = now / 70000L;
        for (int i = 0; i < 90; i++) {
            float u = hash01(i, (int) cycle), v = hash01(i + 300, 7);
            float gx = x + u * wd + (float) Math.sin(now / 420.0 + i) * 6f + ((now % 70000L) / 1000f) * 18f * (0.3f + v);
            float gy = base - 8f - v * (h * 0.9f) + (float) Math.sin(now / 300.0 + i * 1.7) * 3f;
            if (gx < -4f || gx > W + 4f) continue;
            grain(c, gx, gy, env * (0.45f + 0.55f * hash01(i, 99)), night);
        }
        // sand creeping along the ground at the bottom edge of the drift: 1 px grains skimming and hopping low
        for (int i = 0; i < 70; i++) {
            float u = hash01(i + 500, (int) cycle), v = hash01(i + 700, 11);
            float gx = x + u * wd + (((now % 70000L) / 1000f) * (26f + 30f * v)) % 60f - 30f + (float) Math.sin(now / 500.0 + i) * 4f;
            float hop = Math.abs((float) Math.sin(now / (260.0 + 90.0 * v) + i * 2.3)) * 5f;
            float gy = base - 1f - v * 5f - hop;
            if (gx < -4f || gx > W + 4f || gx < x || gx > x + wd) continue;
            grain(c, gx, gy, env * (0.75f + 0.25f * hash01(i, 55)), night, (i & 1) == 0 ? 0xFFB07A33 : 0xFFD9A857);
        }
    }

    /** A sand whirlwind wanders slowly along the far dunes (100 s of every 240 s), grains spiralling up round it. */
    private int[] duneTop;   // per picture column: the row where the visible dune surface starts (far dunes or the oasis' own sand)

    private synchronized void buildDuneProfile() {
        if (duneTop != null) return;
        int[] top = new int[W];
        final int y0 = 380, hh = 400;
        for (int layer = 0; layer < 1; layer++) {   // the far dunes' skyline; the oasis' own hump may hide the foot, the whirlwind then walks behind it
            Bitmap b = layer == 0 ? b0 : b1;
            if (b == null) continue;
            int[] px = new int[W * hh];
            b.getPixels(px, 0, W, 0, y0, W, hh);
            for (int x = 0; x < W; x++) {
                int t = -1;
                for (int y = 0; y < hh; y++) {
                    int p = px[y * W + x];
                    int a = p >>> 24, r = (p >> 16) & 255, g = (p >> 8) & 255, bl = p & 255;
                    boolean ground = layer == 0 ? a > 128 : (a > 128 && r > 170 && g > 130 && bl < 160 && r >= g);   // the oasis layer: sand only, not palms or water
                    if (ground) { t = y0 + y; break; }
                }
                if (t < 0) t = y0 + hh;
                if (layer == 0 || t < top[x]) top[x] = t;
            }
        }
        // smooth, so the whirlwind glides over the dunes
        int[] sm = new int[W];
        for (int x = 0; x < W; x++) {
            int n = 0; long sum = 0;
            for (int k = -18; k <= 18; k++) { int xx = Math.max(0, Math.min(W - 1, x + k)); sum += top[xx]; n++; }
            sm[x] = (int) (sum / n);
        }
        duneTop = sm;
    }

    private float[][] devRuns;   // {start x, crest x} of each rising stretch of the far dunes' skyline

    /** Every rising stretch of the skyline that ends in a crest (slope turns from up to down), at least 140 px long. */
    private synchronized void buildDevilRuns() {
        if (devRuns != null) return;
        java.util.ArrayList<float[]> out = new java.util.ArrayList<float[]>();
        int lastLow = 120;
        for (int x = 130; x < W - 130; x++) {
            float s0 = duneTop[x - 30] - duneTop[x], s1 = duneTop[x] - duneTop[x + 30];   // > 0: the surface is rising to the right
            if (s0 > 1.5f && s1 <= 0.5f) {                 // slope changes from positive to negative: a crest
                int xs = Math.max(lastLow, x - 380);
                // start where the climb starts: walk back while it still rises
                int st = x;
                while (st > xs && duneTop[st - 30] - duneTop[st] < -0.5f == false && duneTop[st - 30] >= duneTop[st] - 0) st--;
                st = Math.max(xs, st - 30);
                if (x - st >= 140 && x >= 200) out.add(new float[]{st, x});
                lastLow = x;
                x += 60;
            }
        }
        devRuns = out.toArray(new float[0][]);
    }

    /**
     * A sand whirlwind climbs a dune of the far skyline (one climb of 80 s every 120 s, a different dune each time). It stands BEHIND
     * the far dunes layer, so the dune hides its foot; the foot is tilted to the slope under it. When it reaches the crest (the
     * slope turns from rising to falling) it fades away and is gone. Grains spiral up round it.
     */
    private void sandDevil(Canvas c, Paint bp, float night, long now) {
        if (now <= 0L || props.length < 14 || props[13] == null) return;
        buildDuneProfile();
        buildDevilRuns();
        if (devRuns.length == 0) return;
        long cycle = now / 120000L;
        float t = (now % 120000L) / 80000f;
        if (t >= 1f) return;
        float[] run = devRuns[(int) (cycle % devRuns.length)];
        float cx = run[0] + t * (run[1] - run[0]);
        int ix = Math.max(30, Math.min(W - 31, (int) cx));
        // visible only while climbing: it comes in over the first 15% and is gone before the crest
        float env = Math.min(1f, t / 0.15f) * Math.max(0f, Math.min(1f, (0.97f - t) / 0.3f));
        if (env <= 0.01f) return;
        Bitmap tn = props[13];
        float surf = duneTop[ix];
        float base = surf + 10f;                                   // the foot sinks 10 px behind the dune
        float h = (150f + (surf - 480f) * 0.9f), w = h * tn.getWidth() / tn.getHeight();
        float sy = (duneTop[ix + 25] - duneTop[ix - 25]) / 50f;    // slope of the surface: tilts the horizontal foot line to it
        float sway = (float) Math.sin(now / 1100.0) * 3f;
        plain.setAlpha((int) (255 * 0.95f * env * (1f - 0.35f * night)));
        c.save();
        c.translate(cx + sway, base);
        c.skew(0f, sy);
        c.scale(1f + 0.02f * (float) Math.sin(now / 260.0), 1f);
        c.drawBitmap(tn, null, new android.graphics.RectF(-w / 2f, -h, w / 2f, 0f), plain);
        c.restore();
        plain.setAlpha(255);
        for (int i = 0; i < 60; i++) {
            float ph = hash01(i, 5);
            float u = ((now / 3200f) + ph) % 1f;            // 0 at the foot, 1 at the top
            float ang = now / 380f * (1.3f - 0.5f * u) + ph * 6.283f;
            float rad = (10f + 70f * u) * (0.6f + 0.8f * hash01(i, 11)) * (h / 250f);
            float gx = cx + sway + (float) Math.cos(ang) * rad;
            float gy = base - u * h * 1.05f + (float) Math.sin(ang) * rad * 0.18f + sy * (gx - cx);
            grain(c, gx, gy, env * (u < 0.1f ? u * 10f : 1f - 0.5f * u), night);
        }
    }

    private void drawCity(Canvas c, Paint bp, float night, long now) {
        layer(c, bp, b0);
        if (bWin != null && night > 0.05f) {
            plain.setAlpha((int) (255 * Math.min(1f, night * 1.15f)));
            c.drawBitmap(bWin, 0f, 0f, plain);
            plain.setAlpha(255);
        }
        layer(c, bp, b1);
        if (now > 0L) {
            people(c, bp, now, night);
        }
        layer(c, bp, b2);
        if (now > 0L) walkers(c, bp, now);   // on the footpath in front of the street items, behind the lamps and the traffic
        lamps(c, night, new float[][]{{118, 627}, {265, 627}, {565, 627}, {930, 627}}, 70f);
        if (now > 0L) {
            traffic(c, bp, now, night, 918f, 938f, false, 0.34f, 1.0f, 913f, 0f, 0f);
        }
    }

    /** The centre line of the highway's road slopes down to the right (picture px): y = HW_LINE + HW_SLOPE * x / W. */
    private static final float HW_LINE = 796f, HW_SLOPE = 9f;

    private void drawHighway(Canvas c, Paint bp, float night, long now) {
        layer(c, bp, b0);
        // the two farm houses on the far slope: one lit window each at night, a single picture pixel (the trees of the next layer still cover it)
        if (night > 0.12f) {
            plain.setColor(0xFFFFC860);
            plain.setAlpha((int) (255 * Math.min(1f, (night - 0.12f) * 1.5f)));
            c.drawRect(900f, 492f, 901f, 493f, plain);
            c.drawRect(971f, 490f, 972f, 491f, plain);
            plain.setAlpha(255);
        }
        layer(c, bp, b1);
        // roadside: milestone, tea stall, prayer flags, shrine and a warning sign on the verge, behind the traffic
        if (props.length >= 5) {
            propOnVerge(c, bp, props[2], 250f);
            propOnVerge(c, bp, props[3], 470f);
            propOnVerge(c, bp, props[1], 650f);
            propOnVerge(c, bp, props[4], 860f);
            propOnVerge(c, bp, props[0], 1060f);
        }
        roadsideLights(c, night, now);
        if (diyaRoad) roadDiyas(c, bp, night, now, true);   // far edge of the road (vehicles drive in front of these)
        if (now > 0L) {
            // vehicles heading right keep to the upper half of the road, oncoming traffic to the lower half,
            // the Meteor rides on the centre line (all follow the slope of the line)
            traffic(c, bp, now, night, HW_LINE - 11f, HW_LINE + 14f, true, 0.22f, 0.54f, HW_LINE, HW_SLOPE, HW_SLOPE);
        }
        layer(c, bp, b1r);   // guardrail: vehicles drive behind it
        if (diyaRoad) roadDiyas(c, bp, night, now, false);   // near edge, in front of the rail feet
        layer(c, bp, b2);    // foreground trees at the sides
    }

    /**
     * Lamp festivals: small diyas stand along BOTH edges of the road (far = top edge, near = rail side), one between every two posts of the guardrail, each as wide as a post.
     * (posts are about 62.7 px apart, the first gap's middle is at x = 228; the asphalt edge runs from y = 822 at x = 230 to 834 at x = 1137)
     */
    private void roadDiyas(Canvas c, Paint bp, float night, long now, boolean far) {
        if (dyB == null) return;
        float glowK = Math.max(0.25f, Math.min(1f, night * 1.3f));
        int k = 0;
        for (float x = 228f - 62.7f * 3; x < W + 20f; x += 62.7f, k++) {
            int si = (k + (far ? 3 : 0)) % 6;
            Bitmap dy = dyB[si], fl = flB[(int) ((now / 130L + k * 3 + (far ? 2 : 0)) % 6)];
            if (dy == null || fl == null) continue;
            float edge = far ? 0f : 822f + (x - 230f) * (12f / 907f);
            float dw = 16f, dh = dw * dy.getHeight() / dy.getWidth();
            float base = far ? 761f + 8f * x / W + 4f : edge + 9f;   // far edge: on the top edge of the asphalt, just under the kerb
            float flick = 0.85f + 0.15f * (float) Math.sin(now / 95.0 + k * 1.7) * (float) Math.sin(now / 210.0 + k);
            float left = x - dw / 2f, top = base - dh;
            c.drawBitmap(dy, null, new android.graphics.RectF(left, top, left + dw, base), bp);
            float tx = left + dyTip[si][0] * dw, ty = top + dyTip[si][1] * dh;
            float fh = 12f * (0.9f + 0.1f * flick), fw = fh * fl.getWidth() / fl.getHeight();
            glow.setShader(new RadialGradient(tx, ty - fh * 0.4f, fh * 1.8f, new int[]{argb(150 * flick * glowK, 255, 210, 110), argb(60 * flick * glowK, 255, 190, 70), 0},
                    new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(tx, ty - fh * 0.4f, fh * 1.8f, glow);
            glow.setShader(null);
            c.drawBitmap(fl, null, new android.graphics.RectF(tx - fw / 2f, ty - fh + 1f, tx + fw / 2f, ty + 1f), plain);
        }
    }

    /** Where a roadside prop's picture sits in the scene (top-left corner), the same as propOnVerge draws it. */
    private float[] propOrigin(Bitmap b, float cx) {
        if (b == null) return new float[]{cx, 0f};
        return new float[]{cx - b.getWidth() / 2f, 761f + 8f * cx / W - b.getHeight()};
    }

    private void glowAt(Canvas c, float x, float y, float rad, float k, int r, int g, int b, float sx, float sy) {
        glow.setShader(new RadialGradient(x, y, rad, new int[]{argb(200 * k, r, g, b), argb(80 * k, r, g, b), 0},
                new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.save();
        c.translate(x, y);
        c.scale(sx, sy);
        c.translate(-x, -y);
        c.drawCircle(x, y, rad, glow);
        c.restore();
        glow.setShader(null);
    }

    /** Night lights of the tea stall (its hanging bulb and its tube light) and the shrine's two diyas. (The festival string lights are drawn by PosterView.) */
    private void roadsideLights(Canvas c, float night, long now) {
        if (props.length < 5 || props[3] == null || props[4] == null) return;
        float[] st = propOrigin(props[3], 470f);   // tea stall
        float[] sh = propOrigin(props[4], 860f);   // shrine
        float k = night < 0.06f ? 0f : Math.min(1f, night * 1.2f);
        if (k <= 0f) return;
        // tea stall: the bulb hanging from the ceiling (warm) and the tube light (long, cool white)
        glowAt(c, st[0] + 76f, st[1] + 18f, 34f, k, 255, 214, 130, 1f, 1f);
        glowAt(c, st[0] + 54f, st[1] + 22f, 30f, k * 0.9f, 235, 245, 255, 2.2f, 0.55f);
        // shrine: one glow for each diya
        float f1 = 1f, f2 = 1f;
        if (now > 0L) {
            f1 = 0.88f + 0.12f * (float) Math.sin(now / 130.0);
            f2 = 0.88f + 0.12f * (float) Math.sin(now / 150.0 + 2.0);
        }
        glowAt(c, sh[0] + 24f, sh[1] + 56f, 16f, k * f1, 255, 190, 90, 1f, 1f);
        glowAt(c, sh[0] + 42.3f, sh[1] + 56.5f, 16f, k * f2, 255, 190, 90, 1f, 1f);
    }

    /** Box {left, top, width, height} (scene px) of the roadside prop k as drawn on the verge, or null. k: 3 tea stall, 4 shrine. */
    float[] propBox(int k) {
        if (city || props == null || k >= props.length || props[k] == null) return null;
        float cx = k == 3 ? 470f : (k == 4 ? 860f : -1f);
        if (cx < 0f) return null;
        float[] o = propOrigin(props[k], cx);
        return new float[]{o[0], o[1], props[k].getWidth(), props[k].getHeight()};
    }

    private void propOnVerge(Canvas c, Paint bp, Bitmap b, float cx) {
        prop(c, bp, b, cx, 761f + 8f * cx / W);
    }

    private void prop(Canvas c, Paint bp, Bitmap b, float cx, float base) {
        if (b != null) c.drawBitmap(b, cx - b.getWidth() / 2f, base - b.getHeight(), bp);
    }

    private void lamps(Canvas c, float night, float[][] pts, float rad) {
        if (night < 0.06f) return;
        float k = Math.min(1f, night * 1.2f);
        for (float[] p : pts) {
            glow.setShader(new RadialGradient(p[0], p[1], rad,
                    new int[]{argb(190 * k, 255, 214, 130), argb(70 * k, 255, 190, 90), 0},
                    new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(p[0], p[1], rad, glow);
        }
        glow.setShader(null);
    }

    private static int argb(float a, int r, int g, int b) {
        return ((int) Math.max(0, Math.min(255, a)) << 24) | (r << 16) | (g << 8) | b;
    }

    // ---------- people ----------

    private static int hash(long a, int b) {
        long x = a * 0x9E3779B97F4A7C15L + b * 0xBF58476D1CE4E5B9L;
        x ^= (x >>> 29);
        x *= 0x94D049BB133111EBL;
        x ^= (x >>> 32);
        return (int) (x & 0x7fffffff);
    }

    private void people(Canvas c, Paint bp, long now, float night) {
        final long S = 15000L;            // a new walker may start every 15 s
        final float speed = 26f;          // picture px per second
        final long dur = (long) ((W + 400f) / speed * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        for (long n = n0; n <= n1; n++) {
            int h = hash(n, 7);
            if (h % 100 >= 78) continue;
            long t = now - n * S;
            if (t < 0 || t > dur) continue;
            int pick = (h >> 8) % 9;      // walkers 0-7 and the dog
            if (pick == 8) pick = 9;
            Bitmap b = pick < ppl.length ? ppl[pick] : null;
            if (b == null) continue;
            boolean rightward = ((h >> 4) & 1) == 0;
            float sp = speed * (0.85f + ((h >> 12) % 40) / 100f);
            float x = -200f + sp * t / 1000f;
            if (!rightward) x = W + 200f - sp * t / 1000f;
            if (x < -200f || x > W + 200f) continue;
            float feet = 874f + ((h >> 16) % 5);
            // a gentle stride bob
            float bob = (float) Math.abs(Math.sin(t / 1000.0 * 5.2 + h)) * 2.2f;
            drawSprite(c, bp, b, x, feet - bob, !rightward, false, night, 0f);
        }
    }

    /**
     * The animated walkers: the man with the briefcase and the woman with the bag (12-frame cycles at 12 fps) and the golden retriever
     * (trotting alone, or beside the man or the woman). Every sprite faces right and is mirrored when it heads left. They walk on the
     * footpath in front of the back items, so they are drawn before the street lamps and the traffic.
     */
    private void walkers(Canvas c, Paint bp, long now) {
        if (walk.length < 3 || walk[0] == null || walk[1] == null || walk[2] == null) return;
        final long S = 11000L;
        final float vMan = 66f, vWom = 62f, vDog = 84f;      // picture px per second, matched to each cycle's stride
        final long dur = (long) ((W + 500f) / 55f * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        for (long n = n0; n <= n1; n++) {
            int h = hash(n, 91);
            if (h % 100 >= 80) continue;
            long t = now - n * S;
            if (t < 0 || t > dur) continue;
            int kind = (h >> 7) % 100;      // 0-34 man, 35-69 woman, 70-84 dog alone, 85-92 man + dog, 93-99 woman + dog
            boolean right = ((h >> 5) & 1) == 0;
            float feet = 861f + ((h >> 15) % 5);
            if (kind < 85) {
                int w = kind < 35 ? 0 : kind < 70 ? 1 : 2;
                float v = w == 0 ? vMan : w == 1 ? vWom : vDog;
                v *= 0.97f + ((h >> 18) % 7) / 100f;
                walkerAt(c, bp, w, right, v, t, feet, 0f, h);
            } else {
                int w = kind < 93 ? 0 : 1;
                float v = (w == 0 ? vMan : vWom) * (0.97f + ((h >> 18) % 7) / 100f);
                float gap = 64f + ((h >> 21) % 14);   // the dog stays a little ahead of its person, a step nearer the kerb
                walkerAt(c, bp, w, right, v, t, feet, 0f, h);
                walkerAt(c, bp, 2, right, v, t, feet + 3f, gap, h + 5);
            }
        }
    }

    private void walkerAt(Canvas c, Paint bp, int w, boolean right, float v, long t, float feet, float ahead, int h) {
        Bitmap sh = walk[w];
        float x = -200f + v * t / 1000f + ahead;
        if (!right) x = W + 200f - v * t / 1000f - ahead;
        if (x < -220f || x > W + 220f) return;
        int fw = sh.getWidth() / 12, fh = sh.getHeight();
        int f = (int) (((t * 12L) / 1000L + (h & 7)) % 12L);
        android.graphics.Rect src = new android.graphics.Rect(f * fw, 0, f * fw + fw, fh);
        // the dog's head sits to the right of the sheet's centre, so people and dogs share the same anchor (the middle of the frame)
        android.graphics.RectF dst = new android.graphics.RectF(x - fw / 2f, feet - fh + 2f, x + fw / 2f, feet + 2f);
        c.save();
        if (!right) c.scale(-1f, 1f, x, 0f);
        c.drawBitmap(sh, src, dst, bp);
        c.restore();
    }

    // ---------- traffic ----------

    /**
     * Two lanes. Lane A runs left to right (feet at yA), lane B right to left (feet at yB). The sprite sheet of the
     * city has both directions; the highway only has right-facing ones, which are mirrored.
     */
    private void traffic(Canvas c, Paint bp, long now, float night, float yA, float yB, boolean mirrorOnly, float spacingK, float meteorK, float meteorY, float slope, float meteorSlope) {
        // far lane first, then the Meteor (a little further into the far lane), then the near lane on top of it:
        // the bike overtakes behind the oncoming traffic instead of riding over it
        if (!city) {
            runLaneHw(c, bp, now, night, true, 1);
            meteor(c, bp, now, night, meteorY, meteorK, meteorSlope);
            runLaneHw(c, bp, now, night, false, 2);
            return;
        }
        runLane(c, bp, now, night, yA, true, mirrorOnly, 1, slope);
        meteor(c, bp, now, night, meteorY, meteorK, meteorSlope);
        runLane(c, bp, now, night, yB, false, mirrorOnly, 2, slope);
    }

    private void runLane(Canvas c, Paint bp, long now, float night, float feet, boolean rightward, boolean mirrorOnly, int lane, float slope) {
        final long S = city ? 6500L : 7500L;
        final float speed = city ? 115f : (rightward ? 80f : 70f);
        final long dur = (long) ((W + 800f) / speed * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        for (long n = n0; n <= n1; n++) {
            int h = hash(n, lane * 31);
            if (h % 100 >= (city ? 72 : 55)) continue;
            long t = now - n * S;
            if (t < 0 || t > dur) continue;
            int count = veh.length;
            int k;
            boolean flip;
            if (mirrorOnly) {
                k = (h >> 6) % count;
                flip = !rightward;
            } else {
                // right-facing pictures are 0..8, left-facing 9..17
                int base = (h >> 6) % 9;
                k = rightward ? base : base + 9;
                flip = false;
            }
            Bitmap b = veh[k];
            if (b == null) continue;
            float sp = speed * (0.9f + ((h >> 14) % 25) / 100f);
            float x = rightward ? -400f + sp * t / 1000f : W + 400f - sp * t / 1000f;
            if (x < -420f || x > W + 420f) continue;
            // the heaviest vehicles are slower
            drawSprite(c, bp, b, x, feet + slope * Math.max(0f, Math.min(1f, x / W)), flip, true, night, 1f);
        }
    }

    /** Highway speeds in picture px per second, by sprite: bus, blue truck, Thar, bike, yellow pickup, hatchback, army truck, van. Heavy ones are slow, light ones fast. */
    private static final float[] HW_SPEED = {60f, 54f, 90f, 104f, 68f, 98f, 50f, 76f};

    /**
     * The highway's traffic, worked out from the clock alone (no stored state). Vehicles heading right keep to their left, the
     * far (upper) lane; oncoming ones keep to their left, the near (lower) lane. Nobody drives on the centre line (the Meteor's).
     * Each vehicle keeps its own place in its lane. A faster vehicle that catches a slower one moves out to the vehicle's right
     * (toward the centre line), passes, and moves back in.
     */
    private void runLaneHw(Canvas c, Paint bp, long now, float night, boolean rightward, int lane) {
        final long S = 8000L;
        final float vMin = 48f;
        final long dur = (long) ((W + 800f) / vMin * 1000f);
        long n1 = now / S, n0 = (now - dur) / S;
        final int MAXV = 14;
        float[] pos = new float[MAXV], spd = new float[MAXV], wid = new float[MAXV], u = new float[MAXV];
        int[] kk = new int[MAXV];
        int cnt = 0;
        for (long n = n0; n <= n1 && cnt < MAXV; n++) {
            int h = hash(n, lane * 31);
            if (h % 100 >= 45) continue;
            long t = now - n * S;
            if (t < 0) continue;
            int k = (h >> 6) % Math.max(1, veh.length);
            if (k >= veh.length || veh[k] == null) continue;
            float v = (k < HW_SPEED.length ? HW_SPEED[k] : 70f) * (0.96f + ((h >> 14) % 9) / 100f);
            float dist = v * t / 1000f;                      // how far it has travelled since it entered
            if (dist > W + 800f) continue;
            pos[cnt] = dist; spd[cnt] = v; wid[cnt] = veh[k].getWidth(); u[cnt] = ((h >> 20) % 100) / 100f; kk[cnt] = k;
            cnt++;
        }
        float[] feetA = new float[cnt], xA = new float[cnt];
        Integer[] order = new Integer[cnt];
        for (int i = 0; i < cnt; i++) {
            float shift = 0f, give = 0f;
            for (int j = 0; j < cnt; j++) {
                if (i == j) continue;
                float d = Math.abs(pos[j] - pos[i]);
                float gap = (wid[i] + wid[j]) / 2f + 12f, ramp = 120f;
                float f = d <= gap ? 1f : (d >= gap + ramp ? 0f : 1f - (d - gap) / ramp);
                f = f * f * (3f - 2f * f);
                if (spd[i] > spd[j]) { if (f > shift) shift = f; }     // I am the faster one: I pull out and pass
                else if (spd[i] < spd[j]) { if (f > give) give = f; }  // the faster one passes me: I give it room
            }
            float x = rightward ? -400f + pos[i] : W + 400f - pos[i];
            float line = HW_LINE + HW_SLOPE * Math.max(0f, Math.min(1f, x / W));
            float off;
            if (rightward) {
                final float edge = -27f;                      // far edge of the road: nobody goes further
                float own = edge + 10f * u[i];                 // its own place in the lane
                off = own + (-10f - own) * shift + (edge - own) * give * (1f - shift);
            } else {
                final float edge = 19f;                       // near edge of the road
                float own = edge - 6f * u[i];
                off = own + (6f - own) * shift + (edge - own) * give * (1f - shift);
            }
            xA[i] = x; feetA[i] = line + off; order[i] = i;
        }
        final float[] fa = feetA;
        java.util.Arrays.sort(order, new java.util.Comparator<Integer>() {
            @Override public int compare(Integer p, Integer q) { return Float.compare(fa[p], fa[q]); }
        });
        for (int oi = 0; oi < cnt; oi++) {
            int i = order[oi];
            if (xA[i] < -420f || xA[i] > W + 420f) continue;
            drawSprite(c, bp, veh[kk[i]], xA[i], feetA[i], !rightward, true, night, 1f);
        }
    }

    private void meteor(Canvas c, Paint bp, long now, float night, float feet, float scale, float slope) {
        if (meteor == null) return;
        long k = now / PERIOD;
        long ev = k * PERIOD + (long) ((hash(k, 99) % 10000) / 10000f * 10f * 60000f);
        float p = -1f;
        if (now >= ev && now < ev + METEOR_MS) p = (now - ev) / (float) METEOR_MS;
        long m = now - manualStart;
        if (m >= 0 && m < METEOR_MS) p = m / (float) METEOR_MS;
        if (p < 0f) return;
        float bw = meteor.getWidth() * scale, bh = meteor.getHeight() * scale;
        float x = -bw + (W + 2f * bw) * p;       // about three times faster than the traffic
        float y = feet + slope * Math.max(0f, Math.min(1f, (x + bw / 2f) / W));
        c.save();
        c.translate(x - bw / 2f + bw / 2f, 0f);
        // speed streak behind the bike
        if (night > 0.2f) {
            float a = Math.min(1f, night * 1.3f);
            glow.setShader(new android.graphics.LinearGradient(-bw * 2.4f, 0f, 0f, 0f, 0x00FF4030, argb(120 * a, 255, 70, 50), Shader.TileMode.CLAMP));
            c.drawRect(-bw * 2.4f, y - bh * 0.42f, 0f, y - bh * 0.34f, glow);
            glow.setShader(null);
        } else {
            glow.setShader(new android.graphics.LinearGradient(-bw * 2.0f, 0f, 0f, 0f, 0x00FFFFFF, 0x66FFFFFF, Shader.TileMode.CLAMP));
            c.drawRect(-bw * 2.0f, y - bh * 0.30f, 0f, y - bh * 0.26f, glow);
            glow.setShader(null);
        }
        c.restore();
        Paint pp = bp;
        c.drawBitmap(meteor, null, new android.graphics.RectF(x, y - bh, x + bw, y), pp);
        if (night > 0.12f) {
            float hx = x + bw * lampX, hy = y - bh * lampY;
            headlight(c, hx, hy, 150f * scale + 40f, night, true);
        }
    }

    private void headlight(Canvas c, float x, float y, float len, float night, boolean toRight) {
        float a = Math.min(1f, (night - 0.1f) * 1.4f);
        if (a <= 0f) return;
        float dir = toRight ? 1f : -1f;
        glow.setShader(new RadialGradient(x, y, len, new int[]{argb(190 * a, 255, 240, 190), argb(60 * a, 255, 225, 150), 0},
                new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        c.save();
        c.translate(x, y);
        c.scale(1.7f * dir, 0.45f);
        c.translate(-x, -y);
        c.drawCircle(x, y, len, glow);
        c.restore();
        glow.setShader(null);
    }

    /**
     * @param feet  y of the wheels / feet
     * @param flip  mirror the picture
     */
    private void drawSprite(Canvas c, Paint bp, Bitmap b, float cx, float feet, boolean flip, boolean vehicle, float night, float unused) {
        float w = b.getWidth(), h = b.getHeight();
        float left = cx - w / 2f, top = feet - h + 3f;
        c.save();
        if (flip) c.scale(-1f, 1f, cx, 0f);
        c.drawBitmap(b, left, top, bp);
        c.restore();
        if (vehicle && night > 0.12f) {
            // the car travels toward its front: right-facing picture unless mirrored
            boolean right = !flip;
            // pictures 9..17 of the city sheet face left; their flip flag is false but they head left
            int idx = -1;
            for (int i = 0; i < veh.length; i++) if (veh[i] == b) { idx = i; break; }
            if (city && idx >= 9) right = false;
            float fx = right ? cx + w * 0.47f : cx - w * 0.47f;
            float fy = top + h * 0.62f;
            headlight(c, fx, fy, Math.max(60f, w * 0.55f), night, right);
            float rx = right ? cx - w * 0.47f : cx + w * 0.47f;
            float a = Math.min(1f, (night - 0.1f) * 1.4f);
            glow.setShader(new RadialGradient(rx, fy, 9f, new int[]{argb(200 * a, 255, 50, 40), 0}, null, Shader.TileMode.CLAMP));
            c.drawCircle(rx, fy, 9f, glow);
            glow.setShader(null);
        }
    }
}
