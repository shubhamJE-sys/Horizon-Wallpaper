package com.horizon.wallpaper;

import android.app.WallpaperManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.service.wallpaper.WallpaperService;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.ViewConfiguration;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Retro poster live wallpaper (v4).
 * Background image = frames only. Everything inside the frames is drawn live:
 * clock/date/day, time- and weather-driven sky (sun, moon, stars, clouds, rain),
 * greeting, day of year, battery/charging, music button + expanding player, text buttons.
 */
public class HorizonWallpaperService extends WallpaperService {

    private static final float DW = 360f, DH = 804f;
    private static final int INK = Color.parseColor("#1B1B1A");
    private static final int RED = Color.parseColor("#C8382C");
    private static final int CREAM = Color.parseColor("#ECE3D0");
    private static final int WARM = Color.parseColor("#E9B58E");
    private static final int NIGHT = Color.parseColor("#1F2430");
    private static final int MOON = Color.parseColor("#EDE6D3");

    // scene area (design units)
    private static final float SC_L = 9.5f, SC_T = 241f, SC_R = 350.5f, SC_B = 477f;
    private static final float LAKE_Y = 241f + 236f * 0.66f;

    // media panel (expanded) bounds
    private static final float PANEL_L = 8f, PANEL_R = 352f, PANEL_T = 395f, PANEL_B = 553f;
    private static final float BTN_Y = 524f, PREV_X = 148f, PLAY_X = 204f, NEXT_X = 260f;

    // Weather location (Raebareli). Change here if you move.
    private static final String WEATHER_URL =
            "https://api.open-meteo.com/v1/forecast?latitude=26.23&longitude=81.23"
                    + "&current=temperature_2m,weather_code,cloud_cover"
                    + "&daily=sunrise,sunset&timezone=auto&forecast_days=1";

    private static final String[] BUTTON_WORDS = {
            "PHONE", "MESSAGES", "BROWSER", "GALLERY", "CAMERA", "PLAY STORE"};

    private static final float[][] CLOUDS = {
            {.15f, .12f, 1.0f}, {.58f, .05f, 1.3f}, {.82f, .24f, 0.9f}, {.33f, .30f, 1.1f},
            {.70f, .40f, 1.0f}, {.06f, .42f, 0.8f}, {.92f, .02f, 0.8f}};

    @Override
    public Engine onCreateEngine() {
        return new PosterEngine();
    }

    private class PosterEngine extends Engine {
        private Bitmap bg, layer;
        private Typeface bebas, roboto;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Paint layerPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Paint artPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Handler handler = new Handler(Looper.getMainLooper());

        private int width, height;
        private float scale = 1f, offX = 0f, offY = 0f;
        private boolean visible = false;
        private boolean receiving = false;
        private long lastTap = 0;

        // tap vs swipe
        private float downX, downY;
        private long downTime;
        private boolean moved = false;
        private int touchSlop = 24;

        // battery
        private int batteryPct = 100;
        private int pluggedType = 0;
        private float tempC = -1f;

        // weather
        private boolean weatherOk = false;
        private volatile boolean fetching = false;
        private long lastFetch = 0;
        private int wCode = 0, wCloud = 0;
        private float wTemp = 0f;
        private int sunriseMin = 360, sunsetMin = 1080;

        // precomputed random scenery
        private final float[] rainX = new float[120];
        private final float[] rainY = new float[120];
        private final float[] starX = new float[45];
        private final float[] starY = new float[45];
        private final float[] starR = new float[45];

        // media
        private MediaSessionManager msm;
        private ComponentName listenerComp;
        private MediaController controller;
        private Bitmap art;
        private boolean mediaRegistered = false;
        private boolean panelOpen = false;
        private boolean wasPlaying = false;

        private final BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                    readBattery(intent);
                }
                fetchWeather();
                draw();
            }
        };

        private final Runnable ticker = new Runnable() {
            @Override
            public void run() {
                draw();
                scheduleTick();
            }
        };

        private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
                new MediaSessionManager.OnActiveSessionsChangedListener() {
                    @Override
                    public void onActiveSessionsChanged(List<MediaController> controllers) {
                        pickController(controllers);
                        checkAutoOpen();
                        draw();
                    }
                };

        private final MediaController.Callback controllerCallback = new MediaController.Callback() {
            @Override
            public void onPlaybackStateChanged(PlaybackState state) {
                checkAutoOpen();
                draw();
                scheduleTick();
            }

            @Override
            public void onMetadataChanged(MediaMetadata metadata) {
                updateArt();
                draw();
            }

            @Override
            public void onSessionDestroyed() {
                setController(null);
                draw();
            }
        };

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);
            try {
                touchSlop = ViewConfiguration.get(HorizonWallpaperService.this).getScaledTouchSlop();
            } catch (Exception ignored) { }
            try {
                InputStream in = getAssets().open("live_bg.jpg");
                bg = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Exception ignored) { }
            try {
                InputStream in = getAssets().open("scene_layer.png");
                layer = BitmapFactory.decodeStream(in);
                in.close();
            } catch (Exception ignored) { }
            try {
                bebas = Typeface.createFromAsset(getAssets(), "BebasNeue.ttf");
                roboto = Typeface.createFromAsset(getAssets(), "Roboto-Regular.ttf");
            } catch (Exception e) {
                bebas = Typeface.DEFAULT_BOLD;
                roboto = Typeface.DEFAULT;
            }
            ColorMatrix gray = new ColorMatrix();
            gray.setSaturation(0f);
            artPaint.setColorFilter(new ColorMatrixColorFilter(gray));

            Random r = new Random(11);
            for (int i = 0; i < rainX.length; i++) {
                rainX[i] = r.nextFloat() * 341f;
                rainY[i] = r.nextFloat() * 236f;
            }
            for (int i = 0; i < starX.length; i++) {
                starX[i] = SC_L + r.nextFloat() * 341f;
                starY[i] = SC_T + 6f + r.nextFloat() * 120f;
                starR[i] = 0.5f + r.nextFloat() * 0.9f;
            }

            Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (sticky != null) readBattery(sticky);
        }

        // ---------- battery ----------

        private void readBattery(Intent i) {
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scaleVal = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (level >= 0 && scaleVal > 0) batteryPct = Math.round(level * 100f / scaleVal);
            pluggedType = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            int t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            tempC = t >= 0 ? t / 10f : -1f;
        }

        private void startReceiving() {
            if (receiving) return;
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_TIME_TICK);
            f.addAction(Intent.ACTION_TIME_CHANGED);
            f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            f.addAction(Intent.ACTION_BATTERY_CHANGED);
            f.addAction(Intent.ACTION_POWER_CONNECTED);
            f.addAction(Intent.ACTION_POWER_DISCONNECTED);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(receiver, f);
            }
            receiving = true;
            Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (sticky != null) readBattery(sticky);
        }

        private void stopReceiving() {
            if (!receiving) return;
            try { unregisterReceiver(receiver); } catch (Exception ignored) { }
            receiving = false;
        }

        // ---------- weather ----------

        private void fetchWeather() {
            long now = SystemClock.elapsedRealtime();
            if (fetching) return;
            if (weatherOk && now - lastFetch < 30L * 60L * 1000L) return;
            if (!weatherOk && lastFetch != 0 && now - lastFetch < 2L * 60L * 1000L) return;
            fetching = true;
            lastFetch = now;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        HttpURLConnection con = (HttpURLConnection) new URL(WEATHER_URL).openConnection();
                        con.setConnectTimeout(8000);
                        con.setReadTimeout(8000);
                        InputStream in = con.getInputStream();
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] buf = new byte[4096];
                        int n;
                        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                        in.close();
                        con.disconnect();
                        JSONObject j = new JSONObject(bo.toString("UTF-8"));
                        JSONObject cur = j.getJSONObject("current");
                        final float temp = (float) cur.getDouble("temperature_2m");
                        final int code = cur.getInt("weather_code");
                        final int cloud = cur.getInt("cloud_cover");
                        JSONObject d = j.getJSONObject("daily");
                        final int sr = toMinutes(d.getJSONArray("sunrise").getString(0));
                        final int ss = toMinutes(d.getJSONArray("sunset").getString(0));
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                wTemp = temp;
                                wCode = code;
                                wCloud = cloud;
                                if (sr > 0 && ss > sr) {
                                    sunriseMin = sr;
                                    sunsetMin = ss;
                                }
                                weatherOk = true;
                                draw();
                            }
                        });
                    } catch (Exception ignored) {
                    } finally {
                        fetching = false;
                    }
                }
            }).start();
        }

        private int toMinutes(String iso) {
            // "2026-10-28T06:05"
            int h = Integer.parseInt(iso.substring(11, 13));
            int m = Integer.parseInt(iso.substring(14, 16));
            return h * 60 + m;
        }

        private float cloudFrac() {
            if (!weatherOk) return 0f;
            float c = wCloud / 100f;
            if (wCode >= 51) c = Math.max(c, 0.8f);
            else if (wCode == 45 || wCode == 48) c = Math.max(c, 0.6f);
            return Math.max(0f, Math.min(1f, c));
        }

        private int rainLevel() {
            if (!weatherOk) return 0;
            switch (wCode) {
                case 51: case 53: case 55: case 56: case 57:
                    return 1;
                case 61: case 63: case 66: case 80: case 81:
                    return 2;
                case 65: case 67: case 82: case 95: case 96: case 99:
                    return 3;
                default:
                    return 0;
            }
        }

        private boolean snowing() {
            return weatherOk && ((wCode >= 71 && wCode <= 77) || wCode == 85 || wCode == 86);
        }

        private String weatherLabel(boolean night) {
            switch (wCode) {
                case 0: return night ? "CLEAR NIGHT" : "CLEAR SKY";
                case 1: return "MOSTLY CLEAR";
                case 2: return "PARTLY CLOUDY";
                case 3: return "OVERCAST";
                case 45: case 48: return "FOG";
                case 51: case 53: case 55: case 56: case 57: return "DRIZZLE";
                case 61: case 63: case 65: case 66: case 67: return "RAIN";
                case 80: case 81: case 82: return "SHOWERS";
                case 71: case 73: case 75: case 77: case 85: case 86: return "SNOW";
                case 95: case 96: case 99: return "THUNDERSTORM";
                default: return "WEATHER";
            }
        }

        // ---------- media ----------

        private boolean hasListenerAccess() {
            try {
                String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
                return flat != null && flat.contains(getPackageName());
            } catch (Exception e) {
                return false;
            }
        }

        private void startMedia() {
            if (mediaRegistered || !hasListenerAccess()) return;
            try {
                msm = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
                listenerComp = new ComponentName(HorizonWallpaperService.this, MediaListenerService.class);
                msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComp, handler);
                mediaRegistered = true;
                pickController(msm.getActiveSessions(listenerComp));
                wasPlaying = isPlaying();
            } catch (RuntimeException e) {
                mediaRegistered = false;
            }
        }

        private void stopMedia() {
            if (msm != null && mediaRegistered) {
                try { msm.removeOnActiveSessionsChangedListener(sessionsListener); } catch (Exception ignored) { }
            }
            mediaRegistered = false;
            setController(null);
        }

        private void pickController(List<MediaController> list) {
            MediaController best = null;
            if (list != null) {
                for (MediaController mc : list) {
                    PlaybackState st = mc.getPlaybackState();
                    if (st == null) continue;
                    if (st.getState() == PlaybackState.STATE_PLAYING) {
                        best = mc;
                        break;
                    }
                    if (best == null && mc.getMetadata() != null
                            && (st.getState() == PlaybackState.STATE_PAUSED
                            || st.getState() == PlaybackState.STATE_BUFFERING)) {
                        best = mc;
                    }
                }
            }
            setController(best);
        }

        private void setController(MediaController mc) {
            if (controller != null) {
                try { controller.unregisterCallback(controllerCallback); } catch (Exception ignored) { }
            }
            controller = mc;
            if (mc != null) {
                try { mc.registerCallback(controllerCallback, handler); } catch (Exception ignored) { }
            }
            updateArt();
            scheduleTick();
        }

        private void checkAutoOpen() {
            boolean p = isPlaying();
            if (p && !wasPlaying) panelOpen = true;
            wasPlaying = p;
        }

        private void updateArt() {
            art = null;
            if (controller == null) return;
            MediaMetadata m = controller.getMetadata();
            if (m == null) return;
            Bitmap b = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
            if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
            art = b;
        }

        private boolean isPlaying() {
            if (controller == null) return false;
            PlaybackState st = controller.getPlaybackState();
            return st != null && st.getState() == PlaybackState.STATE_PLAYING;
        }

        private boolean mediaActive() {
            if (controller == null) return false;
            PlaybackState st = controller.getPlaybackState();
            MediaMetadata m = controller.getMetadata();
            if (st == null || m == null) return false;
            int s = st.getState();
            if (s != PlaybackState.STATE_PLAYING && s != PlaybackState.STATE_PAUSED
                    && s != PlaybackState.STATE_BUFFERING) return false;
            CharSequence title = m.getText(MediaMetadata.METADATA_KEY_TITLE);
            return !TextUtils.isEmpty(title);
        }

        private void scheduleTick() {
            handler.removeCallbacks(ticker);
            if (visible && (isPlaying() || panelOpen)) handler.postDelayed(ticker, 1000);
        }

        private long position() {
            PlaybackState s = controller.getPlaybackState();
            if (s == null) return 0;
            long p = s.getPosition();
            if (s.getState() == PlaybackState.STATE_PLAYING) {
                long dt = SystemClock.elapsedRealtime() - s.getLastPositionUpdateTime();
                p += (long) (dt * s.getPlaybackSpeed());
            }
            return Math.max(0, p);
        }

        private void sendKey(int code) {
            try {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                long t = SystemClock.uptimeMillis();
                am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0));
                am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0));
            } catch (Exception ignored) { }
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    draw();
                }
            }, 400);
        }

        private void transport(int which) {
            // which: 0 previous, 1 play/pause, 2 next. Key events work even without notification access.
            int key = which == 0 ? KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    : (which == 1 ? KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE : KeyEvent.KEYCODE_MEDIA_NEXT);
            sendKey(key);
        }

        private void openMusicApp() {
            try {
                if (controller != null && controller.getSessionActivity() != null) {
                    controller.getSessionActivity().send();
                    return;
                }
            } catch (Exception ignored) { }
            startIntent(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC));
        }

        // ---------- lifecycle ----------

        @Override
        public void onVisibilityChanged(boolean vis) {
            visible = vis;
            if (vis) {
                startReceiving();
                startMedia();
                fetchWeather();
                draw();
                scheduleTick();
            } else {
                handler.removeCallbacks(ticker);
                stopReceiving();
                stopMedia();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            width = w;
            height = h;
            draw();
        }

        @Override
        public void onDestroy() {
            handler.removeCallbacks(ticker);
            stopReceiving();
            stopMedia();
            super.onDestroy();
        }

        // ---------- touch ----------

        @Override
        public void onTouchEvent(MotionEvent e) {
            super.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downY = e.getY();
                    downTime = SystemClock.uptimeMillis();
                    moved = false;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getX() - downX, dy = e.getY() - downY;
                    if (dx * dx + dy * dy > (float) touchSlop * touchSlop) moved = true;
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved && SystemClock.uptimeMillis() - downTime < 400) {
                        handleTap(e.getX(), e.getY());
                    }
                    break;
                case MotionEvent.ACTION_CANCEL:
                    moved = true;
                    break;
                default:
                    break;
            }
        }

        @Override
        public Bundle onCommand(String action, int x, int y, int z, Bundle extras, boolean resultRequested) {
            if (WallpaperManager.COMMAND_TAP.equals(action)) handleTap(x, y);
            return super.onCommand(action, x, y, z, extras, resultRequested);
        }

        private boolean inRect(float x, float y, float l, float t, float r, float b) {
            return x >= l && x <= r && y >= t && y <= b;
        }

        private boolean near(float x, float y, float cx, float cy, float r) {
            float dx = x - cx, dy = y - cy;
            return dx * dx + dy * dy <= r * r;
        }

        private void handleTap(float px, float py) {
            long now = SystemClock.uptimeMillis();
            if (now - lastTap < 350) return;
            if (width <= 0) return;
            float x = (px - offX) / scale;
            float y = (py - offY) / scale;

            // The phone's own floating Search pill sits here: leave that tap alone.
            if (inRect(x, y, 128f, 628f, 232f, 676f)) return;

            // Expanded music panel
            if (panelOpen && inRect(x, y, PANEL_L, PANEL_T, PANEL_R, PANEL_B)) {
                lastTap = now;
                panelTap(x, y);
                return;
            }

            // Music button (closed state)
            if (!panelOpen && inRect(x, y, 240f, 480f, 350f, 552f)) {
                lastTap = now;
                panelOpen = true;
                scheduleTick();
                draw();
                return;
            }

            // Clock -> Clock app
            if (inRect(x, y, 8f, 34f, 108f, 196f)) {
                lastTap = now;
                startIntent(new Intent(AlarmClock.ACTION_SHOW_ALARMS));
                return;
            }

            // Date and day -> Calendar app
            if (inRect(x, y, 108f, 34f, 228f, 150f) || inRect(x, y, 228f, 34f, 352f, 240f)) {
                lastTap = now;
                startIntent(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR));
                return;
            }

            // Text buttons
            if (inRect(x, y, 8f, 641f, 352f, 771f)) {
                lastTap = now;
                int col = (int) ((x - 8f) / (344f / 3f));
                col = Math.max(0, Math.min(2, col));
                int row = y < 713f ? 0 : 1;
                launchButton(row * 3 + col);
            }
        }

        private void panelTap(float x, float y) {
            if (near(x, y, 338f, 408f, 13f)) {
                panelOpen = false;
                handler.removeCallbacks(ticker);
                scheduleTick();
                draw();
                return;
            }
            if (near(x, y, PREV_X, BTN_Y, 22f)) {
                transport(0);
            } else if (near(x, y, PLAY_X, BTN_Y, 24f)) {
                transport(1);
            } else if (near(x, y, NEXT_X, BTN_Y, 22f)) {
                transport(2);
            } else if (inRect(x, y, 288f, 508f, 346f, 540f)) {
                openMusicApp();
            } else if (!mediaActive() && !hasListenerAccess() && inRect(x, y, 120f, 410f, 340f, 480f)) {
                startIntent(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            } else {
                openMusicApp();
            }
        }

        private void startIntent(Intent i) {
            if (i == null) return;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                HorizonWallpaperService.this.startActivity(i);
            } catch (Exception ignored) { }
        }

        private void launchButton(int idx) {
            Intent i = null;
            switch (idx) {
                case 0:
                    i = new Intent(Intent.ACTION_DIAL);
                    break;
                case 1:
                    i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING);
                    break;
                case 2:
                    i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
                    break;
                case 3:
                    i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY);
                    break;
                case 4:
                    i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                    break;
                case 5:
                    i = getPackageManager().getLaunchIntentForPackage("com.android.vending");
                    break;
                default:
                    break;
            }
            startIntent(i);
        }

        // ---------- drawing ----------

        private void draw() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null && width > 0) render(c);
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Exception ignored) { }
                }
            }
        }

        private void render(Canvas c) {
            c.drawColor(CREAM);
            scale = Math.max(width / DW, height / DH);
            offX = (width - DW * scale) / 2f;
            offY = (height - DH * scale) / 2f;

            if (bg != null) {
                Matrix m = new Matrix();
                float bs = scale * DW / bg.getWidth();
                m.postScale(bs, bs);
                m.postTranslate(offX, offY);
                c.drawBitmap(bg, m, bitmapPaint);
            }

            c.save();
            c.translate(offX, offY);
            c.scale(scale, scale);
            try { drawScene(c); } catch (Exception ignored) { }
            drawLive(c);
            c.restore();
        }

        private void text(Canvas c, String t, float x, float y, float size, int color,
                          Typeface tf, Paint.Align align, float spacingEm) {
            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(tf);
            paint.setTextSize(size);
            paint.setColor(color);
            paint.setTextAlign(align);
            paint.setLetterSpacing(spacingEm);
            c.drawText(t, x, y, paint);
        }

        private int blend(int a, int b, float t) {
            t = Math.max(0f, Math.min(1f, t));
            int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t);
            int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t);
            int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
            return Color.rgb(r, g, bl);
        }

        // ---------- the sky / scene ----------

        private void drawScene(Canvas c) {
            Calendar cal = Calendar.getInstance();
            int nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
            int sr = sunriseMin, ss = sunsetMin;
            boolean day = nowMin >= sr && nowMin <= ss;
            float cc = cloudFrac();

            float d = nowMin - sr, e = ss - nowMin;
            int edge = blend(CREAM, WARM, 0.8f);
            int sky;
            float nightK = 0f;
            if (day) {
                float w = Math.min(d, e);
                float f = Math.max(0f, Math.min(1f, 1f - w / 60f));
                sky = blend(CREAM, WARM, f * 0.8f);
            } else {
                float m = d < 0 ? -d : -e;
                nightK = Math.max(0f, Math.min(1f, m / 45f));
                sky = blend(edge, NIGHT, nightK);
            }
            int dimTarget = nightK > 0.5f ? Color.parseColor("#14171F") : Color.parseColor("#BBB5A8");
            sky = blend(sky, dimTarget, cc * 0.45f);

            c.save();
            c.clipRect(SC_L, SC_T, SC_R, SC_B);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(sky);
            c.drawRect(SC_L, SC_T, SC_R, SC_B, paint);

            // stars
            if (nightK > 0.15f) {
                int a = (int) (255 * nightK * (1f - cc * 0.8f));
                paint.setColor(MOON);
                paint.setAlpha(Math.max(0, Math.min(255, a)));
                for (int i = 0; i < starX.length; i++) {
                    c.drawCircle(starX[i], starY[i], starR[i], paint);
                }
                paint.setAlpha(255);
            }

            // sun or moon
            float bx, by, br;
            boolean bodyUp;
            if (day) {
                float t = (nowMin - sr) / (float) Math.max(1, ss - sr);
                bx = 40f + t * 270f;
                float base = LAKE_Y + 24f, peak = 292f;
                by = base - (float) Math.sin(Math.PI * t) * (base - peak);
                br = 33f;
                bodyUp = by < LAKE_Y - 6f;
                paint.setColor(RED);
                paint.setAlpha((int) (255 * (1f - 0.55f * cc)));
                c.drawCircle(bx, by, br, paint);
                paint.setAlpha(255);
            } else {
                int len = 1440 - (ss - sr);
                int m2 = nowMin >= ss ? nowMin - ss : nowMin + 1440 - ss;
                float t = m2 / (float) Math.max(1, len);
                bx = 40f + t * 270f;
                float base = LAKE_Y + 22f, peak = 288f;
                by = base - (float) Math.sin(Math.PI * t) * (base - peak);
                br = 24f;
                bodyUp = by < LAKE_Y - 6f;
                double phase = ((System.currentTimeMillis() - 947182440000L) / 86400000.0 % 29.530588853) / 29.530588853;
                float f = (float) ((1.0 - Math.cos(2.0 * Math.PI * phase)) / 2.0);
                float dd = 2f * br * f;
                paint.setColor(MOON);
                paint.setAlpha((int) (255 * (1f - 0.5f * cc)));
                c.drawCircle(bx, by, br, paint);
                paint.setAlpha(255);
                paint.setColor(sky);
                c.drawCircle(phase < 0.5 ? bx - dd : bx + dd, by, br + 0.5f, paint);
            }

            // clouds (behind the mountains)
            int nCl = Math.round(cc * CLOUDS.length);
            int cloudCol = nightK > 0.5f ? Color.parseColor("#3A4150")
                    : (cc > 0.6f ? Color.parseColor("#B3AD9F") : Color.parseColor("#F6F0E3"));
            for (int i = 0; i < nCl && i < CLOUDS.length; i++) {
                float cx = SC_L + CLOUDS[i][0] * 341f;
                float cy = SC_T + 14f + CLOUDS[i][1] * 150f;
                float s = CLOUDS[i][2];
                paint.setColor(cloudCol);
                paint.setAlpha(235);
                c.drawOval(new RectF(cx - 26f * s, cy - 8f * s, cx + 26f * s, cy + 8f * s), paint);
                c.drawOval(new RectF(cx - 29f * s, cy - 13f * s, cx + 1f * s, cy + 3f * s), paint);
                c.drawOval(new RectF(cx - 8f * s, cy - 17f * s, cx + 27f * s, cy + 2f * s), paint);
                paint.setAlpha(255);
            }

            // mountains + lake layer, darker at night / under cloud
            if (layer != null) {
                float a = 1f - 0.55f * nightK - 0.2f * cc;
                float bl = 16f * nightK;
                ColorMatrix cm = new ColorMatrix(new float[]{
                        a, 0, 0, 0, 0,
                        0, a, 0, 0, 0,
                        0, 0, a, 0, bl,
                        0, 0, 0, 1, 0});
                layerPaint.setColorFilter(new ColorMatrixColorFilter(cm));
                c.drawBitmap(layer, null, new RectF(SC_L, SC_T, SC_R, SC_B), layerPaint);
            }

            // reflection of the sun / moon on the lake
            if (bodyUp) {
                int col = day ? RED : MOON;
                for (int i = 0; i < 9; i++) {
                    float w = (30f - i * 2.8f) * (1f - 0.4f * cc);
                    float yy = LAKE_Y + 5f + i * 8f;
                    paint.setColor(col);
                    paint.setAlpha(150 - i * 8);
                    c.drawRect(bx - w, yy, bx + w, yy + 1.8f, paint);
                }
                paint.setAlpha(255);
            }

            // fog
            if (weatherOk && (wCode == 45 || wCode == 48)) {
                int fog = nightK > 0.5f ? Color.parseColor("#2A2F3B") : Color.parseColor("#E4DCC8");
                paint.setShader(new LinearGradient(0, 320f, 0, LAKE_Y + 30f,
                        Color.argb(0, Color.red(fog), Color.green(fog), Color.blue(fog)),
                        Color.argb(190, Color.red(fog), Color.green(fog), Color.blue(fog)),
                        Shader.TileMode.CLAMP));
                c.drawRect(SC_L, 320f, SC_R, SC_B, paint);
                paint.setShader(null);
            }

            // rain
            int rl = rainLevel();
            if (rl > 0) {
                int n = rl == 1 ? 40 : (rl == 2 ? 75 : 115);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(0.9f);
                paint.setColor(nightK > 0.5f ? MOON : INK);
                paint.setAlpha(120);
                for (int i = 0; i < n; i++) {
                    float x0 = SC_L + rainX[i];
                    float y0 = SC_T + rainY[i];
                    c.drawLine(x0, y0, x0 - 2.5f, y0 + 9f, paint);
                }
                paint.setAlpha(255);
                paint.setStyle(Paint.Style.FILL);
            }
            // snow
            if (snowing()) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(nightK > 0.5f ? MOON : Color.parseColor("#FFFFFF"));
                for (int i = 0; i < 80; i++) {
                    c.drawCircle(SC_L + rainX[i], SC_T + rainY[i], 1.5f, paint);
                }
            }

            // texts on the scene
            int txt = (nightK > 0.5f || cc > 0.85f && nightK > 0.2f) ? CREAM : INK;
            String[] left = {"LESS", "SCROLLING", "MORE", "HORIZONS"};
            String[] right = {"DISCONNECT", "EXPLORE BREATHE", "REPEAT"};
            for (int i = 0; i < left.length; i++) {
                text(c, left[i], 18f, 257f + i * 9.4f, 6.5f, txt, roboto, Paint.Align.LEFT, 0.46f);
            }
            for (int i = 0; i < right.length; i++) {
                text(c, right[i], 344f, 257f + i * 9.4f, 6.5f, txt, roboto, Paint.Align.RIGHT, 0.46f);
            }
            if (weatherOk) {
                String w = weatherLabel(!day) + " • " + Math.round(wTemp) + "°C";
                text(c, w, 344f, 470f, 7f, nightK > 0.5f ? CREAM : INK, roboto, Paint.Align.RIGHT, 0.2f);
            }

            c.restore();
        }

        // ---------- everything else ----------

        private void drawLive(Canvas c) {
            Calendar cal = Calendar.getInstance();
            boolean h24 = DateFormat.is24HourFormat(HorizonWallpaperService.this);
            int hour = cal.get(Calendar.HOUR_OF_DAY);
            int hh = h24 ? hour : ((hour % 12 == 0) ? 12 : hour % 12);
            int mm = cal.get(Calendar.MINUTE);

            // Clock (top-left frame)
            text(c, String.format(Locale.US, "%02d", hh), 14, 108, 96, INK, bebas, Paint.Align.LEFT, 0f);
            text(c, String.format(Locale.US, "%02d", mm), 14, 182, 96, RED, bebas, Paint.Align.LEFT, 0f);

            // Date next to clock
            String mon = cal.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
            text(c, mon, 112, 62, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            text(c, String.valueOf(cal.get(Calendar.DAY_OF_MONTH)), 112, 88, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            text(c, String.valueOf(cal.get(Calendar.YEAR)), 112, 114, 24, INK, bebas, Paint.Align.LEFT, 0.04f);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(INK);
            paint.setStrokeWidth(1.5f);
            c.drawLine(112, 126, 160, 126, paint);
            if (!h24) {
                text(c, hour < 12 ? "AM" : "PM", 112, 144, 10, RED, roboto, Paint.Align.LEFT, 0.25f);
            }

            // Day name, vertical (right column of top frame)
            String day = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.ENGLISH).toUpperCase(Locale.ENGLISH);
            float size = 62f;
            paint.setTypeface(bebas);
            paint.setTextSize(size);
            paint.setLetterSpacing(0.02f);
            float wdt = paint.measureText(day);
            if (wdt > 182f) size = size * 182f / wdt;
            float cap = size * 0.70f;
            c.save();
            c.translate(266f + cap / 2f, 228f);
            c.rotate(-90f);
            text(c, day, 0, 0, size, INK, bebas, Paint.Align.LEFT, 0.02f);
            c.restore();

            // Greeting (media frame, left)
            String greet = hour < 12 ? "GOOD MORNING" : (hour < 17 ? "GOOD AFTERNOON" : (hour < 21 ? "GOOD EVENING" : "GOOD NIGHT"));
            float gs = 40f;
            paint.setTypeface(bebas);
            paint.setTextSize(gs);
            paint.setLetterSpacing(0.03f);
            float gw = paint.measureText(greet);
            if (gw > 215f) gs = gs * 215f / gw;
            text(c, greet, 18, 524, gs, INK, bebas, Paint.Align.LEFT, 0.03f);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(RED);
            c.drawRect(18, 534, 54, 536.5f, paint);

            // Retro music button (media frame, right)
            try { drawMusicButton(c); } catch (Exception ignored) { }

            // Day of year (left small frame)
            text(c, String.valueOf(cal.get(Calendar.DAY_OF_YEAR)), 16, 590, 42, INK, bebas, Paint.Align.LEFT, 0f);
            text(c, "DAY OF THE YEAR", 16, 603, 5.6f, INK, roboto, Paint.Align.LEFT, 0.25f);

            try { drawBattery(c); } catch (Exception ignored) { }
            try { drawButtons(c); } catch (Exception ignored) { }
            try { if (panelOpen) drawMusic(c); } catch (Exception ignored) { }

            text(c, "V4", 346, 781, 5.5f, INK, roboto, Paint.Align.RIGHT, 0.2f);
        }

        private void drawCassette(Canvas c, float cx, float cy, float s, boolean spin) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(INK);
            paint.setStrokeWidth(1.7f * Math.max(0.8f, s));
            c.drawRoundRect(new RectF(cx - 30f * s, cy - 20f * s, cx + 30f * s, cy + 20f * s), 4f * s, 4f * s, paint);
            paint.setStrokeWidth(1.2f * Math.max(0.8f, s));
            c.drawRoundRect(new RectF(cx - 22f * s, cy - 14f * s, cx + 22f * s, cy + 3f * s), 3f * s, 3f * s, paint);
            float[] rx = {cx - 10f * s, cx + 10f * s};
            float ry = cy - 5.5f * s, rr = 5.2f * s;
            double base = spin ? ((System.currentTimeMillis() / 1000L) % 6L) * 60.0 : 0.0;
            for (int i = 0; i < 2; i++) {
                c.drawCircle(rx[i], ry, rr, paint);
                for (int k = 0; k < 3; k++) {
                    double a = Math.toRadians(base + k * 120.0);
                    c.drawLine(rx[i], ry, rx[i] + (float) Math.cos(a) * rr, ry + (float) Math.sin(a) * rr, paint);
                }
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(RED);
            c.drawRect(cx - 20f * s, cy + 9f * s, cx + 20f * s, cy + 12f * s, paint);
            paint.setColor(INK);
            c.drawCircle(cx - 25f * s, cy - 15f * s, 1.1f * s, paint);
            c.drawCircle(cx + 25f * s, cy - 15f * s, 1.1f * s, paint);
            c.drawCircle(cx - 25f * s, cy + 15f * s, 1.1f * s, paint);
            c.drawCircle(cx + 25f * s, cy + 15f * s, 1.1f * s, paint);
        }

        private void drawMusicButton(Canvas c) {
            if (panelOpen) return;
            boolean playing = isPlaying();
            drawCassette(c, 292f, 506f, 0.95f, playing);
            text(c, "MUSIC", 292f, 546f, 13f, INK, bebas, Paint.Align.CENTER, 0.14f);
            if (playing) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(RED);
                c.drawCircle(326f, 489f, 3f, paint);
            }
        }

        private void drawButtons(Canvas c) {
            float cw = 344f / 3f;
            for (int row = 0; row < 2; row++) {
                for (int col = 0; col < 3; col++) {
                    float cx = 8f + cw * (col + 0.5f);
                    float baseline = row == 0 ? 678f : 744f;
                    text(c, BUTTON_WORDS[row * 3 + col], cx, baseline, 22, INK, bebas,
                            Paint.Align.CENTER, 0.06f);
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(RED);
                    c.drawRect(cx - 9, baseline + 6, cx + 9, baseline + 8, paint);
                }
            }
        }

        private void drawBattery(Canvas c) {
            float x = 146, y = 562, w = 52, h = 22;
            boolean charging = pluggedType != 0;

            paint.setColor(INK);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.8f);
            c.drawRoundRect(x, y, x + w, y + h, 3, 3, paint);
            paint.setStyle(Paint.Style.FILL);
            c.drawRect(x + w, y + 6, x + w + 4, y + h - 6, paint);

            int segs = Math.max(batteryPct > 0 ? 1 : 0, Math.round(batteryPct / 20f));
            paint.setColor(RED);
            float sw = (w - 8) / 5f;
            for (int i = 0; i < segs && i < 5; i++) {
                float sx = x + 3 + i * sw;
                c.drawRect(sx, y + 3, sx + sw - 2, y + h - 3, paint);
            }

            if (charging) {
                float cx = x + w / 2f, top = y + 2f;
                Path bolt = new Path();
                bolt.moveTo(cx + 3f, top);
                bolt.lineTo(cx - 6f, top + 11f);
                bolt.lineTo(cx - 0.5f, top + 11f);
                bolt.lineTo(cx - 3f, top + 18f);
                bolt.lineTo(cx + 6f, top + 7f);
                bolt.lineTo(cx + 0.5f, top + 7f);
                bolt.close();
                paint.setColor(CREAM);
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                paint.setStrokeWidth(1.6f);
                c.drawPath(bolt, paint);
                paint.setColor(INK);
                paint.setStyle(Paint.Style.FILL);
                c.drawPath(bolt, paint);
            }

            text(c, batteryPct + "%", 342, 592, 44, INK, bebas, Paint.Align.RIGHT, 0f);

            String status;
            if (charging) {
                String src = pluggedType == BatteryManager.BATTERY_PLUGGED_WIRELESS ? "WIRELESS"
                        : (pluggedType == BatteryManager.BATTERY_PLUGGED_USB ? "USB" : "CABLE");
                status = "CHARGING • " + src;
            } else {
                status = "ON BATTERY";
            }
            if (tempC >= 0) status += " • " + Math.round(tempC) + "°C";
            text(c, status, 146, 593, 6.2f, charging ? RED : INK, roboto, Paint.Align.LEFT, 0.16f);
        }

        private String fmt(long ms) {
            long s = Math.max(0, ms / 1000);
            return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
        }

        private void drawMusic(Canvas c) {
            boolean active = mediaActive();
            boolean playing = isPlaying();

            // panel background + frame
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(CREAM);
            c.drawRect(PANEL_L, PANEL_T, PANEL_R, PANEL_B - 1f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(INK);
            paint.setStrokeWidth(1.5f);
            c.drawRect(PANEL_L, PANEL_T, PANEL_R, PANEL_B - 1f, paint);

            // close (x)
            paint.setStrokeWidth(1.8f);
            c.drawLine(333f, 403f, 343f, 413f, paint);
            c.drawLine(343f, 403f, 333f, 413f, paint);

            RectF dst = new RectF(18, 405, 114, 501);
            if (active) {
                MediaMetadata m = controller.getMetadata();
                String title = String.valueOf(m.getText(MediaMetadata.METADATA_KEY_TITLE));
                CharSequence artistCs = m.getText(MediaMetadata.METADATA_KEY_ARTIST);
                if (TextUtils.isEmpty(artistCs)) artistCs = m.getText(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
                String artist = artistCs == null ? "" : artistCs.toString().toUpperCase(Locale.getDefault());
                long dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION);
                long pos = position();
                if (dur > 0 && pos > dur) pos = dur;

                text(c, playing ? "NOW PLAYING" : "PAUSED", 126, 410, 6f, RED, roboto, Paint.Align.LEFT, 0.3f);

                if (art != null && art.getWidth() > 0 && art.getHeight() > 0) {
                    int sw = art.getWidth(), sh = art.getHeight(), side = Math.min(sw, sh);
                    Rect src = new Rect((sw - side) / 2, (sh - side) / 2, (sw + side) / 2, (sh + side) / 2);
                    c.drawBitmap(art, src, dst, artPaint);
                } else {
                    drawCassette(c, 66f, 453f, 1.3f, playing);
                }
                paint.setStyle(Paint.Style.STROKE);
                paint.setColor(INK);
                paint.setStrokeWidth(1.5f);
                c.drawRect(dst, paint);

                TextPaint tp = new TextPaint(paint);
                tp.setStyle(Paint.Style.FILL);
                tp.setTypeface(bebas);
                tp.setTextSize(30f);
                tp.setLetterSpacing(0.02f);
                CharSequence t = TextUtils.ellipsize(title.toUpperCase(Locale.getDefault()), tp, 200f, TextUtils.TruncateAt.END);
                text(c, t.toString(), 126, 440, 30f, INK, bebas, Paint.Align.LEFT, 0.02f);
                TextPaint ap = new TextPaint(paint);
                ap.setStyle(Paint.Style.FILL);
                ap.setTypeface(roboto);
                ap.setTextSize(8.5f);
                ap.setLetterSpacing(0.16f);
                CharSequence a = TextUtils.ellipsize(artist, ap, 214f, TextUtils.TruncateAt.END);
                text(c, a.toString(), 126, 456, 8.5f, INK, roboto, Paint.Align.LEFT, 0.16f);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(RED);
                c.drawRect(126, 464, 150, 466.5f, paint);

                float px0 = 126, px1 = 342, py = 486;
                paint.setStyle(Paint.Style.STROKE);
                paint.setColor(INK);
                paint.setStrokeWidth(1.2f);
                c.drawLine(px0, py, px1, py, paint);
                float frac = dur > 0 ? Math.min(1f, (float) pos / dur) : 0f;
                paint.setColor(RED);
                paint.setStrokeWidth(2.4f);
                c.drawLine(px0, py, px0 + (px1 - px0) * frac, py, paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(INK);
                c.drawCircle(px0 + (px1 - px0) * frac, py, 3f, paint);
                text(c, fmt(pos), px0, 499, 6.5f, INK, roboto, Paint.Align.LEFT, 0.1f);
                if (dur > 0) text(c, fmt(dur), px1, 499, 6.5f, INK, roboto, Paint.Align.RIGHT, 0.1f);
            } else {
                text(c, "MUSIC", 126, 410, 6f, RED, roboto, Paint.Align.LEFT, 0.3f);
                drawCassette(c, 66f, 453f, 1.4f, false);
                text(c, "NO TRACK INFO", 126, 440, 28f, INK, bebas, Paint.Align.LEFT, 0.03f);
                if (!hasListenerAccess()) {
                    text(c, "TAP HERE TO ALLOW", 126, 456, 7f, RED, roboto, Paint.Align.LEFT, 0.2f);
                    text(c, "NOTIFICATION ACCESS FOR", 126, 466, 7f, RED, roboto, Paint.Align.LEFT, 0.2f);
                    text(c, "TITLE AND COVER ART", 126, 476, 7f, RED, roboto, Paint.Align.LEFT, 0.2f);
                } else {
                    text(c, "NOTHING PLAYING YET", 126, 456, 7f, INK, roboto, Paint.Align.LEFT, 0.2f);
                }
                text(c, "BUTTONS BELOW STILL WORK", 126, 497, 6f, INK, roboto, Paint.Align.LEFT, 0.2f);
            }

            // transport buttons
            float cy = BTN_Y;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(INK);
            c.drawRect(PREV_X - 9, cy - 7, PREV_X - 7, cy + 7, paint);
            Path prev = new Path();
            prev.moveTo(PREV_X + 8, cy - 7);
            prev.lineTo(PREV_X - 5, cy);
            prev.lineTo(PREV_X + 8, cy + 7);
            prev.close();
            c.drawPath(prev, paint);

            c.drawRect(NEXT_X + 7, cy - 7, NEXT_X + 9, cy + 7, paint);
            Path next = new Path();
            next.moveTo(NEXT_X - 8, cy - 7);
            next.lineTo(NEXT_X + 5, cy);
            next.lineTo(NEXT_X - 8, cy + 7);
            next.close();
            c.drawPath(next, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(RED);
            paint.setStrokeWidth(2.2f);
            c.drawCircle(PLAY_X, cy, 17, paint);
            paint.setStyle(Paint.Style.FILL);
            if (playing) {
                c.drawRect(PLAY_X - 5, cy - 7, PLAY_X - 2, cy + 7, paint);
                c.drawRect(PLAY_X + 2, cy - 7, PLAY_X + 5, cy + 7, paint);
            } else {
                Path play = new Path();
                play.moveTo(PLAY_X - 4, cy - 8);
                play.lineTo(PLAY_X - 4, cy + 8);
                play.lineTo(PLAY_X + 8, cy);
                play.close();
                c.drawPath(play, paint);
            }

            // OPEN APP text button
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(INK);
            paint.setStrokeWidth(1.5f);
            c.drawRect(292f, 510f, 342f, 538f, paint);
            text(c, "OPEN", 317f, 529f, 15f, INK, bebas, Paint.Align.CENTER, 0.1f);
        }
    }
}
